@echo off
setlocal
cd /d "%~dp0"
if not exist .env copy /Y .env.example .env >nul
if not exist node_modules\discord.js (
  echo Installing Discord bot dependency...
  call npm install --omit=dev
  if errorlevel 1 (
    echo npm install failed.
    pause
    exit /b 1
  )
)
if not exist .env (
  echo bot\.env is missing.
  pause
  exit /b 1
)
node bot.js
pause
