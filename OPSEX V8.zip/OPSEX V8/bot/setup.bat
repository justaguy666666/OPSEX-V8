@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18+ is required. Install Node.js, then run setup.bat again.
  pause
  exit /b 1
)
node -e "const v=process.versions.node.split('.')[0]; if(+v<18) process.exit(1)"
if errorlevel 1 (
  echo Node.js 18+ is required.
  pause
  exit /b 1
)
call npm install --omit=dev
if errorlevel 1 (
  echo npm install failed.
  pause
  exit /b 1
)
if not exist .env copy /Y .env.example .env >nul
echo.
echo Setup complete.
echo Edit bot\.env and replace PASTE_YOUR_BOT_TOKEN_HERE with your bot token.
echo Then run start.bat.
pause
