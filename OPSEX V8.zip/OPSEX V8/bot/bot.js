const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require('discord.js');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const { execFileSync } = require('child_process');
const crypto = require('crypto');

function loadDotEnv(file) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith('#')) continue;
      const eq = line.indexOf('=');
      if (eq <= 0) continue;
      const key = line.slice(0, eq).trim();
      let value = line.slice(eq + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      if (!(key in process.env)) process.env[key] = value;
    }
  } catch (_) {}
}

const BOT_DIR = __dirname;
const OPSEX_ROOT = path.resolve(BOT_DIR, '..');
loadDotEnv(path.join(BOT_DIR, '.env'));

const TOKEN = process.env.DISCORD_TOKEN;
if (!TOKEN || TOKEN === 'PASTE_YOUR_BOT_TOKEN_HERE') {
  console.error('Missing DISCORD_TOKEN. Put your Discord bot token in bot/.env');
  process.exit(1);
}

const MAX_INPUT_BYTES = Number(process.env.OPSEX_MAX_INPUT_MB || 25) * 1024 * 1024;
const MAX_OUTPUT_BYTES = Number(process.env.OPSEX_MAX_OUTPUT_MB || 25) * 1024 * 1024;
const DOWNLOAD_TIMEOUT_MS = 30_000;
const BUILD_TIMEOUT_MS = Number(process.env.OPSEX_BUILD_TIMEOUT_MS || 180_000);
const ALLOWED_EXTENSIONS = new Set(['.lua', '.luau']);
const LOG_CHANNEL_ID = (process.env.OPSEX_LOG_CHANNEL_ID || '').trim();

function findLua() {
  if (process.env.LUA_EXE && fs.existsSync(process.env.LUA_EXE)) return process.env.LUA_EXE;
  if (process.platform === 'win32') {
    try {
      const found = execFileSync('where.exe', ['lua.exe'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
        .split(/\r?\n/).map(s => s.trim()).find(Boolean);
      if (found && fs.existsSync(found)) return found;
    } catch (_) {}
    const candidates = [
      'C:\\Program Files\\Lua\\5.1\\lua.exe',
      'C:\\Program Files (x86)\\Lua\\5.1\\lua.exe',
      'C:\\Program Files\\Lua\\5.1\\lua5.1.exe',
      'C:\\Program Files (x86)\\Lua\\5.1\\lua5.1.exe',
    ];
    for (const candidate of candidates) if (fs.existsSync(candidate)) return candidate;
  }
  return 'lua';
}

const LUA_EXE = findLua();
const CLI = path.join(OPSEX_ROOT, 'cli.lua');

if (!fs.existsSync(CLI)) {
  console.error(`OPSEX CLI not found: ${CLI}`);
  process.exit(1);
}

const command = new SlashCommandBuilder()
  .setName('opsexify')
  .setDescription('Obfuscate a Lua/Luau script with Opsex V8.')
  .addAttachmentOption(option => option
    .setName('file')
    .setDescription('Lua/Luau source file')
    .setRequired(true))
  .setDefaultMemberPermissions(null);

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

async function downloadAttachment(url, destination) {
  const parsed = new URL(url);
  const allowedHosts = new Set(['cdn.discordapp.com', 'media.discordapp.net']);
  if (!allowedHosts.has(parsed.hostname)) throw new Error('Attachment URL is not a Discord CDN URL.');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), DOWNLOAD_TIMEOUT_MS);
  try {
    const response = await fetch(url, { signal: controller.signal, redirect: 'error' });
    if (!response.ok) throw new Error(`Discord CDN returned HTTP ${response.status}.`);
    const length = Number(response.headers.get('content-length') || 0);
    if (length > MAX_INPUT_BYTES) throw new Error('Input file is too large.');

    const chunks = [];
    let total = 0;
    for await (const chunk of response.body) {
      total += chunk.length;
      if (total > MAX_INPUT_BYTES) throw new Error('Input file is too large.');
      chunks.push(chunk);
    }
    await fsp.writeFile(destination, Buffer.concat(chunks));
  } finally {
    clearTimeout(timer);
  }
}

function runV8(input, output, seed) {
  return new Promise((resolve, reject) => {
    const args = [CLI, '--v8', '--v8-mode', 'vm', '--v8-seed', String(seed), '--out', output, input];
    const child = spawn(LUA_EXE, args, {
      cwd: OPSEX_ROOT,
      shell: false,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, LUA_PATH: undefined, LUA_CPATH: undefined },
    });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', d => { stdout += d.toString('utf8'); });
    child.stderr.on('data', d => { stderr += d.toString('utf8'); });
    const timer = setTimeout(() => {
      try { child.kill('SIGKILL'); } catch (_) {}
      reject(new Error('V8 build timed out.'));
    }, BUILD_TIMEOUT_MS);
    child.on('error', err => { clearTimeout(timer); reject(err); });
    child.on('close', async code => {
      clearTimeout(timer);
      if (code !== 0) {
        console.error(`Opsex V8 build failed with exit code ${code}.`);
        if (stderr.trim()) console.error(stderr.trim().slice(0, 1500));
        return reject(new Error('V8 build failed.'));
      }
      if (!stdout.includes('Stat: v8.anti_tamper = 1')) {
        return reject(new Error('V8 build report did not confirm the AntiTamper gate.'));
      }
      try {
        const stat = await fsp.stat(output);
        if (stat.size <= 0) throw new Error('V8 produced an empty output file.');
        if (stat.size > MAX_OUTPUT_BYTES) throw new Error('V8 output exceeds the configured safety limit.');
      } catch (err) { return reject(err); }
      resolve({ stdout });
    });
  });
}

async function selfTestV8() {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'opsex-v8-selftest-'));
  const input = path.join(dir, 'input.lua');
  const output = path.join(dir, 'output.lua');
  const payload = path.join(dir, 'payload.lua');
  const source = [
    'local function step(x)',
    '  if x % 2 == 0 then return x + 3 else return x - 1 end',
    'end',
    'local total = 0',
    'for i = 1, 5 do total = total + step(i) end',
    'local values = {a = 2, b = 4, c = 6}',
    'for k, v in pairs(values) do if k ~= "z" then total = total + v end end',
    'local n = 0',
    'while n < 2 do total = total + n; n = n + 1 end',
    'repeat total = total + 1; n = n - 1 until n == 0',
    'if values.a == 2 then total = total + 5 end',
    'return total',
    '',
  ].join('\n');

  async function smokePayload(file, seed) {
    await new Promise((resolve, reject) => {
      const child = spawn(LUA_EXE, [file], {
        cwd: OPSEX_ROOT,
        shell: false,
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe'],
        env: { ...process.env, LUA_PATH: undefined, LUA_CPATH: undefined },
      });
      let stderr = '';
      child.stderr.on('data', d => { stderr += d.toString('utf8'); });
      child.on('error', reject);
      child.on('close', code => {
        if (code !== 0) {
          return reject(new Error(`V8 payload smoke test failed for seed ${seed} with code ${code}${stderr.trim() ? `: ${stderr.trim().slice(0, 500)}` : ''}`));
        }
        resolve();
      });
    });
  }

  try {
    await fsp.writeFile(input, source, 'utf8');
    for (const seed of [808080, 123456, 987654321]) {
      await runV8(input, output, seed);
      const generated = await fsp.readFile(output, 'utf8');
      if (!generated.trim()) {
        throw new Error(`V8 produced empty output for seed ${seed}.`);
      }
      if (!generated.includes('local') && !generated.includes('function')) {
        throw new Error(`V8 produced unexpected output for seed ${seed}.`);
      }
      await fsp.writeFile(payload, generated, 'utf8');
      await smokePayload(payload, seed);
    }
    console.log('V8 self-test passed: multi-control-flow compilation succeeded for 3 seeds.');
  } finally {
    await fsp.rm(dir, { recursive: true, force: true });
  }
}

async function registerCommands() {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  const body = [command.toJSON()];
  for (const guild of client.guilds.cache.values()) {
    try {
      await rest.put(Routes.applicationGuildCommands(client.user.id, guild.id), { body });
      console.log(`Registered /opsexify in ${guild.name} (${guild.id}).`);
    } catch (err) {
      console.error(`Command registration failed for guild ${guild.id}: ${err.message}`);
    }
  }
}

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}.`);
  console.log(`Opsex root: ${OPSEX_ROOT}`);
  console.log(`Lua: ${LUA_EXE}`);
  console.log(`Invite URL: https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot%20applications.commands&permissions=2147483648`);
  try {
    await selfTestV8();
  } catch (err) {
    console.error(`V8 self-test FAILED: ${err.message}`);
    console.error('Bot will not register /opsexify until the V8 build passes the local Lua smoke test.');
    try { await client.destroy(); } catch (_) {}
    process.exit(1);
  }
  await registerCommands();
  console.log('Opsex V8 bot ready.');
});

client.on('guildCreate', async guild => {
  try {
    const rest = new REST({ version: '10' }).setToken(TOKEN);
    await rest.put(Routes.applicationGuildCommands(client.user.id, guild.id), { body: [command.toJSON()] });
  } catch (err) {
    console.error(`Command registration failed for new guild ${guild.id}: ${err.message}`);
  }
});

async function sendAuditLog({ input, inputName, inputSize, outputSize, method, status, error }) {
  if (!LOG_CHANNEL_ID) return;
  try {
    const channel = await client.channels.fetch(LOG_CHANNEL_ID);
    if (!channel || !channel.isTextBased()) throw new Error('Audit log channel is unavailable or not text-based.');

    const lines = [
      'OPSEXIFY AUDIT',
      `Input: ${inputName}`,
      `Input size: ${inputSize} bytes`,
      `Output size: ${outputSize == null ? 'N/A' : `${outputSize} bytes`}`,
      `Method: ${method}`,
      `Status: ${status}`,
    ];
    if (error) lines.push(`Error: ${String(error).replace(/\r?\n/g, ' ').slice(0, 500)}`);

    const payload = { content: lines.join('\n').slice(0, 1900) };
    if (input && fs.existsSync(input)) {
      payload.files = [{ attachment: input, name: `INPUT_${path.basename(inputName).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 90)}` }];
    }
    await channel.send(payload);
  } catch (err) {
    console.error(`Audit log failed: ${err.message}`);
  }
}

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand() || interaction.commandName !== 'opsexify') return;

  const attachment = interaction.options.getAttachment('file', true);
  const originalName = attachment.name || 'input.lua';
  const extension = path.extname(originalName).toLowerCase();
  if (!ALLOWED_EXTENSIONS.has(extension)) {
    return interaction.reply({ content: 'Only .lua and .luau files are accepted.', ephemeral: true });
  }
  if (Number(attachment.size || 0) > MAX_INPUT_BYTES) {
    return interaction.reply({ content: 'That file is too large for the configured Opsex V8 input limit.', ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });
  const jobDir = await fsp.mkdtemp(path.join(os.tmpdir(), 'opsex-job-'));
  const input = path.join(jobDir, 'input' + extension);
  const output = path.join(jobDir, 'output.lua');
  const seed = crypto.randomInt(1, 2147483646);

  try {
    await downloadAttachment(attachment.url, input);
    const inputStat = await fsp.stat(input);
    await runV8(input, output, seed);
    const outputStat = await fsp.stat(output);
    await sendAuditLog({ input, inputName: originalName, inputSize: inputStat.size, outputSize: outputStat.size, method: 'V8/VM', status: 'PASS' });

    const safeBase = path.basename(originalName, extension).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80) || 'script';
    const outputName = `${safeBase}.opsex-v8-vm.lua`;
    await interaction.editReply({
      content: 'v8 obf complete',
      files: [{ attachment: output, name: outputName }],
    });
  } catch (err) {
    console.error(`Job failed: ${err.message}`);
    let failedInputSize = Number(attachment.size || 0);
    try { if (fs.existsSync(input)) failedInputSize = (await fsp.stat(input)).size; } catch (_) {}
    await sendAuditLog({ input: fs.existsSync(input) ? input : null, inputName: originalName, inputSize: failedInputSize, outputSize: null, method: 'V8/VM', status: 'FAIL', error: err.message });
    try { await interaction.editReply({ content: `V8 could not process that file. The input was recorded in the configured audit channel.` }); } catch (_) {}
  } finally {
    try { await fsp.rm(jobDir, { recursive: true, force: true }); } catch (_) {}
  }
});

process.on('SIGINT', () => client.destroy());
process.on('SIGTERM', () => client.destroy());

client.login(TOKEN).catch(err => {
  console.error(`Discord login failed: ${err.message}`);
  process.exit(1);
});
