# OPSEX V8

cmd I used for test-output.lua: lua cli.lua --v8 --v8-mode hybrid --v8-seed 123456 --out test-output.lua test.lua

## Requirements

- Lua 5.1+ or LuaJIT available as `lua` on your PATH.
- Windows users can use Command Prompt or PowerShell from this folder. Commands below use `lua` and work in shells where Lua is on PATH.
- Use a separate copy of your own source file as input. The CLI writes the generated output to the path passed to `--out`.

Check the CLI options with:

lua cli.lua --help

## Recommended: V8 hybrid

From the project root, run:

lua cli.lua --v8 --v8-mode hybrid --v8-seed 123456 --out test-output.lua test.lua

Replace `test.lua` with your input filename and `test-output.lua` with the output filename you want. The seed controls the seeded build layout; choose a different integer for a different build.

### V8 mode selection

All V8 commands use `--v8-preset v8` implicitly, so it is optional. The examples include it only where useful for clarity.

| Mode | Example | Intended use |
|---|---|---|
| `hybrid` | `lua cli.lua --v8 --v8-mode hybrid --v8-seed 123456 --out output.lua input.lua` | Recommended balanced option. Uses selective VM compilation and considers a broader set of eligible helper functions than `vm`. |
| `vm` | `lua cli.lua --v8 --v8-mode vm --v8-seed 123456 --out output.lua input.lua` | Selective VM compilation; intended for the optimized VM path without virtualizing the entire program. |
| `cff` | `lua cli.lua --v8 --v8-mode cff --v8-seed 123456 --out output.lua input.lua` | Control-flow obfuscation path with string protection; use when you do not want the selective VM path. |
| `fullVm` | `lua cli.lua --v8 --v8-mode fullVm --v8-seed 123456 --out output.lua input.lua` | Whole-program VM path. Prioritizes virtualization/static-recovery resistance over runtime speed; benchmark your script before use. |
| `safeEnv` | `lua cli.lua --v8 --v8-mode safeEnv --v8-seed 123456 --out output.lua input.lua` | Whole-program VM variant with the runtime guard compiled separately from the payload VM. Test compatibility with your target runtime. |

For V8, valid mode spellings are case-sensitive: `cff`, `vm`, `hybrid`, `fullVm`, `safeEnv`.

## Other CLI generations

These are available for compatibility/comparison. They are separate pipelines; their output characteristics and performance are not guaranteed to match V8.

| Generation | Command | Intended use |
|---|---|---|
| V7 | `lua cli.lua --v7 --v7-seed 123456 --out output.lua input.lua` | Earlier polymorphic VM pipeline. |
| V6 | `lua cli.lua --v6 --v6-seed 123456 --out output.lua input.lua` | Earlier heterogeneous VM pipeline. |
| V5 | `lua cli.lua --v5 --v5-preset v5-standard --v5-seed 123456 --out output.lua input.lua` | Earlier V5 VM pipeline using the `v5-standard` preset. |
| V4 | `lua cli.lua --v4 --seed 123456 --out output.lua input.lua` | V4 transformation pipeline without the V4 VM option. |
| V4 VM | `lua cli.lua --v4-vm --seed 123456 --out output.lua input.lua` | V4 pipeline with its VM option enabled. |
| V3 | `lua cli.lua --v3 --v3-preset v3-standard --v3-seed 123456 --out output.lua input.lua` | Legacy V3 pipeline; `v3-standard` is its only preset. |

## Common workflow

1. Put your source file in the project folder, or provide a path to it.
2. Run one of the commands above.
3. Check the CLI output for errors and confirm the generated file exists.
4. Test the generated file in the same runtime and environment as the original. Obfuscation can expose compatibility issues with dynamic environments or runtime-specific APIs, so test important behavior before distributing it.

Do not use the same path for input and output.

## Optional Discord bot

The `bot/` folder contains the Discord `/opsexify` bot source. It invokes the root CLI in V8 `vm` mode with a fresh randomized seed per job; it does not expose the CLI mode selector. The bot requires Node.js 18+ and a Discord application/bot token. Setup:

1. Install Lua 5.1+ or LuaJIT and make sure `lua` is available on PATH (or set `LUA_EXE` in `bot/.env`).
2. Open `bot/` and run `setup.bat` once, or run `npm install --omit=dev` there.
3. Copy `.env.example` to `.env` if setup did not create it.
4. Set `DISCORD_TOKEN` in `bot/.env`. Never publish that file or share its token.
5. Optionally set `OPSEX_LOG_CHANNEL_ID` to a private channel ID if you explicitly want audit logging. If it is unset, audit logging is disabled.
6. Run `start.bat` and use `/opsexify` with a `.lua` or `.luau` attachment.

The bot uses `bot/package.json` and `bot/package-lock.json`; dependencies are installed locally by setup. `node_modules` is intentionally not included in this release archive.

## Release layout

- `cli.lua` — command-line entry point.
- `src/` — runtime and transformation source required by the CLI.
- `configs/` — included CLI configuration presets.
- `bot/` — optional Discord bot source and setup files.
- `LICENSE` — upstream license and attribution conditions.
