 

local function script_path()
    local str = debug.getinfo(1, "S").source:sub(2)
    return str:match("(.*[/%\\])") or ""
end

local ROOT = script_path()

package.path =
    ROOT .. "?.lua;" ..
    ROOT .. "src/?.lua;" ..
    ROOT .. "src/?/init.lua;" ..
    package.path

local V3 = require("src.cli")
local V4 = require("prometheus.v4.cli")
local V5 = require("prometheus.v5.cli")
local V6 = require("prometheus.v6.cli")
local V7 = require("prometheus.v7.cli")
local V8 = require("prometheus.v8.cli")

local function usage()
    print("Prometheus V3 / V4 / V5")
    print("")
    print("Usage:")
    print("  lua cli.lua --v3 --v3-preset <preset> --v3-seed <seed> --out <file> <input>")
    print("  lua cli.lua --v4 --seed <seed> --out <file> <input>")
    print("  lua cli.lua --v4-vm --seed <seed> --out <file> <input>")
    print("  lua cli.lua --v5 --v5-preset v5-standard --v5-seed <seed> --out <file> <input>")
    print("  lua cli.lua --v6 --v6-preset v6-beta --v6-seed <seed> --out <file> <input>")
    print("  lua cli.lua --v7 --v7-preset v7 --v7-seed <seed> --out <file> <input>")
    print("  lua cli.lua --v8 --v8-mode <cff|vm|hybrid|fullVm|safeEnv> --v8-seed <seed> --out <file> <input>")
    print("")
    print("Presets:")
    print("  v3-standard  (only V3 mode)")
end

local v3 = false
local v4 = false
local v4vm = false
local v5 = false
local v6 = false
local v7 = false
local v8 = false
local preset = "v3-standard"
local v5preset = "v5-standard"
local v6preset = "v6-beta"
local v7preset = "v7"
local v8preset = "v8"
local v8mode = "cff"
local seed = 0
local output = nil
local input = nil
local pretty = false

local i = 1

while i <= #arg do
    local a = arg[i]

    if a == "--help" or a == "-h" then
        usage()
        return
    elseif a == "--v3" then
        v3 = true
    elseif a == "--v4" then
        v4 = true
    elseif a == "--v4-vm" then
        v4 = true
        v4vm = true
    elseif a == "--v5" then
        v5 = true
    elseif a == "--v6" then
        v6 = true
    elseif a == "--v7" then
        v7 = true
    elseif a == "--v8" then
        v8 = true
    elseif a == "--pretty-print" then
        pretty = true
    elseif a == "--v3-preset" then
        i = i + 1
        preset = arg[i]
        if not preset then
            error("--v3-preset requires a value")
        end
    elseif a == "--v5-preset" then
        i = i + 1
        v5preset = arg[i]
        if not v5preset then error("--v5-preset requires a value") end
    elseif a == "--v6-preset" then
        i = i + 1
        v6preset = arg[i]
        if not v6preset then error("--v6-preset requires a value") end
    elseif a == "--v7-preset" then
        i = i + 1
        v7preset = arg[i]
        if not v7preset then error("--v7-preset requires a value") end
    elseif a == "--v8-preset" then
        i = i + 1
        v8preset = arg[i]
        if not v8preset then error("--v8-preset requires a value") end
    elseif a == "--v8-mode" then
        i = i + 1
        v8mode = arg[i]
        if not v8mode then error("--v8-mode requires cff, vm, hybrid, fullVm, or safeEnv") end
    elseif a == "--seed" or a == "--v4-seed" or a == "--v5-seed" or a == "--v6-seed" or a == "--v7-seed" or a == "--v8-seed" then
        i = i + 1
        seed = tonumber(arg[i])
        if not seed then
            error("--seed requires a number")
        end
    elseif a == "--out" then
        i = i + 1
        output = arg[i]
        if not output then
            error("--out requires a filename")
        end
    elseif a:sub(1, 2) ~= "--" and not input then
        input = a
    end

    i = i + 1
end

if not v3 and not v4 and not v5 and not v6 and not v7 and not v8 then
    usage()
    return
end

local modes = (v3 and 1 or 0) + (v4 and 1 or 0) + (v5 and 1 or 0) + (v6 and 1 or 0) + (v7 and 1 or 0) + (v8 and 1 or 0)
if modes > 1 then error("Choose exactly one of --v3, --v4, --v5, --v6, --v7, or --v8") end

if v3 and preset ~= "v3-standard" then
    error("V3 has one mode: v3-standard")
end
if v5 and v5preset ~= "v5-standard" then error("V5 has one preset: v5-standard") end
if v6 and v6preset ~= "v6-beta" then error("V6 has one preset: v6-beta") end
if v7 and v7preset ~= "v7" then error("V7 has one preset: v7") end
if v8 and v8preset ~= "v8" then error("V8 has one preset: v8") end
if v8 and v8mode ~= "cff" and v8mode ~= "vm" and v8mode ~= "hybrid" and v8mode ~= "fullVm" and v8mode ~= "safeEnv" then error("--v8-mode must be cff, vm, hybrid, fullVm, or safeEnv") end

if not input then
    error("No input file specified")
end

if not output then
    error("No output file specified")
end

local f = assert(io.open(input, "rb"))
local source = f:read("*a")
f:close()

local started = os.clock()
local generated, ctx
if v8 then
    generated, ctx = V8.apply(source, nil, pretty, seed, v8preset, v8mode)
elseif v7 then
    generated, ctx = V7.apply(source, nil, pretty, seed, v7preset)
elseif v6 then
    generated, ctx = V6.apply(source, nil, pretty, seed, v6preset)
elseif v5 then
    generated, ctx = V5.apply(source, nil, pretty, seed)
elseif v4 then
    generated, ctx = V4.apply(source, nil, pretty, seed, v4vm)
else
    generated, ctx = V3.apply(source, nil, pretty, seed, preset)
end

local out = assert(io.open(output, "wb"))
out:write(generated)
out:close()

print('PROMETHEUS: Writing output to "' .. output .. '"')

local elapsed = os.clock() - started
local report
if v8 then
    report = V8.Report.create(ctx, #source, #generated, elapsed)
elseif v7 then
    report = V7.Report.create(ctx, #source, #generated, elapsed)
elseif v6 then
    report = V6.Report.create(ctx, #source, #generated, elapsed)
elseif v5 then
    report = V5.Report.create(ctx, #source, #generated, elapsed)
elseif v4 then
    report = V4.Report.create(ctx, #source, #generated, elapsed)
elseif V3.Report and V3.Report.create then
    report = V3.Report.create(ctx)
else
    report = ctx.report
end
if report then
    local buildLabel = v8 and 'V8 BUILD REPORT' or (v7 and 'V7 BUILD REPORT' or (v6 and 'V6 BUILD REPORT' or (v5 and 'V5 BUILD REPORT' or (v4 and 'V4 BUILD REPORT' or 'V3 BUILD REPORT'))))
    local protectionLabel
    if v8 then
        protectionLabel = (v8mode == 'cff') and 'Protection: OPSEX V8 CFF + string protection' or (v8mode == 'vm') and 'Protection: OPSEX V8 OPTIMIZED SELECTIVE VM + string protection' or (v8mode == 'safeEnv' and 'Protection: OPSEX V8 SAFE-ENV FULL VM' or 'Protection: OPSEX V8 FULL-PROGRAM VM + protected constants')
    elseif v7 then
        protectionLabel = 'Protection: OPSEX V7 POLYMORPHIC VM'
    elseif v6 then
        protectionLabel = 'Protection: OPSEX V6 HETEROGENEOUS VM'
    elseif v5 then
        protectionLabel = 'Protection: OPSEX 5.0 V5 VM PHASE 10'
    elseif v4 then
        protectionLabel = 'Protection: FULL V4'
    else
        protectionLabel = 'Preset: ' .. tostring(report.mode or preset)
    end
    local selectedPreset
    if v8 then selectedPreset = v8mode .. "/" .. v8preset
    elseif v7 then selectedPreset = v7preset
    elseif v6 then selectedPreset = v6preset
    elseif v5 then selectedPreset = v5preset
    elseif v4 then selectedPreset = 'full-v4'
    else selectedPreset = preset end
    print(buildLabel)
    print(protectionLabel)
    print('Preset: ' .. tostring(selectedPreset))
    print('Seed: ' .. tostring(seed))
    print('Pipeline: ' .. table.concat(report.pipeline or report.passes or {}, ' -> '))
    if v4 or v5 or v6 or v7 or v8 then
        print('Input bytes: ' .. tostring(report.inputSize))
        print('Output bytes: ' .. tostring(report.outputSize))
        print('Compile time: ' .. string.format('%.4fs', report.compileTime or 0))
    else
        print('Vmify: ' .. tostring(report.vmify or 'UNKNOWN'))
    end
    print('Deterministic: ' .. tostring(report.deterministic ~= false))

    local statistics = report.statistics or {}
    local statisticNames = {}
    for name in pairs(statistics) do
        statisticNames[#statisticNames + 1] = name
    end
    table.sort(statisticNames)

    for _, name in ipairs(statisticNames) do
        print('Stat: ' .. name .. ' = ' .. tostring(statistics[name]))
    end
end