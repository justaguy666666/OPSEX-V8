 
local Rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()

local Window = Rayfield:CreateWindow({
    Name = "Granny Destroyer",
    LoadingTitle = "Granny Destroyer",
    LoadingSubtitle = "Made By EasyAssNames",
    ConfigurationSaving = {
        Enabled = false
    }
})

local MainTab = Window:CreateTab("Main")
 
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local PlayerGui = LocalPlayer:WaitForChild("PlayerGui")
local UserInputService = game:GetService("UserInputService")
local VirtualInput = game:GetService("VirtualInputManager")

local FloatingGui = Instance.new("ScreenGui")
FloatingGui.Name = "FloatingButtons"
FloatingGui.ResetOnSpawn = false
FloatingGui.IgnoreGuiInset = true
FloatingGui.DisplayOrder = 999999
FloatingGui.ZIndexBehavior = Enum.ZIndexBehavior.Global
FloatingGui.Parent = PlayerGui
 
local function MakeDraggable(button)
    local dragging, startPos, startInputPos

    button.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            startPos = button.Position
            startInputPos = input.Position
        end
    end)

    button.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
        or input.UserInputType == Enum.UserInputType.Touch then
            dragging = false
        end
    end)

    UserInputService.InputChanged:Connect(function(input)
        if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement
        or input.UserInputType == Enum.UserInputType.Touch) then

            local delta = input.Position - startInputPos
            button.Position = UDim2.new(
                startPos.X.Scale,
                startPos.X.Offset + delta.X,
                startPos.Y.Scale,
                startPos.Y.Offset + delta.Y
            )
        end
    end)
end
 
local function CreateCircleButton(name, text, position, keycode)
    local button = Instance.new("TextButton")
    button.Name = name
    button.Size = UDim2.new(0, 55, 0, 55)
    button.Position = position
    button.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
    button.TextColor3 = Color3.new(1, 1, 1)
    button.Font = Enum.Font.GothamBold
    button.TextSize = 14
    button.Text = text
    button.BorderSizePixel = 3
    button.BorderColor3 = Color3.fromRGB(0, 0, 0)
    button.Parent = FloatingGui

    button.MouseButton1Click:Connect(function()
  
        VirtualInput:SendKeyEvent(true, keycode, false, game)
        task.wait()
        VirtualInput:SendKeyEvent(false, keycode, false, game)
    end)

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(1, 0)
    corner.Parent = button

    MakeDraggable(button)
    return button
end
 
local COL1, COL2 = 0.78, 0.88
local ROW1, ROW2, ROW3, ROW4 = 0.05, 0.14, 0.23, 0.32
 
 
CreateCircleButton("ToddlerESPBtn", "V", UDim2.new(COL1, 0, ROW4, 0), Enum.KeyCode.V)
 
CreateCircleButton("FlyBtn", "X", UDim2.new(COL2, 0, ROW1, 0), Enum.KeyCode.X)
 
CreateCircleButton("FlyLegitBtn", "C", UDim2.new(COL2, 0, ROW2, 0), Enum.KeyCode.C)
 
CreateCircleButton("AvoidToddlerBtn", "R", UDim2.new(COL1, 0, ROW3, 0), Enum.KeyCode.R)
 
CreateCircleButton("DodgeProjectilesBtn", "G", UDim2.new(COL2, 0, ROW3, 0), Enum.KeyCode.G)
 
CreateCircleButton("TpToolBtn", "T", UDim2.new(COL1, 0, ROW2, 0), Enum.KeyCode.T)
 
CreateCircleButton("GrannyESPBtn", "H", UDim2.new(COL1, 0, ROW1, 0), Enum.KeyCode.H)

CreateCircleButton("AvoidGrannyToddlerBtn", "Y", UDim2.new(COL2, 0, ROW4, 0), Enum.KeyCode.Y)




MainTab:CreateButton({
    Name = "Grandma ESP",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local LocalPlayer = Players.LocalPlayer

        local function animateHighlight(highlight)
            if highlight:FindFirstChild("Animator") then return end

            local animator = Instance.new("BoolValue")
            animator.Name = "Animator"
            animator.Parent = highlight

            local t = 0
            local speed = 2

            RunService.Heartbeat:Connect(function(dt)
                if not highlight.Parent or animator.Parent ~= highlight then return end

                t += dt * speed
                local pulse = (math.sin(t) + 1) / 2

                highlight.FillTransparency = 0.3 + (pulse * 0.4)
                highlight.OutlineTransparency = 0.1 + math.abs(math.cos(t * 1.5)) * 0.3
            end)
        end

        local function applyTitle(character)
            local head = character:FindFirstChild("Head")
            if not head then return end

            if head:FindFirstChild("GrannyTitle") then return end

            local billboard = Instance.new("BillboardGui")
            billboard.Name = "GrannyTitle"
            billboard.Adornee = head
            billboard.Size = UDim2.new(0, 200, 0, 50)
            billboard.StudsOffset = Vector3.new(0, 2.5, 0)
            billboard.AlwaysOnTop = true
            billboard.MaxDistance = 200
            billboard.Parent = head

            local textLabel = Instance.new("TextLabel")
            textLabel.BackgroundTransparency = 1
            textLabel.Text = "Grandma"
            textLabel.Font = Enum.Font.GothamBold
            textLabel.TextScaled = true
            textLabel.Size = UDim2.new(1, 0, 1, 0)
            textLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
            textLabel.TextTransparency = 1
            textLabel.Parent = billboard

            task.spawn(function()
                for i = 1, 20 do
                    if not textLabel.Parent then break end
                    textLabel.TextTransparency = math.clamp(1 - (i / 20), 0, 1)
                    task.wait(0.02)
                end
            end)
        end

        local function applyHighlight(character)
            local highlight = character:FindFirstChild("GrannyHighlight")

            if not highlight then
                highlight = Instance.new("Highlight")
                highlight.Name = "GrannyHighlight"
                highlight.FillColor = Color3.fromRGB(255, 255, 255)
                highlight.FillTransparency = 0.3
                highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
                highlight.OutlineTransparency = 0.1
                highlight.Adornee = character
                highlight.Parent = character
            end

            animateHighlight(highlight)
        end

        local function isGranny(player)
            local status = player:FindFirstChild("Status")
            if not status then return false end

            local teamValue = status:FindFirstChild("Team")
            return teamValue and teamValue.Value == "Granny"
        end

        local function updatePlayer(player)
            local character = player.Character or player.CharacterAdded:Wait()

            if isGranny(player) then
                applyHighlight(character)
                applyTitle(character)
            end
        end

        for _, player in ipairs(Players:GetPlayers()) do
            task.spawn(function()
                updatePlayer(player)
            end)
        end

        Players.PlayerAdded:Connect(function(player)
            task.spawn(function()
                updatePlayer(player)
            end)
        end)

    end
})

MainTab:CreateButton({
    Name = "Tool ESP (RED)",
    Callback = function()

        local RunService = game:GetService("RunService")

        local map = workspace:WaitForChild("Map")
        local toolsFolder = map:WaitForChild("Tools")

        local HIGHLIGHT_NAME = "ToolHighlight"

        local trackedTools = {}

        local function ensureHighlight(tool)
            if not tool:IsA("Tool") or not tool.Parent then
                return
            end

            local highlight = tool:FindFirstChild(HIGHLIGHT_NAME)

            if not highlight then
                highlight = Instance.new("Highlight")
                highlight.Name = HIGHLIGHT_NAME
                highlight.Parent = tool
            end

            highlight.Enabled = true
            highlight.FillColor = Color3.fromRGB(255, 0, 0)
            highlight.OutlineColor = Color3.fromRGB(255, 50, 50)
            highlight.FillTransparency = 0.15
            highlight.OutlineTransparency = 0
            highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
            highlight.Adornee = tool
        end

        local function trackTool(tool)
            if trackedTools[tool] then
                return
            end

            trackedTools[tool] = true
            ensureHighlight(tool)
        end

        for _, obj in ipairs(toolsFolder:GetDescendants()) do
            if obj:IsA("Tool") then
                trackTool(obj)
            end
        end

        toolsFolder.DescendantAdded:Connect(function(obj)
            if obj:IsA("Tool") then
                trackTool(obj)
            end
        end)

        RunService.Heartbeat:Connect(function()
            for tool in pairs(trackedTools) do
                if tool.Parent then
                    ensureHighlight(tool)
                else
                    trackedTools[tool] = nil
                end
            end
        end)

    end
})

MainTab:CreateButton({
    Name = "Chest ESP (GREEN)",
    Callback = function()

        local TweenService = game:GetService("TweenService")

        local chestFolder = workspace:FindFirstChild("Map") and workspace.Map:FindFirstChild("Chests")
        if not chestFolder or not chestFolder:IsA("Folder") then
            warn("Chests folder not found at workspace.Map.Chests")
            return
        end

        local function startPulse(highlight)
            if highlight:GetAttribute("Pulsing") then return end
            highlight:SetAttribute("Pulsing", true)

            task.spawn(function()
                while highlight.Parent and highlight:GetAttribute("Pulsing") do
                    local fadeOut = TweenService:Create(
                        highlight,
                        TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut),
                        {
                            FillTransparency = 0.8,
                            OutlineTransparency = 0.8
                        }
                    )

                    local fadeIn = TweenService:Create(
                        highlight,
                        TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut),
                        {
                            FillTransparency = 0.2,
                            OutlineTransparency = 0.2
                        }
                    )

                    fadeOut:Play()
                    fadeOut.Completed:Wait()

                    fadeIn:Play()
                    fadeIn.Completed:Wait()
                end
            end)
        end

        local function updateChestHighlight(chest)
            local highlight = chest:FindFirstChild("ChestHighlight")
            local lock = chest:FindFirstChild("Lock")

            if lock then
                if not highlight then
                    highlight = Instance.new("Highlight")
                    highlight.Name = "ChestHighlight"

                    if chest.Name == "MegaChest" then
                        highlight.FillColor = Color3.fromRGB(255, 215, 0)
                        highlight.OutlineColor = Color3.fromRGB(255, 255, 0)
                        highlight.FillTransparency = 0.2
                        highlight.OutlineTransparency = 0.2
                    else
                        highlight.FillColor = Color3.fromRGB(0, 255, 0)
                        highlight.OutlineColor = Color3.fromRGB(0, 255, 0)
                    end

                    highlight.Parent = chest
                end

                if chest.Name == "MegaChest" then
                    startPulse(highlight)
                end

            else
                if highlight then
                    highlight:SetAttribute("Pulsing", false)
                    highlight:Destroy()
                end
            end
        end

        for _, chest in ipairs(chestFolder:GetChildren()) do
            if chest:IsA("Model") or chest:IsA("BasePart") then
                updateChestHighlight(chest)

                chest.ChildAdded:Connect(function(child)
                    if child.Name == "Lock" then
                        updateChestHighlight(chest)
                    end
                end)

                chest.ChildRemoved:Connect(function(child)
                    if child.Name == "Lock" then
                        updateChestHighlight(chest)
                    end
                end)
            end
        end

        chestFolder.ChildAdded:Connect(function(chest)
            if chest:IsA("Model") or chest:IsA("BasePart") then
                updateChestHighlight(chest)

                chest.ChildAdded:Connect(function(child)
                    if child.Name == "Lock" then
                        updateChestHighlight(chest)
                    end
                end)

                chest.ChildRemoved:Connect(function(child)
                    if child.Name == "Lock" then
                        updateChestHighlight(chest)
                    end
                end)
            end
        end)

    end
})

MainTab:CreateButton({
    Name = "AutoPickup Tools",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")

        local player = Players.LocalPlayer
        local character = player.Character or player.CharacterAdded:Wait()
        local root = character:WaitForChild("HumanoidRootPart")

        local PICKUP_DISTANCE = 10

        local function getPrompt(tool)
            if not tool or not tool:IsA("Tool") then
                return nil
            end
            local handle = tool:FindFirstChild("Handle")
            if not handle then
                return nil
            end
            local prompt = handle:FindFirstChild("ToolPickupPrompt")
            if prompt and prompt:IsA("ProximityPrompt") then
                return prompt
            end
            return nil
        end

        RunService.Heartbeat:Connect(function()

            if not root.Parent then
                local newChar = player.Character or player.CharacterAdded:Wait()
                root = newChar:WaitForChild("HumanoidRootPart")
            end

            local toolsFolder = workspace:FindFirstChild("Map")
            if not toolsFolder then return end

            toolsFolder = toolsFolder:FindFirstChild("Tools")
            if not toolsFolder then return end

            for _, tool in pairs(toolsFolder:GetChildren()) do
                local prompt = getPrompt(tool)
                if prompt then
                    local handle = tool.Handle
                    local distance = (root.Position - handle.Position).Magnitude

                    if distance <= PICKUP_DISTANCE and prompt.Enabled then
                        pcall(function()
                            fireproximityprompt(prompt)
                        end)
                    end
                end
            end
        end)

    end
})

MainTab:CreateButton({
    Name = "Bring All Keys",
    Callback = function()

        local Players = game:GetService("Players")
        local player = Players.LocalPlayer

        local function getCharacter()
            local char = player.Character or player.CharacterAdded:Wait()
            local root = char:WaitForChild("HumanoidRootPart", 5)
            return char, root
        end

        local character, root = getCharacter()

        local keysFolder = workspace:FindFirstChild("Map")
            and workspace.Map:FindFirstChild("Keys")

        if not keysFolder then
            warn("Keys folder not found at workspace.Map.Keys")
            return
        end

        for _, key in ipairs(keysFolder:GetChildren()) do
            if key:IsA("BasePart") then
                key.CFrame = root.CFrame * CFrame.new(0, 5, 0)

            elseif key:IsA("Model") then
                local primary = key.PrimaryPart
                if primary then
                    key:SetPrimaryPartCFrame(root.CFrame * CFrame.new(0, 5, 0))
                else
                    warn("Model has no PrimaryPart:", key.Name)
                end
            end
        end

    end
})

MainTab:CreateButton({
    Name = "Inf Energy",
    Callback = function()

        local Players = game:GetService("Players")

        local function setEnergy(player)
            if not player or not player:IsA("Player") then
                warn("Invalid player object")
                return
            end

            local statusFolder = player:WaitForChild("Status", 5)
            if not statusFolder then
                warn("Player " .. player.Name .. " has no Status folder")
                return
            end

            local energyValue = statusFolder:WaitForChild("Energy", 5)
            if not energyValue then
                warn("Player " .. player.Name .. " has no Energy value")
                return
            end

            if not energyValue:IsA("ValueBase") then
                warn("Energy is not a ValueBase for player " .. player.Name)
                return
            end

            energyValue.Value = 9999999999
        end

        for _, player in ipairs(Players:GetPlayers()) do
            task.spawn(setEnergy, player)
        end

        Players.PlayerAdded:Connect(function(player)
            setEnergy(player)
        end)

    end
})

MainTab:CreateButton({
    Name = "Anti Granny Kick (for Toddler)",
    Callback = function()

        local Players = game:GetService("Players")
        local ReplicatedStorage = game:GetService("ReplicatedStorage")
        local RunService = game:GetService("RunService")

        local player = Players.LocalPlayer
        local ragdollRemote = ReplicatedStorage:WaitForChild("RagdollRemotes"):WaitForChild("Ragdoll")

        local freezeConnection
        local frozenParts = {}

        local function freezeCharacter()
            local character = player.Character
            if not character then return end

            frozenParts = {}

            for _, obj in ipairs(character:GetDescendants()) do
                if obj:IsA("BasePart") then
                    frozenParts[obj] = obj.CFrame
                end
            end

            freezeConnection = RunService.RenderStepped:Connect(function()
                for part, cf in pairs(frozenParts) do
                    if part and part.Parent then
                        part.CFrame = cf
                        part.AssemblyLinearVelocity = Vector3.zero
                        part.AssemblyAngularVelocity = Vector3.zero
                    end
                end
            end)
        end

        local function unfreezeCharacter()
            if freezeConnection then
                freezeConnection:Disconnect()
                freezeConnection = nil
            end
            table.clear(frozenParts)
        end

        ragdollRemote.OnClientEvent:Connect(function()
            freezeCharacter()
            task.wait(1)
            unfreezeCharacter()
        end)

    end
})

MainTab:CreateButton({
    Name = "Anti-Fling",
    Callback = function()

        local Players = game:GetService("Players")
        local LocalPlayer = Players.LocalPlayer

        local function NoCollision(character)
            for _, v in ipairs(character:GetDescendants()) do
                if v:IsA("BasePart") then
                    v.CanCollide = false
                end
            end

            character.DescendantAdded:Connect(function(v)
                if v:IsA("BasePart") then
                    v.CanCollide = false
                end
            end)
        end

        local function SetupPlayer(player)
            if player == LocalPlayer then return end

            if player.Character then
                NoCollision(player.Character)
            end

            player.CharacterAdded:Connect(NoCollision)
        end

        for _, player in ipairs(Players:GetPlayers()) do
            SetupPlayer(player)
        end

        Players.PlayerAdded:Connect(SetupPlayer)
 
        task.spawn(function()
            while true do
                for _, player in ipairs(Players:GetPlayers()) do
                    if player ~= LocalPlayer and player.Character then
                        for _, part in ipairs(player.Character:GetDescendants()) do
                            if part:IsA("BasePart") then
                                part.CanCollide = false
                            end
                        end
                    end
                end
                task.wait(1)
            end
        end)

    end
})

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local LocalPlayer = Players.LocalPlayer

local ENABLED = false
local boxes = {}

local function getTeam(plr)
    local status = plr:FindFirstChild("Status")
    local team = status and status:FindFirstChild("Team")
    return team and team.Value
end

local function clearBoxes()
    for _, part in pairs(boxes) do
        part:Destroy()
    end
    table.clear(boxes)
end

local function createBox(plr)
    if boxes[plr] then
      
        local part = boxes[plr]
        local box = part:FindFirstChildOfClass("SelectionBox")
        return part, box
    end

    local part = Instance.new("Part")
    part.Anchored = true
    part.CanCollide = false
    part.CanTouch = false
    part.CanQuery = false
    part.Transparency = 1
    part.Parent = workspace

    local box = Instance.new("SelectionBox")
    box.Adornee = part
    box.Color3 = Color3.fromRGB(255, 40, 40)
    box.LineThickness = 0.06
    box.SurfaceTransparency = 1
    box.Parent = part

    boxes[plr] = part
    return part, box
end


local t = 0

RunService.RenderStepped:Connect(function(dt)
    if not ENABLED then
        clearBoxes()
        return
    end

    t += dt * 6
    local pulse = (math.sin(t) + 1) / 2

    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LocalPlayer and getTeam(plr) == "Granny" then
            local char = plr.Character
            local root = char and char:FindFirstChild("HumanoidRootPart")

            if char and root then
                local part, box = createBox(plr)

                local size = char:GetExtentsSize()
                part.Size = Vector3.new(size.X, size.Y, 9)
                part.CFrame = root.CFrame * CFrame.new(0, 0, -5)

                box.Color3 = Color3.fromRGB(
                    255,
                    40 + math.floor(pulse * 40),
                    40 + math.floor(pulse * 40)
                )

                box.LineThickness = 0.05 + (pulse * 0.03)
            end
        else
            if boxes[plr] then
                boxes[plr]:Destroy()
                boxes[plr] = nil
            end
        end
    end
end)

MainTab:CreateKeybind({
    Name = "Granny Kick Hitbox ESP",
    CurrentKeybind = "H",
    HoldToInteract = false,
    Flag = "GrannyKickESP",
    Callback = function()
        ENABLED = not ENABLED

        Rayfield:Notify({
            Title = "Granny Kick Hitbox ESP",
            Content = ENABLED and "Enabled" or "Disabled",
            Duration = 4
        })
    end
})



MainTab:CreateKeybind({
    Name = "Tp to Nearest Tool",
    CurrentKeybind = "T",
    HoldToInteract = false,
    Flag = "TpNearestTool",
    Callback = function()

        Rayfield:Notify({
            Title = "TP to Nearest Tool",
            Content = "Activated",
            Duration = 4
        })

        local Players = game:GetService("Players")
        local LocalPlayer = Players.LocalPlayer
        local character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
        local root = character:WaitForChild("HumanoidRootPart")

        local map = workspace:FindFirstChild("Map")
        if not map then return end

        local toolsFolder = map:FindFirstChild("Tools")
        if not toolsFolder then return end

        local closestTool = nil
        local closestDistance = math.huge

        for _, tool in ipairs(toolsFolder:GetChildren()) do
            if tool:IsA("Tool") and tool:FindFirstChild("Handle") then
                local handle = tool.Handle
                local distance = (root.Position - handle.Position).Magnitude

                if distance < closestDistance then
                    closestDistance = distance
                    closestTool = tool
                end
            end
        end

        if closestTool then
            local handle = closestTool:FindFirstChild("Handle")
            if handle then
                root.CFrame = handle.CFrame + Vector3.new(0, 3, 0)
            end
        end
    end
})

MainTab:CreateButton({
    Name = "Infinite Yield",
    Callback = function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()
    end
})

MainTab:CreateLabel("Throw a tool at Granny before tp flinging")

local AuraEnabled = false

MainTab:CreateToggle({
    Name = "Tp/Fling Aura (Enable wfling first)",
    CurrentValue = false,
    Flag = "TpFlingAura",
    Callback = function(state)
        AuraEnabled = state
    end
})

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local LocalPlayer = Players.LocalPlayer
local Character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local Root = Character:WaitForChild("HumanoidRootPart")

LocalPlayer.CharacterAdded:Connect(function(char)
    Character = char
    Root = char:WaitForChild("HumanoidRootPart")
end)

local RANGE = 10
local COOLDOWN = 0.33
local lastUse = 0

local function getNearestPlayerInRange()
    local nearestPlayer = nil
    local nearestDistance = RANGE

    for _, player in ipairs(Players:GetPlayers()) do
        if player ~= LocalPlayer and player.Character then
            local targetRoot = player.Character:FindFirstChild("HumanoidRootPart")

            if targetRoot then
                local dist = (Root.Position - targetRoot.Position).Magnitude
                if dist <= nearestDistance then
                    nearestDistance = dist
                    nearestPlayer = player
                end
            end
        end
    end

    return nearestPlayer
end

RunService.Heartbeat:Connect(function()
    if not AuraEnabled then return end
    if not Character or not Character.Parent then return end

    if tick() - lastUse < COOLDOWN then
        return
    end

    local targetPlayer = getNearestPlayerInRange()
    if not targetPlayer then return end

    local targetRoot = targetPlayer.Character and targetPlayer.Character:FindFirstChild("HumanoidRootPart")
    if not targetRoot then return end

    local distance = (Root.Position - targetRoot.Position).Magnitude
    if distance > RANGE then return end

    lastUse = tick()

    Root.CFrame = targetRoot.CFrame
end)

MainTab:CreateButton({
    Name = "WalkFling",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local LocalPlayer = Players.LocalPlayer

        local Character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
        local Root = Character:WaitForChild("HumanoidRootPart")
        local Humanoid = Character:WaitForChild("Humanoid")

        walkflinging = true

        Humanoid.Died:Connect(function()
            walkflinging = false
        end)

        game:GetService("UserInputService").JumpRequest:Connect(function()
            Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
        end)

        Root.CanCollide = false
        Humanoid:ChangeState(11)

        repeat
            RunService.Heartbeat:Wait()

            local vel = Root.Velocity
 
            Root.Velocity = vel * 10000 + Vector3.new(0, 10000, 0)

            RunService.RenderStepped:Wait()
            Root.Velocity = vel

            RunService.Stepped:Wait()
            Root.Velocity = vel + Vector3.new(0, 0.1, 0)

        until walkflinging == false

    end
})

MainTab:CreateButton({
    Name = "WalkFling Lite (Doesn't Instant Kill)",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local LocalPlayer = Players.LocalPlayer

        local Character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
        local Root = Character:WaitForChild("HumanoidRootPart")
        local Humanoid = Character:WaitForChild("Humanoid")

        walkflinging = true

        Humanoid.Died:Connect(function()
            walkflinging = false
        end)

        game:GetService("UserInputService").JumpRequest:Connect(function()
            Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
        end)

        Root.CanCollide = false
        Humanoid:ChangeState(11)

        repeat
            RunService.Heartbeat:Wait()

            local vel = Root.Velocity
 
            Root.Velocity = vel * 50 + Vector3.new(0, 50, 0)

            RunService.RenderStepped:Wait()
            Root.Velocity = vel

            RunService.Stepped:Wait()
            Root.Velocity = vel + Vector3.new(0, 0.1, 0)

        until walkflinging == false

    end
})

MainTab:CreateButton({
    Name = "Teleport to Granny once",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local localPlayer = Players.LocalPlayer

        local function getRootPart(character)
            if not character then return nil end
            local root = character:FindFirstChild("HumanoidRootPart")
            if root and root:IsA("BasePart") then
                return root
            end
            return nil
        end

        local function getTeam(player)
            local status = player:FindFirstChild("Status")
            if not status then return nil end

            local teamValue = status:FindFirstChild("Team")
            if teamValue and teamValue:IsA("StringValue") then
                return teamValue.Value
            end

            return nil
        end

        local myRoot = getRootPart(localPlayer.Character)
        if not myRoot then return end
 
        local originalCFrame = myRoot.CFrame

        local followTime = 0.5
        local endTime = tick() + followTime
 
        while tick() < endTime do
            myRoot = getRootPart(localPlayer.Character)
            if not myRoot then break end

            for _, plr in ipairs(Players:GetPlayers()) do
                if plr ~= localPlayer and getTeam(plr) == "Granny" then
                    local targetRoot = getRootPart(plr.Character)
                    if targetRoot then
                        myRoot.CFrame = targetRoot.CFrame
                        break
                    end
                end
            end

            RunService.Heartbeat:Wait()
        end
 
        myRoot = getRootPart(localPlayer.Character)
        if myRoot then
            myRoot.CFrame = originalCFrame
        end

    end
})

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local localPlayer = Players.LocalPlayer

local teleportEnabled = false

local function getRootPart(character)
    if not character then return nil end
    local root = character:FindFirstChild("HumanoidRootPart")
    if root and root:IsA("BasePart") then
        return root
    end
    return nil
end

local function getTeam(player)
    local status = player:FindFirstChild("Status")
    if not status then return nil end

    local teamValue = status:FindFirstChild("Team")
    if teamValue and teamValue:IsA("StringValue") then
        return teamValue.Value
    end
    return nil
end

MainTab:CreateToggle({
    Name = "Loop Teleport to Granny",
    CurrentValue = false,
    Flag = "LoopTeleportGranny",
    Callback = function(state)
        teleportEnabled = state
    end
})

RunService.Heartbeat:Connect(function()
    if not teleportEnabled then return end

    local myCharacter = localPlayer.Character
    local myRoot = getRootPart(myCharacter)
    if not myRoot then return end

    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= localPlayer and getTeam(plr) == "Granny" then
            local targetRoot = getRootPart(plr.Character)
            if targetRoot then
                myRoot.CFrame = targetRoot.CFrame
            end
        end
    end
end)

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local LocalPlayer = Players.LocalPlayer

local Remotes = {
    ReplicatedStorage.RagdollRemotes.Ragdoll,
    ReplicatedStorage.RagdollRemotes.RagdollForce,
}

local TELEPORT_DELAY = 5
local HOLD_TIME = 0.33

local enabled = false
local running = false

MainTab:CreateToggle({
    Name = "Karma (wfling)",
    CurrentValue = false,
    Flag = "KarmaWfling",
    Callback = function(state)
        enabled = state
        if not state then
            running = false
        end
    end
})

local function getGrannyPlayer()
    for _, player in ipairs(Players:GetPlayers()) do
        if player ~= LocalPlayer then
            local status = player:FindFirstChild("Status")
            local team = status and status:FindFirstChild("Team")

            if team and team.Value == "Granny" then
                return player
            end
        end
    end
    return nil
end

local function loopTeleportInFront(granny, myRoot)
    if running then return end
    running = true

    local endTime = time() + HOLD_TIME

    while time() < endTime and enabled do
        if not myRoot.Parent or not granny.Character then
            break
        end

        local grannyRoot = granny.Character:FindFirstChild("HumanoidRootPart")
        if not grannyRoot then
            break
        end

        myRoot.CFrame = grannyRoot.CFrame * CFrame.new(0, 0, -0.5)

        task.wait(0.03)
    end

    running = false
end

local function teleportEffect()
    local granny = getGrannyPlayer()
    if not granny then return end

    local char = LocalPlayer.Character
    if not char then return end

    local root = char:FindFirstChild("HumanoidRootPart")
    if not root then return end

    loopTeleportInFront(granny, root)
end

local function onRemoteActivated()
    if not enabled then return end

    task.delay(TELEPORT_DELAY, function()
        if enabled then
            teleportEffect()
        end
    end)
end

for _, remote in ipairs(Remotes) do
    if remote:IsA("RemoteEvent") then
        remote.OnClientEvent:Connect(onRemoteActivated)
    end
end

local TELEPORT_DELAY = 4
local HOLD_TIME = 5

local enabled = false
local running = false

MainTab:CreateToggle({
    Name = "Karma (wfling Lite)",
    CurrentValue = false,
    Flag = "KarmaWflingLite",
    Callback = function(state)
        enabled = state
        if not state then
            running = false
        end
    end
})

local function getGrannyPlayer()
    for _, player in ipairs(Players:GetPlayers()) do
        if player ~= LocalPlayer then
            local status = player:FindFirstChild("Status")
            local team = status and status:FindFirstChild("Team")

            if team and team.Value == "Granny" then
                return player
            end
        end
    end
    return nil
end

local function loopTeleportInFront(granny, myRoot)
    if running then return end
    running = true

    local endTime = time() + HOLD_TIME

    while time() < endTime and enabled do
        if not myRoot.Parent or not granny.Character then
            break
        end

        local grannyRoot = granny.Character:FindFirstChild("HumanoidRootPart")
        if not grannyRoot then
            break
        end

        myRoot.CFrame = grannyRoot.CFrame * CFrame.new(0, 0, -0.5)

        task.wait(0.03)
    end

    running = false
end

local function teleportEffect()
    local granny = getGrannyPlayer()
    if not granny then return end

    local char = LocalPlayer.Character
    if not char then return end

    local root = char:FindFirstChild("HumanoidRootPart")
    if not root then return end

    loopTeleportInFront(granny, root)
end

local function onRemoteActivated()
    if not enabled then return end

    task.delay(TELEPORT_DELAY, function()
        if enabled then
            teleportEffect()
        end
    end)
end

for _, remote in ipairs(Remotes) do
    if remote:IsA("RemoteEvent") then
        remote.OnClientEvent:Connect(onRemoteActivated)
    end
end

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local localPlayer = Players.LocalPlayer

local teleportEnabled = false
local COOLDOWN = 0.11
local lastUse = 0

local function getRootPart(char)
    return char and char:FindFirstChild("HumanoidRootPart")
end

local function getTeam(plr)
    local status = plr:FindFirstChild("Status")
    local team = status and status:FindFirstChild("Team")
    return team and team.Value
end

local function getBehindPosition(targetRoot)
    return targetRoot.Position - targetRoot.CFrame.LookVector * 1
end

local function teleportBehind(myRoot, targetRoot)
    if tick() - lastUse < COOLDOWN then return end

    local pos = getBehindPosition(targetRoot)
    pos = pos + Vector3.new(0, 2, 0)

    myRoot.CFrame = CFrame.lookAt(pos, targetRoot.Position)

    lastUse = tick()
end

MainTab:CreateToggle({
    Name = "Distract Granny (Behind)",
    CurrentValue = false,
    Flag = "DistractGrannyBehind",
    Callback = function(state)
        teleportEnabled = state
    end
})

RunService.Heartbeat:Connect(function()
    if not teleportEnabled then return end

    local myCharacter = localPlayer.Character
    local myRoot = getRootPart(myCharacter)
    if not myRoot then return end

    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= localPlayer and getTeam(plr) == "Granny" then
            local targetRoot = getRootPart(plr.Character)
            if targetRoot then
                teleportBehind(myRoot, targetRoot)
            end
        end
    end
end)

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local localPlayer = Players.LocalPlayer

local teleportEnabled = false
local COOLDOWN = 0.11
local lastUse = 0

local function getRootPart(char)
    return char and char:FindFirstChild("HumanoidRootPart")
end

local function getTeam(plr)
    local status = plr:FindFirstChild("Status")
    local team = status and status:FindFirstChild("Team")
    return team and team.Value
end

local function getFrontPosition(targetRoot)
    return targetRoot.Position - targetRoot.CFrame.LookVector * -1
end

local function teleportFront(myRoot, targetRoot)
    if tick() - lastUse < COOLDOWN then return end

    local pos = getFrontPosition(targetRoot)
    pos = pos + Vector3.new(0, 2, 0)

    myRoot.CFrame = CFrame.lookAt(pos, targetRoot.Position)

    lastUse = tick()
end

MainTab:CreateToggle({
    Name = "Distract Granny (Front)",
    CurrentValue = false,
    Flag = "DistractGrannyFront",
    Callback = function(state)
        teleportEnabled = state
    end
})

RunService.Heartbeat:Connect(function()
    if not teleportEnabled then return end

    local myCharacter = localPlayer.Character
    local myRoot = getRootPart(myCharacter)
    if not myRoot then return end

    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= localPlayer and getTeam(plr) == "Granny" then
            local targetRoot = getRootPart(plr.Character)
            if targetRoot then
                teleportFront(myRoot, targetRoot)
            end
        end
    end
end)

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local localPlayer = Players.LocalPlayer

local teleportEnabled = false
local COOLDOWN = 0.11
local lastUse = 0

local function getRootPart(char)
    return char and char:FindFirstChild("HumanoidRootPart")
end

local function getTeam(plr)
    local status = plr:FindFirstChild("Status")
    local team = status and status:FindFirstChild("Team")
    return team and team.Value
end

local function teleportAboveHead(myRoot, targetCharacter)
    if tick() - lastUse < COOLDOWN then
        return
    end

    local head = targetCharacter:FindFirstChild("Head")
    local targetRoot = targetCharacter:FindFirstChild("HumanoidRootPart")

    if not head or not targetRoot then
        return
    end
 
    local pos = head.Position + Vector3.new(0, 1, 0)

    local _, yRotation, _ = targetRoot.CFrame:ToOrientation()

    myRoot.CFrame =
        CFrame.new(pos) *
        CFrame.Angles(0, yRotation, 0)

    lastUse = tick()
end

MainTab:CreateToggle({
    Name = "Distract Granny (Above)",
    CurrentValue = false,
    Flag = "DistractGrannyAbove",
    Callback = function(state)
        teleportEnabled = state
    end
})

RunService.Heartbeat:Connect(function()
    if not teleportEnabled then
        return
    end

    local myCharacter = localPlayer.Character
    local myRoot = getRootPart(myCharacter)

    if not myRoot then
        return
    end

    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= localPlayer and getTeam(plr) == "Granny" then
            local targetCharacter = plr.Character

            if targetCharacter then
                teleportAboveHead(myRoot, targetCharacter)
            end
        end
    end
end)

MainTab:CreateButton({
    Name = "Auto Snipe Granny (hold & let go quickly)",
    Callback = function()

        task.spawn(function()

            local Players = game:GetService("Players")
            local ReplicatedStorage = game:GetService("ReplicatedStorage")
            local UserInputService = game:GetService("UserInputService")

            local localPlayer = Players.LocalPlayer

            local TELEPORT_DELAY = 0.2
            local STAY_TIME = 0.25

            local HOLD_TIME = 0.22
            local holding = false
            local holdStart = 0

            local animFolder = ReplicatedStorage:WaitForChild("Animations"):WaitForChild("Toddler")

            local watchedAnimations = {
                [animFolder.ChildThrow.AnimationId] = true,
                [animFolder.ChildThrows.AnimationId] = true,
            }

            local enabled = true

            local function getRoot(character)
                return character and character:FindFirstChild("HumanoidRootPart")
            end

            local function isGranny(player)
                local status = player:FindFirstChild("Status")
                if not status then return false end

                local team = status:FindFirstChild("Team")
                if not team then return false end

                return team.Value == "Granny"
            end

            local function getGrannyRoot()
                for _, player in ipairs(Players:GetPlayers()) do
                    if player ~= localPlayer and isGranny(player) then
                        local root = getRoot(player.Character)
                        if root then
                            return root
                        end
                    end
                end
            end

            local function triggerTeleport()
                if not enabled then return end

                local character = localPlayer.Character
                local root = getRoot(character)
                if not root then return end

                local targetRoot = getGrannyRoot()
                if not targetRoot then return end

                local originalCFrame = root.CFrame

                local offsetPosition = targetRoot.Position + Vector3.new(0, 0, 0.2)

                root.CFrame = CFrame.lookAt(offsetPosition, targetRoot.Position)

                local camera = workspace.CurrentCamera
                camera.CFrame = CFrame.lookAt(camera.CFrame.Position, targetRoot.Position)

                task.delay(STAY_TIME, function()
                    if not enabled then return end
                    local char = localPlayer.Character
                    local r = getRoot(char)

                    if r then
                        r.CFrame = originalCFrame
                    end
                end)
            end

            local function onAnimationPlayed(track)
                if not enabled then return end

                local animation = track.Animation
                if not animation then return end

                if not watchedAnimations[animation.AnimationId] then
                    return
                end

                task.delay(TELEPORT_DELAY, function()
                    triggerTeleport()
                end)
            end

            UserInputService.InputBegan:Connect(function(input, gameProcessed)
                if gameProcessed then return end

                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    holding = true
                    holdStart = time()

                    task.delay(HOLD_TIME, function()
                        if holding and (time() - holdStart >= HOLD_TIME) then
                            triggerTeleport()
                        end
                    end)
                end
            end)

            UserInputService.InputEnded:Connect(function(input)
                if input.UserInputType == Enum.UserInputType.MouseButton1 then
                    holding = false
                end
            end)

            local function setupCharacter(character)
                local humanoid = character:WaitForChild("Humanoid")
                local animator = humanoid:WaitForChild("Animator")

                humanoid.Died:Connect(function()
                    enabled = false
                end)

                animator.AnimationPlayed:Connect(onAnimationPlayed)
            end

            if localPlayer.Character then
                setupCharacter(localPlayer.Character)
            end

            localPlayer.CharacterAdded:Connect(setupCharacter)

        end)


        task.spawn(function()

            local Players = game:GetService("Players")
            local RunService = game:GetService("RunService")
            local LocalPlayer = Players.LocalPlayer
            local Character = LocalPlayer.Character
            local Root = Character:WaitForChild("HumanoidRootPart")
            local Humanoid = Character:WaitForChild("Humanoid")

            test = true

            Humanoid.Died:Connect(function()
                test = false
            end)

            game:GetService("UserInputService").JumpRequest:Connect(function()
                Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
            end)

            Root.CanCollide = false
            Humanoid:ChangeState(11)

            repeat
                RunService.Heartbeat:Wait()
                local vel = Root.Velocity
                Root.Velocity = vel * 50 + Vector3.new(0, 10, 0)
                RunService.RenderStepped:Wait()
                Root.Velocity = vel
                RunService.Stepped:Wait()
                Root.Velocity = vel + Vector3.new(0, 0.1, 0)
            until test == false

        end)

    end
})

MainTab:CreateButton({
    Name = "Magic Projectile",
    Callback = function()

        local Players = game:GetService("Players")

        local HITBOX_SIZE = Vector3.new(5000, 5000, 5000)
        local TRANSPARENCY = 1

        local localPlayer = Players.LocalPlayer

        local function isGranny(player)
            return player:FindFirstChild("Status")
                and player.Status:FindFirstChild("Team")
                and player.Status.Team.Value == "Granny"
        end

        local function applyToGrannyCharacter(char)
            local root = char:FindFirstChild("HumanoidRootPart")

            if root and root:IsA("BasePart") then
                root.CanCollide = false
                root.Size = HITBOX_SIZE
                root.Transparency = TRANSPARENCY
            end

            for _, obj in ipairs(char:GetChildren()) do
                if obj:IsA("Tool") then
                    obj:Destroy()
                end
            end
        end

        local function hookPlayer(plr)
            plr.CharacterAdded:Connect(function(char)
                if isGranny(plr) then
                    applyToGrannyCharacter(char)
                end
            end)

            if plr.Character and isGranny(plr) then
                applyToGrannyCharacter(plr.Character)
            end
        end

        for _, plr in ipairs(Players:GetPlayers()) do
            hookPlayer(plr)
        end

        Players.PlayerAdded:Connect(hookPlayer)

        local function applyHandle(obj)
            if obj:IsA("BasePart") and obj.Name == "Handle" then
                obj.Transparency = 1
                obj.CanCollide = false
                obj.CastShadow = false
            end
        end

        local function watchCharacter(char)
            for _, obj in ipairs(char:GetDescendants()) do
                applyHandle(obj)
            end

            char.DescendantAdded:Connect(function(obj)
                applyHandle(obj)
            end)
        end

        for _, plr in ipairs(Players:GetPlayers()) do
            if plr.Character and isGranny(plr) then
                watchCharacter(plr.Character)
            end

            plr.CharacterAdded:Connect(function(char)
                if isGranny(plr) then
                    watchCharacter(char)
                end
            end)
        end

        Players.PlayerAdded:Connect(function(plr)
            plr.CharacterAdded:Connect(function(char)
                if isGranny(plr) then
                    watchCharacter(char)
                end
            end)
        end)

    end
})

local AutoAvoidGrannyToddler_Enabled = false
local AutoAvoidGrannyToddler_Conn = nil

MainTab:CreateKeybind({
    Name = "Auto Avoid Granny (Toddler)",
    CurrentKeybind = "Y",
    HoldToInteract = false,
    Flag = "AutoAvoidGrannyToddler",
    Callback = function()

        AutoAvoidGrannyToddler_Enabled = not AutoAvoidGrannyToddler_Enabled

        Rayfield:Notify({
            Title = "Auto Avoid Granny (Toddler)",
            Content = AutoAvoidGrannyToddler_Enabled and "Enabled" or "Disabled",
            Duration = 4
        })

        if AutoAvoidGrannyToddler_Enabled then
       

            local Players = game:GetService("Players")
            local RunService = game:GetService("RunService")
            local Workspace = game:GetService("Workspace")

            local lp = Players.LocalPlayer
            local char = lp.Character or lp.CharacterAdded:Wait()
            local root = char:WaitForChild("HumanoidRootPart")

            local DETECTION_RADIUS = 30
            local SPEED = 75

            local PRIORITY_DIST = 25
            local EMERGENCY_DIST = 10

            local TELEPORT_DIST = 20

            local lastTeleport = 0
            local TELEPORT_COOLDOWN = 1.2

            local graceTime = 0
            local GRACE_DURATION = 0.6

            local lastPos = root.Position
            local stuckTime = 0

            local moveDir = Vector3.zero

            local recentTeleports = {}
            local MAX_TELEPORT_MEMORY = 6
            local REPEAT_RADIUS = 12

            local function wasRecentlyUsed(pos)
                for _, p in ipairs(recentTeleports) do
                    if (p - pos).Magnitude < REPEAT_RADIUS then
                        return true
                    end
                end
                return false
            end

            local rayParams = RaycastParams.new()
            rayParams.FilterType = Enum.RaycastFilterType.Exclude
            rayParams.FilterDescendantsInstances = {char}

            local function getTarget()
                local best, bestDist = nil, DETECTION_RADIUS
                local priority, priorityDist = nil, PRIORITY_DIST

                for _, p in ipairs(Players:GetPlayers()) do
                    if p ~= lp then
                        local status = p:FindFirstChild("Status")
                        local team = status and status:FindFirstChild("Team")

                        if team and tostring(team.Value) == "Granny" then
                            local pr = p.Character and p.Character:FindFirstChild("HumanoidRootPart")

                            if pr then
                                local dist = (pr.Position - root.Position).Magnitude

                                if dist <= PRIORITY_DIST then
                                    if not priority or dist < priorityDist then
                                        priority, priorityDist = pr, dist
                                    end
                                end

                                if dist < bestDist then
                                    best, bestDist = pr, dist
                                end
                            end
                        end
                    end
                end

                return priority or best, bestDist
            end

            local function teleportEscape()
                if tick() - lastTeleport < TELEPORT_COOLDOWN then return end

                local origin = root.Position

                local dirs = {
                    Vector3.new(1,0,0),
                    Vector3.new(-1,0,0),
                    Vector3.new(0,0,1),
                    Vector3.new(0,0,-1),
                    Vector3.new(1,0,1).Unit,
                    Vector3.new(-1,0,1).Unit,
                }

                local bestPos
                local bestScore = -math.huge
                local chosenDir

                for _, d in ipairs(dirs) do
                    local hit = Workspace:Raycast(origin, d * TELEPORT_DIST, rayParams)
                    local score = hit and (hit.Position - origin).Magnitude or TELEPORT_DIST

                    local candidate = origin + d * math.min(score, TELEPORT_DIST)

                    if not wasRecentlyUsed(candidate) then
                        if score > bestScore then
                            bestScore = score
                            bestPos = candidate
                            chosenDir = d
                        end
                    end
                end

                if not bestPos then
                    bestPos = origin + Vector3.new(0,0,TELEPORT_DIST)
                    chosenDir = Vector3.new(0,0,1)
                end

                root.CFrame = CFrame.new(bestPos)

                table.insert(recentTeleports, bestPos)
                if #recentTeleports > MAX_TELEPORT_MEMORY then
                    table.remove(recentTeleports, 1)
                end

                graceTime = GRACE_DURATION
                lastTeleport = tick()
                stuckTime = 0
                lastPos = bestPos
                moveDir = chosenDir or moveDir
            end

            local function step(dt)
                local target, dist = getTarget()
                if not target then return end

                if graceTime > 0 then
                    graceTime -= dt
                    return
                end

                if dist <= EMERGENCY_DIST then
                    teleportEscape()
                    return
                end

                local toTarget = (target.Position - root.Position)
                if toTarget.Magnitude < 0.1 then return end

                local away = (-toTarget).Unit
                local side = Vector3.new(-away.Z, 0, away.X)

                local desired =
                    away * 1.2 +
                    side * 0.4 +
                    moveDir * 0.6

                local dir = desired.Unit

                moveDir = moveDir:Lerp(dir, 0.12)
                if moveDir.Magnitude > 0 then
                    moveDir = moveDir.Unit
                end

                local speed = SPEED * math.clamp(25 / math.max(dist, 1), 1, 2)

                local pos = root.Position + moveDir * speed * dt
                local cf = CFrame.lookAt(pos, pos + moveDir)

                root.CFrame = root.CFrame:Lerp(cf, 1 - math.exp(-12 * dt))

                local moved = (root.Position - lastPos).Magnitude

                if moved < 0.08 then
                    stuckTime += dt
                else
                    stuckTime = math.max(stuckTime - dt * 2, 0)
                end

                lastPos = root.Position

                if stuckTime > 0.8 then
                    teleportEscape()
                    stuckTime = 0
                end
            end

            AutoAvoidGrannyToddler_Conn = RunService.Heartbeat:Connect(function(dt)
                if AutoAvoidGrannyToddler_Enabled then
                    step(dt)
                end
            end)

        else
         
            if AutoAvoidGrannyToddler_Conn then
                AutoAvoidGrannyToddler_Conn:Disconnect()
                AutoAvoidGrannyToddler_Conn = nil
            end
        end
    end
})


local GrannyTab = Window:CreateTab("Granny")

GrannyTab:CreateButton({
    Name = "Granny Meds ESP (PINK)",
    Callback = function()

        local Players = game:GetService("Players")

        local pink = Color3.fromRGB(255, 80, 160)

        local function applyEffects(target)
            if not target or not target:IsA("BasePart") then
                return
            end

            if target:FindFirstChild("EnhancedHighlight") then
                return
            end

            local h = Instance.new("Highlight")
            h.Name = "EnhancedHighlight"
            h.Adornee = target
            h.FillColor = pink
            h.OutlineColor = pink
            h.FillTransparency = 0.15
            h.OutlineTransparency = 0
            h.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
            h.Parent = target

            local gui = Instance.new("BillboardGui")
            gui.Name = "GlowRing"
            gui.Size = UDim2.new(4, 0, 4, 0)
            gui.LightInfluence = 0
            gui.AlwaysOnTop = true
            gui.Parent = target

            local glow = Instance.new("ImageLabel")
            glow.BackgroundTransparency = 1
            glow.Image = "rbxassetid://1316045217"
            glow.ImageColor3 = pink
            glow.ImageTransparency = 0.2
            glow.Size = UDim2.new(1, 0, 1, 0)
            glow.Parent = gui

            task.spawn(function()
                local t = 0
                while target.Parent and gui.Parent do
                    t += task.wait(0.05)
                    local pulse = (math.sin(t * 2) + 1) / 2

                    h.FillTransparency = 0.1 + pulse * 0.25
                    glow.ImageTransparency = 0.15 + pulse * 0.5
                end
            end)
        end

        local pillsFolder = workspace:FindFirstChild("Map")
            and workspace.Map:FindFirstChild("Pills")

        if not pillsFolder then
            warn("workspace.Map.Pills not found.")
            return
        end

        local function processPill(pill)
            if not pill or not pill.Parent then
                return
            end

            if pill:IsA("BasePart") then
                applyEffects(pill)
                return
            end

            for _, desc in ipairs(pill:GetDescendants()) do
                if desc:IsA("BasePart") then
                    applyEffects(desc)
                end
            end
        end

        for _, pill in ipairs(pillsFolder:GetChildren()) do
            processPill(pill)
        end

        pillsFolder.ChildAdded:Connect(function(newPill)
            processPill(newPill)
        end)

    end
})

GrannyTab:CreateButton({
    Name = "Granny Task ESP (PURPLE)",
    Callback = function()

        local function getTaskItemsFolder()
            local map = workspace:FindFirstChild("Map")
            if not map then return nil end

            local taskItems = map:FindFirstChild("TaskItems")
            return taskItems
        end

        local highlights = {}

        local function createHighlight(target)
            if not target or highlights[target] then return end

            local highlight = Instance.new("Highlight")
            highlight.Adornee = target

            highlight.FillColor = Color3.fromRGB(170, 0, 255)
            highlight.OutlineColor = Color3.fromRGB(120, 0, 200)

            highlight.FillTransparency = 0.5
            highlight.OutlineTransparency = 0
            highlight.Parent = target

            highlights[target] = highlight
        end

        local function removeHighlight(target)
            local highlight = highlights[target]
            if highlight then
                highlight:Destroy()
                highlights[target] = nil
            end
        end

        local function scanChildren(folder)
            for _, child in ipairs(folder:GetChildren()) do
                createHighlight(child)
            end
        end

        local function watchFolder(folder)
            folder.ChildAdded:Connect(function(child)
                createHighlight(child)
            end)

            folder.ChildRemoved:Connect(function(child)
                removeHighlight(child)
            end)
        end

        task.defer(function()
            while true do
                local folder = getTaskItemsFolder()
                if folder then
                    scanChildren(folder)
                    watchFolder(folder)
                    break
                end
                task.wait(0.5)
            end
        end)

    end
})

local ToddlerESPEnabled = false
local ToddlerESPConnections = {}

GrannyTab:CreateKeybind({
    Name = "Toddler ESP",
    CurrentKeybind = "V",
    HoldToInteract = false,
    Flag = "ToddlerESP",
    Callback = function()
        ToddlerESPEnabled = not ToddlerESPEnabled

        Rayfield:Notify({
            Title = "Toddler ESP",
            Content = ToddlerESPEnabled and "Enabled" or "Disabled",
            Duration = 4
        })

        if ToddlerESPEnabled then
          
            local Players = game:GetService("Players")
            local RunService = game:GetService("RunService")

            local function animateHighlight(highlight)
                if highlight:FindFirstChild("Animator") then
                    return
                end

                local animator = Instance.new("BoolValue")
                animator.Name = "Animator"
                animator.Parent = highlight

                local t = 0
                local speed = 4

                local conn = RunService.Heartbeat:Connect(function(dt)
                    if not ToddlerESPEnabled then return end
                    if not highlight.Parent or animator.Parent ~= highlight then
                        return
                    end

                    t += dt * speed

                    local pulse = (math.sin(t) + 1) / 2

                    highlight.FillTransparency = 0.35 + (pulse * 0.35)
                    highlight.OutlineTransparency = 0.05 + (pulse * 0.05)

                    highlight.OutlineColor = Color3.fromRGB(
                        255,
                        30 + (pulse * 70),
                        30 + (pulse * 70)
                    )
                end)

                table.insert(ToddlerESPConnections, conn)
            end

            local function applyHighlight(character)
                if not character then return end

                local highlight = character:FindFirstChild("ToddlerHighlight")

                if not highlight then
                    highlight = Instance.new("Highlight")
                    highlight.Name = "ToddlerHighlight"

                    highlight.FillColor = Color3.fromRGB(255, 165, 0)
                    highlight.FillTransparency = 0.35

                    highlight.OutlineColor = Color3.fromRGB(255, 0, 0)
                    highlight.OutlineTransparency = 0

                    highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop

                    highlight.Adornee = character
                    highlight.Parent = character
                end

                animateHighlight(highlight)
            end

            local function removeEffects(character)
                if not character then return end

                local highlight = character:FindFirstChild("ToddlerHighlight")

                if highlight then
                    highlight:Destroy()
                end
            end

            local function isToddler(player)
                local status = player:FindFirstChild("Status")
                if not status then
                    return false
                end

                local team = status:FindFirstChild("Team")

                return team
                    and team:IsA("StringValue")
                    and team.Value == "Toddler"
            end

            local function updatePlayer(player)
                local character = player.Character
                if not character then
                    return
                end

                if isToddler(player) then
                    applyHighlight(character)
                else
                    removeEffects(character)
                end
            end

            local function setupPlayer(player)
                local conn1 = player.CharacterAdded:Connect(function(character)
                    task.wait(0.5)
                    if ToddlerESPEnabled then
                        updatePlayer(player)
                    end
                end)

                table.insert(ToddlerESPConnections, conn1)

                task.spawn(function()
                    local status = player:WaitForChild("Status", 10)
                    if not status then return end

                    local team = status:WaitForChild("Team", 10)
                    if not team then return end

                    local conn2 = team:GetPropertyChangedSignal("Value"):Connect(function()
                        if ToddlerESPEnabled then
                            updatePlayer(player)
                        end
                    end)

                    table.insert(ToddlerESPConnections, conn2)
                end)

                if player.Character then
                    updatePlayer(player)
                end
            end

            for _, player in ipairs(Players:GetPlayers()) do
                setupPlayer(player)
            end

            local conn3 = Players.PlayerAdded:Connect(function(player)
                setupPlayer(player)
            end)

            table.insert(ToddlerESPConnections, conn3)

        else
          
            for _, conn in ipairs(ToddlerESPConnections) do
                conn:Disconnect()
            end
            table.clear(ToddlerESPConnections)

            for _, player in ipairs(Players:GetPlayers()) do
                if player.Character then
                    local highlight = player.Character:FindFirstChild("ToddlerHighlight")
                    if highlight then
                        highlight:Destroy()
                    end
                end
            end
        end
    end
})



GrannyTab:CreateButton({
    Name = "Closest Toddler Indicators (Press V) (Press M to change modes)",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local UserInputService = game:GetService("UserInputService")

        local LocalPlayer = Players.LocalPlayer

        local TARGET_TEAM_NAME = "Toddler"
        local ORB_COUNT = 8

        local enabled = true
        local currentTarget = nil

        local ORB_MODE = 1

        local ORB_MODES = {
            "DNA HELIX",
            "SATURN RINGS",
            "TORNADO",
            "CUBE",
            "SOLAR SYSTEM",
            "ANGEL HALO",
            "BLACK HOLE",
            "SPHERE CAGE",
            "INFINITY",
            "CROWN",
            "WINGS",
            "STAR",
            "DOUBLE HALO",
            "SPIRAL STAIRCASE",
            "HEART",
            "ATOM",
            "FLOWER",
            "LIGHTNING",
            "PYRAMID",
            "GALAXY"
        }

        local orbsFolder = Instance.new("Folder")
        orbsFolder.Name = "VisualOrbs"
        orbsFolder.Parent = workspace

        local orbs = {}
        local orbTargets = {}

        local screenGui = Instance.new("ScreenGui")
        screenGui.Name = "DistanceIndicator"
        screenGui.ResetOnSpawn = false
        screenGui.Parent = LocalPlayer:WaitForChild("PlayerGui")

        local label = Instance.new("TextLabel")
        label.Size = UDim2.new(0,250,0,50)
        label.Position = UDim2.new(0.5,-125,0.93,0)
        label.BackgroundTransparency = 0.3
        label.BackgroundColor3 = Color3.fromRGB(0,0,0)
        label.TextScaled = true
        label.Font = Enum.Font.GothamBold
        label.TextColor3 = Color3.fromRGB(255,255,255)
        label.Text = "Searching..."
        label.Parent = screenGui

        local function getHRP(char)
            return char and char:FindFirstChild("HumanoidRootPart")
        end

        local function getTeam(plr)
            return plr.Team
                or (
                    plr:FindFirstChild("Status")
                    and plr.Status:FindFirstChild("Team")
                    and plr.Status.Team.Value
                )
        end

        local function getDistanceColor(distance,maxDist)
            local alpha = math.clamp(distance / maxDist,0,1)

            local red = Color3.fromRGB(255,60,60)
            local yellow = Color3.fromRGB(255,200,80)
            local green = Color3.fromRGB(60,255,120)

            if alpha < 0.3 then
                return red:Lerp(yellow,alpha / 0.3)
            else
                return yellow:Lerp(green,(alpha - 0.3) / 0.7)
            end
        end

        local function getClosestToddler()
            local myHRP = getHRP(LocalPlayer.Character)
            if not myHRP then return nil end

            local closest = nil
            local closestDist = math.huge

            for _,plr in ipairs(Players:GetPlayers()) do
                if plr ~= LocalPlayer then
                    if tostring(getTeam(plr)) == TARGET_TEAM_NAME then
                        local hrp = getHRP(plr.Character)
                        if hrp then
                            local dist = (hrp.Position - myHRP.Position).Magnitude
                            if dist < closestDist then
                                closestDist = dist
                                closest = plr
                            end
                        end
                    end
                end
            end

            return closest,closestDist
        end

        local function createOrb()
            local orb = Instance.new("Part")
            orb.Shape = Enum.PartType.Ball
            orb.Material = Enum.Material.Neon
            orb.Size = Vector3.new(0.32,0.32,0.32)
            orb.Anchored = true
            orb.CanCollide = false
            orb.CastShadow = false
            orb.Parent = orbsFolder

            local light = Instance.new("PointLight")
            light.Range = 7.5
            light.Brightness = 0.5
            light.Parent = orb

            local orbAtt = Instance.new("Attachment")
            orbAtt.Parent = orb

            local targetAtt = Instance.new("Attachment")
            targetAtt.Parent = orb

            local beam = Instance.new("Beam")
            beam.Attachment0 = orbAtt
            beam.Attachment1 = targetAtt
            beam.FaceCamera = true
            beam.LightInfluence = 0
            beam.LightEmission = 1
            beam.Width0 = 0.22
            beam.Width1 = 0.03
            beam.Transparency = NumberSequence.new({
                NumberSequenceKeypoint.new(0,0.1),
                NumberSequenceKeypoint.new(1,1)
            })
            beam.Parent = orb

            return orb,targetAtt
        end

        local function buildOrbs()
            orbs = {}
            orbTargets = {}

            for i=1,ORB_COUNT do
                local orb,att = createOrb()
                table.insert(orbs,orb)
                table.insert(orbTargets,att)
            end
        end

        local function destroyOrbs()
            for _,orb in ipairs(orbs) do
                orb:Destroy()
            end
            orbs = {}
            orbTargets = {}
        end

        buildOrbs()
        UserInputService.InputBegan:Connect(function(input,gp)
            if gp then return end

            if input.KeyCode == Enum.KeyCode.V then
                enabled = not enabled
                label.Visible = enabled

                if enabled then
                    buildOrbs()
                else
                    destroyOrbs()
                end
            end

            if input.KeyCode == Enum.KeyCode.M then
                ORB_MODE += 1
                if ORB_MODE > #ORB_MODES then
                    ORB_MODE = 1
                end
                print("Orb Mode:", ORB_MODES[ORB_MODE])
            end
        end)

        local lastUpdate = 0

        RunService.RenderStepped:Connect(function()
            if not enabled then return end
            if #orbs == 0 then return end

            local now = tick()

            if now - lastUpdate > 0.2 then
                lastUpdate = now
                currentTarget = getClosestToddler()
            end

            local target, dist = getClosestToddler()

            if not target then
                label.Text = "No target"
                label.TextColor3 = Color3.fromRGB(150,150,150)
                return
            end

            label.Text = string.format(
                "%s | %.1f studs | %s",
                target.Name,
                dist,
                ORB_MODES[ORB_MODE]
            )

            if not currentTarget or not currentTarget.Character then
                return
            end

            local hrp = getHRP(currentTarget.Character)
            local myHRP = getHRP(LocalPlayer.Character)

            if not hrp or not myHRP then
                return
            end

            local distance = (myHRP.Position - hrp.Position).Magnitude
            local color = getDistanceColor(distance,100)
            label.TextColor3 = color

            local basePos = hrp.Position
            local time = now

            for i, orb in ipairs(orbs) do
                local targetAtt = orbTargets[i]
                local offset
               

                if ORB_MODE == 1 then
                    local strand = (i % 2 == 0) and 1 or -1
                    local helixAngle = time * 3 + (i * 0.8)

                    offset = Vector3.new(
                        math.cos(helixAngle) * 1.8,
                        math.sin(helixAngle * 0.5) * 2,
                        math.sin(helixAngle) * 1.8
                    ) * strand

                elseif ORB_MODE == 2 then
                    local ring = (i <= ORB_COUNT/2) and 1.5 or 2.7
                    local angle = (math.pi*2/ORB_COUNT)*i + time

                    offset = Vector3.new(
                        math.cos(angle)*ring,
                        (i % 2 == 0 and 0.5 or -0.5),
                        math.sin(angle)*ring
                    )

                elseif ORB_MODE == 3 then
                    local height = ((i-1)/ORB_COUNT)*5 - 2.5
                    local angle = time*4 + i
                    local radius = 0.7 + (i*0.2)

                    offset = Vector3.new(
                        math.cos(angle)*radius,
                        height,
                        math.sin(angle)*radius
                    )

                elseif ORB_MODE == 4 then
                    local points = {
                        Vector3.new(2,2,2),
                        Vector3.new(-2,2,2),
                        Vector3.new(2,-2,2),
                        Vector3.new(-2,-2,2),
                        Vector3.new(2,2,-2),
                        Vector3.new(-2,2,-2),
                        Vector3.new(2,-2,-2),
                        Vector3.new(-2,-2,-2)
                    }

                    local point = points[i]

                    offset = point + Vector3.new(
                        math.sin(time+i)*0.3,
                        math.cos(time+i)*0.3,
                        math.sin(time*1.5+i)*0.3
                    )

                elseif ORB_MODE == 5 then
                    local radius = 0.8 + (i*0.35)
                    local speed = 0.4 + (i*0.15)
                    local angle = time * speed * 4

                    offset = Vector3.new(
                        math.cos(angle+i)*radius,
                        math.sin(time+i)*0.4,
                        math.sin(angle+i)*radius
                    )

                elseif ORB_MODE == 6 then
                    local angle = (math.pi * 2 / ORB_COUNT) * i + time * 2

                    offset = Vector3.new(
                        math.cos(angle) * 2.2,
                        3,
                        math.sin(angle) * 2.2
                    )

                elseif ORB_MODE == 7 then
                    local pulse = 1.5 + math.sin(time * 2 + i)
                    local angle = time * 5 + i

                    offset = Vector3.new(
                        math.cos(angle) * pulse,
                        math.sin(angle * 2) * 0.5,
                        math.sin(angle) * pulse
                    )

                elseif ORB_MODE == 8 then
                    local phi = math.acos(1 - (2 * i / ORB_COUNT))
                    local theta = time * 1.5 + i * 2.4
                    local radius = 2.5

                    offset = Vector3.new(
                        radius * math.sin(phi) * math.cos(theta),
                        radius * math.cos(phi),
                        radius * math.sin(phi) * math.sin(theta)
                    )

                elseif ORB_MODE == 9 then
                    local t = time * 2 + (i / ORB_COUNT) * math.pi * 2

                    offset = Vector3.new(
                        math.sin(t) * 2.5,
                        math.sin(t * 2) * 0.8,
                        math.sin(t) * math.cos(t) * 2.5
                    )

                elseif ORB_MODE == 10 then
                    local angle = (math.pi * 2 / ORB_COUNT) * i + time
                    local crownRadius = 1.8
                    local spike = (math.sin(i * 2.5) > 0) and 1 or 0

                    offset = Vector3.new(
                        math.cos(angle) * crownRadius,
                        2.5 + spike,
                        math.sin(angle) * crownRadius
                    )

                elseif ORB_MODE == 11 then
                    local side = (i <= ORB_COUNT/2) and -1 or 1
                    local index = ((i - 1) % (ORB_COUNT/2))

                    local x = side * (1.5 + index * 0.8)
                    local y = 0.5 + (index * 0.35)
                    local z = (index * 0.8)

                    local flap = math.sin(time * 6) * 0.4

                    local localOffset = Vector3.new(
                        x,
                        y + flap,
                        z
                    )

                    offset = hrp.CFrame:VectorToWorldSpace(localOffset)

                elseif ORB_MODE == 12 then
                    local angle = (math.pi * 2 / ORB_COUNT) * i + time
                    local radius = (i % 2 == 0) and 2.5 or 1.2

                    offset = Vector3.new(
                        math.cos(angle) * radius,
                        0,
                        math.sin(angle) * radius
                    )

                elseif ORB_MODE == 13 then
                    local upper = i <= ORB_COUNT/2
                    local angle = (math.pi * 2 / (ORB_COUNT/2)) * i + time

                    offset = Vector3.new(
                        math.cos(angle) * 2,
                        upper and 3 or 1,
                        math.sin(angle) * 2
                    )

                elseif ORB_MODE == 14 then
                    local angle = time * 3 + i
                    local height = (i - 1) * 0.7

                    offset = Vector3.new(
                        math.cos(angle) * 1.8,
                        height - 2.5,
                        math.sin(angle) * 1.8
                    )

                elseif ORB_MODE == 15 then
                    local t = ((i - 1) / ORB_COUNT) * math.pi * 2 + time * 0.5

                    local x = 16 * math.sin(t)^3
                    local z = 13 * math.cos(t)
                        - 5 * math.cos(2*t)
                        - 2 * math.cos(3*t)
                        - math.cos(4*t)

                    offset = Vector3.new(
                        x * 0.15,
                        0,
                        z * 0.15
                    )

                elseif ORB_MODE == 16 then
                    local angle = time * 3 + i

                    if i % 3 == 0 then
                        offset = Vector3.new(
                            math.cos(angle) * 2,
                            math.sin(angle) * 2,
                            0
                        )
                    elseif i % 3 == 1 then
                        offset = Vector3.new(
                            0,
                            math.cos(angle) * 2,
                            math.sin(angle) * 2
                        )
                    else
                        offset = Vector3.new(
                            math.cos(angle) * 2,
                            0,
                            math.sin(angle) * 2
                        )
                    end

                elseif ORB_MODE == 17 then
                    local angle = (math.pi * 2 / ORB_COUNT) * i + time
                    local radius = 2 + math.sin(angle * 5)

                    offset = Vector3.new(
                        math.cos(angle) * radius,
                        0,
                        math.sin(angle) * radius
                    )

                elseif ORB_MODE == 18 then
                    offset = Vector3.new(
                        math.random(-20,20) / 10,
                        (i - ORB_COUNT/2) * 0.8,
                        math.random(-20,20) / 10
                    )

                elseif ORB_MODE == 19 then
                    local points = {
                        Vector3.new(0,3,0),
                        Vector3.new(-2,0,-2),
                        Vector3.new(2,0,-2),
                        Vector3.new(2,0,2),
                        Vector3.new(-2,0,2),
                        Vector3.new(-1,1,-1),
                        Vector3.new(1,1,-1),
                        Vector3.new(0,2,0)
                    }

                    offset = points[i]

                elseif ORB_MODE == 20 then
                    local arm = i % 2
                    local angle = time * 2 + (i * 0.8)
                    local radius = 0.5 + (i * 0.35)

                    offset = Vector3.new(
                        math.cos(angle + arm * math.pi) * radius,
                        math.sin(i + time) * 0.5,
                        math.sin(angle + arm * math.pi) * radius
                    )
                end

                orb.Position = basePos + offset
                targetAtt.WorldPosition = hrp.Position

                orb.Color = color

                local light = orb:FindFirstChildOfClass("PointLight")
                if light then
                    light.Color = color
                end

                local beam = orb:FindFirstChildOfClass("Beam")
                if beam then
                    beam.Color = ColorSequence.new(color)
                end
            end
        end)

    end
})

GrannyTab:CreateButton({
    Name = "Granny AutoTask",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")

        local player = Players.LocalPlayer

        local AUTO_DISTANCE = 12  

        local prompts = {}

        local function registerPrompt(prompt)
            if not prompt or prompts[prompt] then return end
            prompts[prompt] = true
        end

        local function scanForPrompts(parent)
            for _, obj in ipairs(parent:GetDescendants()) do
                if obj:IsA("ProximityPrompt") then
                    registerPrompt(obj)
                end
            end
        end

        workspace.DescendantAdded:Connect(function(desc)
            if desc:IsA("ProximityPrompt") then
                registerPrompt(desc)
            end
        end)

        scanForPrompts(workspace)

        RunService.RenderStepped:Connect(function()
            local character = player.Character
            local root = character and character:FindFirstChild("HumanoidRootPart")
            if not root then return end

            for prompt in pairs(prompts) do

                if not prompt.Parent then
                    prompts[prompt] = nil
                else

                    local holder = prompt.Parent
                    local pos

                    if holder:IsA("BasePart") then
                        pos = holder.Position
                    else
                        local model = holder:FindFirstAncestorOfClass("Model")
                        if model and model.PrimaryPart then
                            pos = model.PrimaryPart.Position
                        end
                    end

                    if pos then
                        local distance = (root.Position - pos).Magnitude

                        if prompt.Enabled and distance <= math.min(AUTO_DISTANCE, prompt.MaxActivationDistance) then
                            pcall(function()
                                prompt:InputHoldBegin()
                            end)
                        else
                            pcall(function()
                                prompt:InputHoldEnd()
                            end)
                        end
                    end
                end
            end
        end)

        player.CharacterAdded:Connect(function()
            task.wait(1)
            scanForPrompts(workspace)
        end)

    end
})

local DodgeEnabled = false
local DodgeConnections = {}

GrannyTab:CreateKeybind({
    Name = "Projectile AutoDodge",
    CurrentKeybind = "G",
    HoldToInteract = false,
    Flag = "ProjectileDodge",
    Callback = function()
        DodgeEnabled = not DodgeEnabled

        Rayfield:Notify({
            Title = "Projectile AutoDodge",
            Content = DodgeEnabled and "Enabled" or "Disabled",
            Duration = 4
        })

        if DodgeEnabled then
          
            local Players = game:GetService("Players")
            local ReplicatedStorage = game:GetService("ReplicatedStorage")
            local UserInputService = game:GetService("UserInputService")

            local LocalPlayer = Players.LocalPlayer

            local watchedAnimations = {
                [ReplicatedStorage.Animations.Toddler.ChildThrows.AnimationId] = true,
                [ReplicatedStorage.Animations.Toddler.ChildThrow.AnimationId] = true,
            }

            local DETECTION_RADIUS = 88
            local OFFSET_DISTANCE = 9

            local CLOSE_RANGE = 38
            local RETURN_DELAY = 0.8

            local function getCharacter()
                return LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
            end

            local function pushAwayFromAnimation(targetCharacter, sourceCharacter)
                if not DodgeEnabled then return end

                local targetRoot = targetCharacter:FindFirstChild("HumanoidRootPart")
                local sourceRoot = sourceCharacter:FindFirstChild("HumanoidRootPart")

                if not targetRoot or not sourceRoot then return end

                local distance = (targetRoot.Position - sourceRoot.Position).Magnitude
                local originalCFrame = targetRoot.CFrame

                if distance <= CLOSE_RANGE then
                    targetRoot.CFrame = targetRoot.CFrame * CFrame.Angles(math.rad(90), 0, 0)

                    task.delay(0.8, function()
                        if targetRoot and targetRoot.Parent then
                            targetRoot.CFrame = originalCFrame
                        end
                    end)

                    return
                end

                local rightVector = sourceRoot.CFrame.RightVector
                local sideMultiplier = (math.random(0, 1) == 0) and -1 or 1
                local moveDirection = rightVector * sideMultiplier

                targetRoot.CFrame = originalCFrame + (moveDirection * OFFSET_DISTANCE)

                task.delay(RETURN_DELAY, function()
                    if targetRoot and targetRoot.Parent then
                        targetRoot.CFrame = originalCFrame
                    end
                end)
            end

            local function onAnimationPlayed(sourceCharacter, animationTrack)
                if not DodgeEnabled then return end

                local localCharacter = getCharacter()

                local myRoot = localCharacter:FindFirstChild("HumanoidRootPart")
                local sourceRoot = sourceCharacter:FindFirstChild("HumanoidRootPart")

                if not myRoot or not sourceRoot then return end

                local anim = animationTrack.Animation
                if not anim or not watchedAnimations[anim.AnimationId] then return end

                local distance = (myRoot.Position - sourceRoot.Position).Magnitude

                if distance <= DETECTION_RADIUS then
                    pushAwayFromAnimation(localCharacter, sourceCharacter)
                end
            end

            local function watchCharacter(character)
                if not DodgeEnabled then return end

                local humanoid = character:FindFirstChildOfClass("Humanoid")
                    or character:WaitForChild("Humanoid")

                local animator = humanoid:FindFirstChildOfClass("Animator")
                    or humanoid:WaitForChild("Animator")

                local conn = animator.AnimationPlayed:Connect(function(track)
                    if DodgeEnabled and character ~= getCharacter() then
                        onAnimationPlayed(character, track)
                    end
                end)

                table.insert(DodgeConnections, conn)
            end

            for _, player in ipairs(Players:GetPlayers()) do
                if player ~= LocalPlayer then
                    if player.Character then
                        watchCharacter(player.Character)
                    end

                    table.insert(DodgeConnections,
                        player.CharacterAdded:Connect(function(char)
                            if DodgeEnabled then
                                watchCharacter(char)
                            end
                        end)
                    )
                end
            end

            table.insert(DodgeConnections,
                Players.PlayerAdded:Connect(function(player)
                    if player == LocalPlayer then return end

                    table.insert(DodgeConnections,
                        player.CharacterAdded:Connect(function(char)
                            if DodgeEnabled then
                                watchCharacter(char)
                            end
                        end)
                    )
                end)
            )

        else
        
            for _, conn in ipairs(DodgeConnections) do
                conn:Disconnect()
            end
            table.clear(DodgeConnections)
        end
    end
})


local FlyLegitEnabled = false
local FlyLegitConn = nil

GrannyTab:CreateKeybind({
    Name = "Fly Bypass (Legit)",
    CurrentKeybind = "C",
    HoldToInteract = false,
    Flag = "FlyLegit",
    Callback = function()
        FlyLegitEnabled = not FlyLegitEnabled

        Rayfield:Notify({
            Title = "Fly Bypass (Legit)",
            Content = FlyLegitEnabled and "Enabled" or "Disabled",
            Duration = 4
        })

        if FlyLegitEnabled then
            local Players = game:GetService("Players")
            local UIS = game:GetService("UserInputService")
            local RS = game:GetService("RunService")

            local player = Players.LocalPlayer
            local character, humanoid, root

            local function loadChar()
                character = player.Character or player.CharacterAdded:Wait()
                humanoid = character:WaitForChild("Humanoid")
                root = character:WaitForChild("HumanoidRootPart")
                humanoid.AutoRotate = true
            end

            loadChar()
            player.CharacterAdded:Connect(loadChar)

            local BASE_SPEED = 27
            local BOOST_SPEED = 100
            local ACCEL = 0.35
            local SMOOTH = 0.32

            local flying = true
            local inputVector = Vector3.zero
            local velocity = Vector3.zero

            local function updateInput()
                local x, y, z = 0, 0, 0
                if UIS:IsKeyDown(Enum.KeyCode.W) then z -= 1 end
                if UIS:IsKeyDown(Enum.KeyCode.S) then z += 1 end
                if UIS:IsKeyDown(Enum.KeyCode.A) then x -= 1 end
                if UIS:IsKeyDown(Enum.KeyCode.D) then x += 1 end
                if UIS:IsKeyDown(Enum.KeyCode.Space) then y += 1 end
                if UIS:IsKeyDown(Enum.KeyCode.LeftShift) then y -= 1 end
                inputVector = Vector3.new(x, y, z)
            end

            FlyLegitConn = RS.RenderStepped:Connect(function(dt)
                if not FlyLegitEnabled then return end
                if not flying or not root then return end

                updateInput()

                local cam = workspace.CurrentCamera
                local desiredDir = cam.CFrame:VectorToWorldSpace(inputVector)
                if desiredDir.Magnitude > 0 then desiredDir = desiredDir.Unit end

                local targetSpeed = (inputVector.Magnitude > 0) and BOOST_SPEED or BASE_SPEED
                local desiredVelocity = desiredDir * targetSpeed

                velocity = velocity:Lerp(desiredVelocity, ACCEL)
                local nextPos = root.Position + velocity * dt

                if inputVector.Y == 0 then
                    nextPos = Vector3.new(nextPos.X, root.Position.Y, nextPos.Z)
                end

                local targetCF = CFrame.new(nextPos, nextPos + root.CFrame.LookVector)
                root.CFrame = root.CFrame:Lerp(targetCF, SMOOTH)

                root.AssemblyLinearVelocity = Vector3.zero
                root.AssemblyAngularVelocity = Vector3.zero
            end)

        else
            if FlyLegitConn then
                FlyLegitConn:Disconnect()
                FlyLegitConn = nil
            end
        end
    end
})


local FlyEnabled = false
local FlyConn = nil

GrannyTab:CreateKeybind({
    Name = "Fly Bypass",
    CurrentKeybind = "X",
    HoldToInteract = false,
    Flag = "FlyBypass",
    Callback = function()
        FlyEnabled = not FlyEnabled

        Rayfield:Notify({
            Title = "Fly Bypass",
            Content = FlyEnabled and "Enabled" or "Disabled",
            Duration = 4
        })

        if FlyEnabled then
            local Players = game:GetService("Players")
            local UIS = game:GetService("UserInputService")
            local RS = game:GetService("RunService")

            local player = Players.LocalPlayer
            local character, humanoid, root

            local function loadChar()
                character = player.Character or player.CharacterAdded:Wait()
                humanoid = character:WaitForChild("Humanoid")
                root = character:WaitForChild("HumanoidRootPart")
                humanoid.AutoRotate = true
            end

            loadChar()
            player.CharacterAdded:Connect(loadChar)

            local BASE_SPEED = 90
            local BOOST_SPEED = 180
            local ACCEL = 0.35
            local SMOOTH = 0.32

            local flying = true
            local inputVector = Vector3.zero
            local velocity = Vector3.zero

            local function updateInput()
                local x, y, z = 0, 0, 0
                if UIS:IsKeyDown(Enum.KeyCode.W) then z -= 1 end
                if UIS:IsKeyDown(Enum.KeyCode.S) then z += 1 end
                if UIS:IsKeyDown(Enum.KeyCode.A) then x -= 1 end
                if UIS:IsKeyDown(Enum.KeyCode.D) then x += 1 end
                if UIS:IsKeyDown(Enum.KeyCode.Space) then y += 1 end
                if UIS:IsKeyDown(Enum.KeyCode.LeftShift) then y -= 1 end
                inputVector = Vector3.new(x, y, z)
            end

            FlyConn = RS.RenderStepped:Connect(function(dt)
                if not FlyEnabled then return end
                if not flying or not root then return end

                updateInput()

                local cam = workspace.CurrentCamera
                local desiredDir = cam.CFrame:VectorToWorldSpace(inputVector)
                if desiredDir.Magnitude > 0 then desiredDir = desiredDir.Unit end

                local targetSpeed = (inputVector.Magnitude > 0) and BOOST_SPEED or BASE_SPEED
                local desiredVelocity = desiredDir * targetSpeed

                velocity = velocity:Lerp(desiredVelocity, ACCEL)
                local nextPos = root.Position + velocity * dt

                if inputVector.Y == 0 then
                    nextPos = Vector3.new(nextPos.X, root.Position.Y, nextPos.Z)
                end

                local targetCF = CFrame.new(nextPos, nextPos + root.CFrame.LookVector)
                root.CFrame = root.CFrame:Lerp(targetCF, SMOOTH)

                root.AssemblyLinearVelocity = Vector3.zero
                root.AssemblyAngularVelocity = Vector3.zero
            end)

        else
            if FlyConn then
                FlyConn:Disconnect()
                FlyConn = nil
            end
        end
    end
})



GrannyTab:CreateButton({
    Name = "Walkspeed Bypass",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local localPlayer = Players.LocalPlayer

        local function getRootPart(character)
            if not character then return nil end

            local root = character:FindFirstChild("HumanoidRootPart")
            if root and root:IsA("BasePart") then
                return root
            end

            return nil
        end

        local function getTeam(player)
            local status = player:FindFirstChild("Status")
            if not status then return nil end

            local teamValue = status:FindFirstChild("Team")
            if teamValue and teamValue:IsA("StringValue") then
                return teamValue.Value
            end

            return nil
        end

        local function getNearestToddler()
            local myRoot = getRootPart(localPlayer.Character)
            if not myRoot then return nil end

            local nearestRoot = nil
            local nearestDistance = math.huge

            for _, plr in ipairs(Players:GetPlayers()) do
                if plr ~= localPlayer and getTeam(plr) == "Toddler" then
                    local targetRoot = getRootPart(plr.Character)

                    if targetRoot then
                        local distance = (myRoot.Position - targetRoot.Position).Magnitude

                        if distance < nearestDistance then
                            nearestDistance = distance
                            nearestRoot = targetRoot
                        end
                    end
                end
            end

            return nearestRoot
        end


        local player = Players.LocalPlayer
        local character = player.Character or player.CharacterAdded:Wait()
        local humanoid = character:WaitForChild("Humanoid")
        local root = character:WaitForChild("HumanoidRootPart")

        local stepDistance = 0.6
        local heightCheck = 3
        local cooldown = 0.015

        local lastTP = 0

        local params = RaycastParams.new()
        params.FilterDescendantsInstances = {character}
        params.FilterType = Enum.RaycastFilterType.Exclude

        RunService.Heartbeat:Connect(function(dt)
            if not character.Parent then
                return
            end

            if humanoid.MoveDirection.Magnitude < 0.1 then
                return
            end

            if tick() - lastTP < cooldown then
                return
            end
            lastTP = tick()

            local direction = humanoid.MoveDirection.Unit
            local newPos = root.Position + direction * stepDistance

            local result = workspace:Raycast(newPos, Vector3.new(0, -heightCheck, 0), params)
            if result then
                newPos = Vector3.new(newPos.X, result.Position.Y + 2.5, newPos.Z)
            end

            root.CFrame = CFrame.new(newPos, newPos + root.CFrame.LookVector)
        end)

    end
})

GrannyTab:CreateButton({
    Name = "Granny Anti-Ragdoll (Never pair with wfling) (death)",
    Callback = function()

        local Players = game:GetService("Players")
        local ReplicatedStorage = game:GetService("ReplicatedStorage")
        local RunService = game:GetService("RunService")

        local player = Players.LocalPlayer
        local ragdollRemote = ReplicatedStorage:WaitForChild("RagdollRemotes"):WaitForChild("Ragdoll")

        local freezeConnection
        local frozenParts = {}

        local function freezeCharacter()
            local character = player.Character
            if not character then return end

            frozenParts = {}

            for _, obj in ipairs(character:GetDescendants()) do
                if obj:IsA("BasePart") then
                    frozenParts[obj] = obj.CFrame
                end
            end

            freezeConnection = RunService.RenderStepped:Connect(function()
                for part, cf in pairs(frozenParts) do
                    if part and part.Parent then
                        part.CFrame = cf
                        part.AssemblyLinearVelocity = Vector3.zero
                        part.AssemblyAngularVelocity = Vector3.zero
                    end
                end
            end)
        end

        local function unfreezeCharacter()
            if freezeConnection then
                freezeConnection:Disconnect()
                freezeConnection = nil
            end

            table.clear(frozenParts)
        end

        ragdollRemote.OnClientEvent:Connect(function()
            freezeCharacter()

            task.wait(5)

            unfreezeCharacter()
        end)

    end
})

GrannyTab:CreateLabel("Only use this on big maps for best results (Bigger = Better)")

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local lp = Players.LocalPlayer
local char = lp.Character or lp.CharacterAdded:Wait()
local root = char:WaitForChild("HumanoidRootPart")
 
lp.CharacterAdded:Connect(function(newChar)
    char = newChar
    root = newChar:WaitForChild("HumanoidRootPart")
end)

local AvoidEnabled = false
local AvoidConn = nil

local DETECTION_RADIUS = 50
local SPEED = 75

local PRIORITY_DIST = 50
local EMERGENCY_DIST = 45
local TELEPORT_DIST = 40

local lastTeleport = 0
local TELEPORT_COOLDOWN = 1.2

local graceTime = 0
local GRACE_DURATION = 0.6

local lastPos = root.Position
local stuckTime = 0

local moveDir = Vector3.zero
local recentTeleports = {}
local MAX_TELEPORT_MEMORY = 6
local REPEAT_RADIUS = 12

local function wasRecentlyUsed(pos)
    for _, p in ipairs(recentTeleports) do
        if (p - pos).Magnitude < REPEAT_RADIUS then
            return true
        end
    end
    return false
end

local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Exclude
rayParams.FilterDescendantsInstances = {char}

local function getTarget()
    local best, bestDist = nil, DETECTION_RADIUS
    local priority, priorityDist = nil, PRIORITY_DIST

    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= lp then
            local status = p:FindFirstChild("Status")
            local team = status and status:FindFirstChild("Team")

            if team and tostring(team.Value) == "Toddler" then
                local pr = p.Character and p.Character:FindFirstChild("HumanoidRootPart")

                if pr then
                    local dist = (pr.Position - root.Position).Magnitude

                    if dist <= PRIORITY_DIST then
                        if not priority or dist < priorityDist then
                            priority, priorityDist = pr, dist
                        end
                    end

                    if dist < bestDist then
                        best, bestDist = pr, dist
                    end
                end
            end
        end
    end

    return priority or best, bestDist
end

local function teleportEscape()
    if tick() - lastTeleport < TELEPORT_COOLDOWN then return end

    local origin = root.Position

    local dirs = {
        Vector3.new(1,0,0),
        Vector3.new(-1,0,0),
        Vector3.new(0,0,1),
        Vector3.new(0,0,-1),
        Vector3.new(1,0,1).Unit,
        Vector3.new(-1,0,1).Unit,
    }

    local bestPos
    local bestScore = -math.huge
    local chosenDir

    for _, d in ipairs(dirs) do
        local hit = Workspace:Raycast(origin, d * TELEPORT_DIST, rayParams)
        local score = hit and (hit.Position - origin).Magnitude or TELEPORT_DIST

        local candidate = origin + d * math.min(score, TELEPORT_DIST)

        if not wasRecentlyUsed(candidate) then
            if score > bestScore then
                bestScore = score
                bestPos = candidate
                chosenDir = d
            end
        end
    end

    if not bestPos then
        bestPos = origin + Vector3.new(0,0,TELEPORT_DIST)
        chosenDir = Vector3.new(0,0,1)
    end

    root.CFrame = CFrame.new(bestPos)

    table.insert(recentTeleports, bestPos)
    if #recentTeleports > MAX_TELEPORT_MEMORY then
        table.remove(recentTeleports, 1)
    end

    graceTime = GRACE_DURATION
    lastTeleport = tick()
    stuckTime = 0
    lastPos = bestPos
    moveDir = chosenDir or moveDir
end

local function step(dt)
    if not root or not root.Parent then return end

    local target, dist = getTarget()
    if not target then return end

    if graceTime > 0 then
        graceTime -= dt
        return
    end

    if dist <= EMERGENCY_DIST then
        teleportEscape()
        return
    end

    local toTarget = (target.Position - root.Position)
    if toTarget.Magnitude < 0.1 then return end

    local away = (-toTarget).Unit
    local side = Vector3.new(-away.Z, 0, away.X)

    local desired =
        away * 1.2 +
        side * 0.4 +
        moveDir * 0.6

    local dir = desired.Unit

    moveDir = moveDir:Lerp(dir, 0.12)
    if moveDir.Magnitude > 0 then
        moveDir = moveDir.Unit
    end

    local speed = SPEED * math.clamp(25 / math.max(dist, 1), 1, 2)

    local pos = root.Position + moveDir * speed * dt
    local cf = CFrame.lookAt(pos, pos + moveDir)

    root.CFrame = root.CFrame:Lerp(cf, 1 - math.exp(-12 * dt))

    local moved = (root.Position - lastPos).Magnitude

    if moved < 0.08 then
        stuckTime += dt
    else
        stuckTime = math.max(stuckTime - dt * 2, 0)
    end

    lastPos = root.Position

    if stuckTime > 0.8 then
        teleportEscape()
        stuckTime = 0
    end
end

local function setAvoid(state)
    AvoidEnabled = state

    if AvoidConn then
        AvoidConn:Disconnect()
        AvoidConn = nil
    end

    if not state then return end

    AvoidConn = RunService.Heartbeat:Connect(function(dt)
        if AvoidEnabled then
            step(dt)
        end
    end)
end

GrannyTab:CreateKeybind({
    Name = "Auto Avoid Toddler (Granny)",
    CurrentKeybind = "R",
    HoldToInteract = false,
    Flag = "AutoAvoidGranny",
    Callback = function()
        setAvoid(not AvoidEnabled)

        Rayfield:Notify({
            Title = "Auto Avoid Toddler",
            Content = AvoidEnabled and "Enabled" or "Disabled",
            Duration = 4
        })
    end
})

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local lp = Players.LocalPlayer
local char = lp.Character or lp.CharacterAdded:Wait()
local root = char:WaitForChild("HumanoidRootPart")

lp.CharacterAdded:Connect(function(newChar)
    char = newChar
    root = newChar:WaitForChild("HumanoidRootPart")
end)

local AvoidEnabled = false
local AvoidConn = nil

local DETECTION_RADIUS = 50
local SPEED = 75

local PRIORITY_DIST = 50
local EMERGENCY_DIST = 45
local TELEPORT_DIST = 40

local lastTeleport = 0
local TELEPORT_COOLDOWN = 1.2

local graceTime = 0
local GRACE_DURATION = 0.6

local lastPos = root.Position
local stuckTime = 0

local moveDir = Vector3.zero
local recentTeleports = {}
local MAX_TELEPORT_MEMORY = 6
local REPEAT_RADIUS = 12

local function wasRecentlyUsed(pos)
    for _, p in ipairs(recentTeleports) do
        if (p - pos).Magnitude < REPEAT_RADIUS then
            return true
        end
    end
    return false
end

local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Exclude
rayParams.FilterDescendantsInstances = {char}

local function getTarget()
    local best, bestDist = nil, DETECTION_RADIUS
    local priority, priorityDist = nil, PRIORITY_DIST

    for _, p in ipairs(Players:GetPlayers()) do
        if p ~= lp then
            local status = p:FindFirstChild("Status")
            local team = status and status:FindFirstChild("Team")

            if team and tostring(team.Value) == "Toddler" then
                local pr = p.Character and p.Character:FindFirstChild("HumanoidRootPart")

                if pr then
                    local dist = (pr.Position - root.Position).Magnitude

                    if dist <= PRIORITY_DIST then
                        if not priority or dist < priorityDist then
                            priority, priorityDist = pr, dist
                        end
                    end

                    if dist < bestDist then
                        best, bestDist = pr, dist
                    end
                end
            end
        end
    end

    return priority or best, bestDist
end

local function teleportEscape()
    if tick() - lastTeleport < TELEPORT_COOLDOWN then return end

    local origin = root.Position

    local dirs = {
        Vector3.new(1,0,0),
        Vector3.new(-1,0,0),
        Vector3.new(0,0,1),
        Vector3.new(0,0,-1),
        Vector3.new(1,0,1).Unit,
        Vector3.new(-1,0,1).Unit,
    }

    local bestPos
    local bestScore = -math.huge
    local chosenDir

    for _, d in ipairs(dirs) do
        local hit = Workspace:Raycast(origin, d * TELEPORT_DIST, rayParams)
        local score = hit and (hit.Position - origin).Magnitude or TELEPORT_DIST

        local candidate = origin + d * math.min(score, TELEPORT_DIST)

        if not wasRecentlyUsed(candidate) then
            if score > bestScore then
                bestScore = score
                bestPos = candidate
                chosenDir = d
            end
        end
    end

    if not bestPos then
        bestPos = origin + Vector3.new(0,0,TELEPORT_DIST)
        chosenDir = Vector3.new(0,0,1)
    end

    root.CFrame = CFrame.new(bestPos)

    table.insert(recentTeleports, bestPos)
    if #recentTeleports > MAX_TELEPORT_MEMORY then
        table.remove(recentTeleports, 1)
    end

    graceTime = GRACE_DURATION
    lastTeleport = tick()
    stuckTime = 0
    lastPos = bestPos
    moveDir = chosenDir or moveDir
end

local function step(dt)
    if not root or not root.Parent then return end

    local target, dist = getTarget()
    if not target then return end

    if graceTime > 0 then
        graceTime -= dt
        return
    end

    if dist <= EMERGENCY_DIST then
        teleportEscape()
        return
    end

    local toTarget = (target.Position - root.Position)
    if toTarget.Magnitude < 0.1 then return end

    local away = (-toTarget).Unit
    local side = Vector3.new(-away.Z, 0, away.X)

    local desired =
        away * 1.2 +
        side * 0.4 +
        moveDir * 0.6

    local dir = desired.Unit

    moveDir = moveDir:Lerp(dir, 0.12)
    if moveDir.Magnitude > 0 then
        moveDir = moveDir.Unit
    end

    local speed = SPEED * math.clamp(25 / math.max(dist, 1), 1, 2)

    local pos = root.Position + moveDir * speed * dt
    local cf = CFrame.lookAt(pos, pos + moveDir)

    root.CFrame = root.CFrame:Lerp(cf, 1 - math.exp(-12 * dt))

    local moved = (root.Position - lastPos).Magnitude

    if moved < 0.08 then
        stuckTime += dt
    else
        stuckTime = math.max(stuckTime - dt * 2, 0)
    end

    lastPos = root.Position

    if stuckTime > 0.8 then
        teleportEscape()
        stuckTime = 0
    end
end

local function setAvoid(state)
    AvoidEnabled = state

    if AvoidConn then
        AvoidConn:Disconnect()
        AvoidConn = nil
    end

    if not state then return end

    AvoidConn = RunService.Heartbeat:Connect(function(dt)
        if AvoidEnabled then
            step(dt)
        end
    end)
end

setAvoid(false)



GrannyTab:CreateLabel("Kick Toddler before tp fling")

GrannyTab:CreateButton({
    Name = "Teleport to nearest Toddler once",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")

        local localPlayer = Players.LocalPlayer

        local function getRootPart(character)
            if not character then return nil end
            return character:FindFirstChild("HumanoidRootPart")
        end

        local function getTeam(player)
            local status = player:FindFirstChild("Status")
            if not status then return nil end

            local team = status:FindFirstChild("Team")
            if team and team:IsA("StringValue") then
                return team.Value
            end

            return nil
        end

        local function getNearestToddler()
            local myChar = localPlayer.Character
            local myRoot = getRootPart(myChar)
            if not myRoot then return nil end

            local closestPlayer = nil
            local closestDist = math.huge

            for _, plr in ipairs(Players:GetPlayers()) do
                if plr ~= localPlayer and getTeam(plr) == "Toddler" then
                    local root = getRootPart(plr.Character)

                    if root then
                        local dist = (root.Position - myRoot.Position).Magnitude

                        if dist < closestDist then
                            closestDist = dist
                            closestPlayer = plr
                        end
                    end
                end
            end

            return closestPlayer
        end

        local function teleportToNearestToddler()
            local myChar = localPlayer.Character
            local myRoot = getRootPart(myChar)
            if not myRoot then return end

            local targetPlayer = getNearestToddler()
            if not targetPlayer then return end

            local targetRoot = getRootPart(targetPlayer.Character)
            if not targetRoot then return end

            local originalCFrame = myRoot.CFrame

            local followTime = 0.5
            local endTime = tick() + followTime

            while tick() < endTime do
                myChar = localPlayer.Character
                myRoot = getRootPart(myChar)

                targetRoot = getRootPart(targetPlayer.Character)

                if myRoot and targetRoot then
                    myRoot.CFrame = targetRoot.CFrame
                else
                    break
                end

                RunService.Heartbeat:Wait()
            end

            myChar = localPlayer.Character
            myRoot = getRootPart(myChar)

            if myRoot then
                myRoot.CFrame = originalCFrame
            end
        end

        teleportToNearestToddler()

    end
})


GrannyTab:CreateButton({
    Name = "WalkFling",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local LocalPlayer = Players.LocalPlayer
        local Character = LocalPlayer.Character
        local Root = Character:WaitForChild("HumanoidRootPart")
        local Humanoid = Character:WaitForChild("Humanoid")

        walkflinging = true

        Humanoid.Died:Connect(function()
            walkflinging = false
        end)

        game:GetService("UserInputService").JumpRequest:Connect(function()
            Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
        end)

        Root.CanCollide = false
        Humanoid:ChangeState(11)

        repeat
            RunService.Heartbeat:Wait()

            local vel = Root.Velocity

            Root.Velocity = vel * 10000 + Vector3.new(0, 10000, 0)

            RunService.RenderStepped:Wait()
            Root.Velocity = vel

            RunService.Stepped:Wait()
            Root.Velocity = vel + Vector3.new(0, 0.1, 0)

        until walkflinging == false

    end
})

local TeleportTab = Window:CreateTab("Teleport")

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local inputName = ""
local loopTP = false
local proxTP = false

TeleportTab:CreateInput({
    Name = "Player Name",
    PlaceholderText = "(Doesn't have to be full name) Example: 'blox' or 'pla'",
    RemoveTextAfterFocusLost = false,
    Callback = function(txt)
        inputName = txt
    end
})

local function findPlayer(partial)
    partial = string.lower(partial)

    for _, player in ipairs(Players:GetPlayers()) do
        local name = string.lower(player.Name)
        local display = string.lower(player.DisplayName)

        if name:sub(1, #partial) == partial or display:sub(1, #partial) == partial then
            return player
        end
    end

    for _, player in ipairs(Players:GetPlayers()) do
        local name = string.lower(player.Name)
        local display = string.lower(player.DisplayName)

        if string.find(name, partial) or string.find(display, partial) then
            return player
        end
    end

    return nil
end

local function teleportToPlayer(player)
    local char = LocalPlayer.Character
    local targetChar = player.Character

    if not char or not targetChar then return end

    local hrp = char:FindFirstChild("HumanoidRootPart")
    local targetHRP = targetChar:FindFirstChild("HumanoidRootPart")

    if hrp and targetHRP then
        hrp.CFrame = targetHRP.CFrame
    end
end

local function getDistance(player)
    local char = LocalPlayer.Character
    local targetChar = player.Character

    if not char or not targetChar then return math.huge end

    local hrp = char:FindFirstChild("HumanoidRootPart")
    local targetHRP = targetChar:FindFirstChild("HumanoidRootPart")

    if not hrp or not targetHRP then return math.huge end

    return (hrp.Position - targetHRP.Position).Magnitude
end

TeleportTab:CreateSection("Press Enter when you're done typing")

TeleportTab:CreateButton({
    Name = "Teleport once",
    Callback = function()
        if inputName == "" then return end

        local target = findPlayer(inputName)
        if target then
            teleportToPlayer(target)
        end
    end
})

TeleportTab:CreateToggle({
    Name = "Loop Teleport",
    Callback = function(state)
        loopTP = state

        if loopTP then
            task.spawn(function()
                while loopTP do
                    local target = findPlayer(inputName)
                    if target then
                        teleportToPlayer(target)
                    end
                    task.wait(0.1)
                end
            end)
        end
    end
})

TeleportTab:CreateToggle({
    Name = "Tp/Fling Aura for specific player (Enable wfling first)",
    Callback = function(state)
        proxTP = state

        if proxTP then
            task.spawn(function()
                while proxTP do
                    local target = findPlayer(inputName)

                    if target then
                        local dist = getDistance(target)

                        if dist <= 10 then
                            teleportToPlayer(target)
                            task.wait(0.33)
                        end
                    end

                    task.wait(0.1)
                end
            end)
        end
    end
})


TeleportTab:CreateButton({
    Name = "WalkFling",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local LocalPlayer = Players.LocalPlayer
        local Character = LocalPlayer.Character
        local Root = Character:WaitForChild("HumanoidRootPart")
        local Humanoid = Character:WaitForChild("Humanoid")

        walkflinging = true

        Humanoid.Died:Connect(function()
            walkflinging = false
        end)

        game:GetService("UserInputService").JumpRequest:Connect(function()
            Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
        end)

        Root.CanCollide = false
        Humanoid:ChangeState(11)

        repeat
            RunService.Heartbeat:Wait()

            local vel = Root.Velocity
            Root.Velocity = vel * 10000 + Vector3.new(0, 10000, 0)

            RunService.RenderStepped:Wait()
            Root.Velocity = vel

            RunService.Stepped:Wait()
            Root.Velocity = vel + Vector3.new(0, 0.1, 0)

        until walkflinging == false

    end
})
 
TeleportTab:CreateButton({
    Name = "WalkFling Lite (Doesn't Instant Kill)",
    Callback = function()

        local Players = game:GetService("Players")
        local RunService = game:GetService("RunService")
        local LocalPlayer = Players.LocalPlayer
        local Character = LocalPlayer.Character
        local Root = Character:WaitForChild("HumanoidRootPart")
        local Humanoid = Character:WaitForChild("Humanoid")

        walkflinging = true

        Humanoid.Died:Connect(function()
            walkflinging = false
        end)

        game:GetService("UserInputService").JumpRequest:Connect(function()
            Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
        end)

        Root.CanCollide = false
        Humanoid:ChangeState(11)

        repeat
            RunService.Heartbeat:Wait()

            local vel = Root.Velocity
            Root.Velocity = vel * 50 + Vector3.new(0, 10, 0)

            RunService.RenderStepped:Wait()
            Root.Velocity = vel

            RunService.Stepped:Wait()
            Root.Velocity = vel + Vector3.new(0, 0.1, 0)

        until walkflinging == false

    end
})

local RoundInfoTab = Window:CreateTab("Round Info")

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Stats = game:GetService("Stats")

local GrannyLabel = RoundInfoTab:CreateLabel("Granny: Loading...")
local MapLabel = RoundInfoTab:CreateLabel("Map: Loading...")
local GamemodeLabel = RoundInfoTab:CreateLabel("Gamemode: Loading...")
local PingLabel = RoundInfoTab:CreateLabel("Ping: Loading...")

local function safeFind(func)
    local ok, result = pcall(func)
    return ok and result or nil
end

local RoundData = safeFind(function()
    return ReplicatedStorage:WaitForChild("RoundData", 5)
end)

local GrannyValue, MapValue, GamemodeValue
if RoundData then
    GrannyValue = safeFind(function() return RoundData:WaitForChild("Granny", 5) end)
    MapValue = safeFind(function() return RoundData:WaitForChild("Map", 5) end)
    GamemodeValue = safeFind(function() return RoundData:WaitForChild("Gamemode", 5) end)
end

local function updateLabel(label, valueObj, prefix)
    if not valueObj then
        label:Set(prefix .. ": Not Found")
        return
    end
    local ok, val = pcall(function() return tostring(valueObj.Value) end)
    label:Set(prefix .. ": " .. (ok and val or "Unknown"))
end

updateLabel(GrannyLabel, GrannyValue, "Granny")
updateLabel(MapLabel, MapValue, "Map")
updateLabel(GamemodeLabel, GamemodeValue, "Gamemode")

if GrannyValue then
    GrannyValue:GetPropertyChangedSignal("Value"):Connect(function()
        updateLabel(GrannyLabel, GrannyValue, "Granny")
    end)
end
if MapValue then
    MapValue:GetPropertyChangedSignal("Value"):Connect(function()
        updateLabel(MapLabel, MapValue, "Map")
    end)
end
if GamemodeValue then
    GamemodeValue:GetPropertyChangedSignal("Value"):Connect(function()
        updateLabel(GamemodeLabel, GamemodeValue, "Gamemode")
    end)
end

task.spawn(function()
    while task.wait(1) do
        local pingStat = Stats.Network.ServerStatsItem["Data Ping"]
        if pingStat then
            local ping = math.floor(pingStat:GetValue())
            PingLabel:Set("Ping: " .. ping .. " ms")
        else
            PingLabel:Set("Ping: Unknown")
        end
    end
end)

local function safeGetValue(obj)
    local ok, val = pcall(function() return obj and obj.Value end)
    return ok and val or "nil"
end

local function formatEntry(name, value)
    return name .. ": " .. tostring(value)
end

local StatsSection = RoundInfoTab:CreateSection("Nil = false")

local ColA = RoundInfoTab:CreateLabel("Loading...")
local ColB = RoundInfoTab:CreateLabel("Loading...")
local ColC = RoundInfoTab:CreateLabel("Loading...")
local ColD = RoundInfoTab:CreateLabel("Loading...")
local ColE = RoundInfoTab:CreateLabel("Loading...")
local ColF = RoundInfoTab:CreateLabel("Loading...")
local ColG = RoundInfoTab:CreateLabel("Loading...")
local ColH = RoundInfoTab:CreateLabel("Loading...")

local function updateGrannyStats()
    local grannyVal = GrannyValue and GrannyValue.Value
    local plr

    if typeof(grannyVal) == "string" then
        plr = Players:FindFirstChild(grannyVal)
    elseif typeof(grannyVal) == "Instance" then
        plr = grannyVal
    end

    if not plr then
        ColA:Set("Status: Unknown")
        ColB:Set("Owned Trolls: Unknown")
        ColC:Set("Gamepasses: Unknown")
        ColD:Set("Data: Unknown")
        return
    end

    local s  = plr:FindFirstChild("Status")
    local ot = plr:FindFirstChild("OwnedTrolls")
    local gp = plr:FindFirstChild("Gamepasses")
    local d  = plr:FindFirstChild("Data")

    ColA:Set(table.concat({
        formatEntry("Energy", safeGetValue(s and s:FindFirstChild("Energy"))),
        formatEntry("IsAdmin", safeGetValue(s and s:FindFirstChild("IsAdmin"))),
    }, "\n"))

    ColB:Set(table.concat({
        formatEntry("ZombieApocalypse", safeGetValue(ot and ot:FindFirstChild("ZombieApocalypse"))),
        formatEntry("FlyingBazooka", safeGetValue(ot and ot:FindFirstChild("FlyingBazooka"))),
        formatEntry("FireLighter", safeGetValue(ot and ot:FindFirstChild("FireLighter"))),
    }, "\n"))

    ColC:Set(table.concat({
        formatEntry("Clones", safeGetValue(ot and ot:FindFirstChild("Clones"))),
        formatEntry("BubbleGun", safeGetValue(ot and ot:FindFirstChild("BubbleGun"))),
    }, "\n"))

    ColD:Set(table.concat({
        formatEntry("Vip", safeGetValue(gp and gp:FindFirstChild("Vip"))),
        formatEntry("ExtraKeys", safeGetValue(gp and gp:FindFirstChild("ExtraKeys"))),
        formatEntry("DoubleVote", safeGetValue(gp and gp:FindFirstChild("DoubleVote"))),
    }, "\n"))

    ColE:Set(table.concat({
        formatEntry("DoubleGranny", safeGetValue(gp and gp:FindFirstChild("DoubleGranny"))),
        formatEntry("DeathSound", safeGetValue(gp and gp:FindFirstChild("DeathSound"))),
    }, "\n"))

    ColF:Set(table.concat({
        formatEntry("Visits", safeGetValue(d and d:FindFirstChild("Visits"))),
        formatEntry("ToddlerWins", safeGetValue(d and d:FindFirstChild("ToddlerWins"))),
        formatEntry("TimePlayed", safeGetValue(d and d:FindFirstChild("TimePlayed"))),
    }, "\n"))

    ColG:Set(table.concat({
        formatEntry("ToddlerRoundsPlayed", safeGetValue(d and d:FindFirstChild("ToddlerRoundsPlayed"))),
        formatEntry("RobuxDonated", safeGetValue(d and d:FindFirstChild("RobuxDonated"))),
    }, "\n"))

    ColH:Set(table.concat({
        formatEntry("Money", safeGetValue(d and d:FindFirstChild("Money"))),
        formatEntry("GrannyWins", safeGetValue(d and d:FindFirstChild("GrannyWins"))),
        formatEntry("Exp", safeGetValue(d and d:FindFirstChild("Exp"))),
    }, "\n"))
end

updateGrannyStats()

if GrannyValue then
    GrannyValue:GetPropertyChangedSignal("Value"):Connect(updateGrannyStats)
end



local UpdatesTab = Window:CreateTab("Updates")

UpdatesTab:CreateSection("Updated UI + Mobile Support")
UpdatesTab:CreateSection("Thank you for using my script")

local DiscordTab = Window:CreateTab("Discord")

DiscordTab:CreateButton({
    Name = "Click to copy discord",
    Callback = function()

        local discordLink = "https://discord.gg/fcM53Z6C2c"

        local safeSetClipboard = typeof(setclipboard) == "function"

        if safeSetClipboard then
            local success, err = pcall(function()
                setclipboard(discordLink)
            end)

            if success then
                print("Discord link copied to clipboard.")
            else
                warn("Failed to copy to clipboard: " .. tostring(err))
            end
        else
            warn("setclipboard() is not available in this environment.")
        end

    end
})

