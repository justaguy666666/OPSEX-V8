local Parser=require("prometheus.parser")
local Unparser=require("prometheus.unparser")
local V=require("prometheus.v3")
local Report=require("prometheus.v3.report")
local E=require("prometheus.enums")

local M={}

function M.apply(source,luaVersion,pretty,seed,preset)
local c=V.Config.create({
preset=preset or "v3-standard",
seed=seed or 0
})

  
c.LuaVersion=luaVersion or E.LuaVersion.LuaU
c.PrettyPrint=pretty or false

local ast=Parser:new({
    LuaVersion=c.LuaVersion
}):parse(source)

local out,ctx=V.apply(ast,c)

ctx.report=Report.create(ctx)

return Unparser:new({
    LuaVersion=c.LuaVersion,
    PrettyPrint=c.PrettyPrint
}):unparse(out),ctx
  

end

M.Report=Report

return M
