 
 
 
local Ast = require("prometheus.ast")

local INTERNAL = {
    string=true, char=true, format=true, reverse=true, sub=true, rep=true,
    unpack=true, type=true, select=true, setmetatable=true, getmetatable=true,
    tostring=true, tonumber=true, pairs=true, ipairs=true, next=true,
    error=true, pcall=true, xpcall=true, assert=true, rawget=true, rawset=true,
    rawequal=true, collectgarbage=true, require=true, print=true,
    _G=true, _ENV=true, __index=true, __newindex=true, __gc=true, __len=true,
}

return function(self, value)
    value = tostring(value or "")
    if value == "" or INTERNAL[value] then
        return Ast.StringExpression(value)
    end

    local globalScope = self.scope
    local stringScope, stringId = globalScope:resolveGlobal("string")
    assert(stringScope and stringId, "VM string encoding: unable to resolve global 'string'")
    local charCall = Ast.IndexExpression(
        Ast.VariableExpression(stringScope, stringId),
        Ast.StringExpression("char")
    )
    local result = nil
    local offset = 1
    while offset <= #value do
        local args = {}
        local stopAt = math.min(#value, offset + 62)
        for i = offset, stopAt do
            args[#args + 1] = Ast.NumberExpression(string.byte(value, i))
        end
        local chunk = Ast.FunctionCallExpression(charCall, args)
        result = result and Ast.StrCatExpression(result, chunk) or chunk
        offset = stopAt + 1
    end
    return result or Ast.StringExpression("")
end
