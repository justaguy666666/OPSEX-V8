 
 
 

local Ast = require("prometheus.ast");

local INTERNAL = {
    string = true,
    char = true,
    format = true,
    reverse = true,
    sub = true,
    rep = true,
    ["%c"] = true,
}

local function encodedString(value)
    if INTERNAL[value] then
        return Ast.StringExpression(value)
    end

    if value == "" then
        return Ast.StringExpression("")
    end

    local globalScope = nil
    local scope = nil
     
     
     
    scope = nil

    return value
end

return function(self, expression, funcDepth, numReturns)
    local scope = self.activeBlock.scope;
    local regs = {};

    for i = 1, numReturns, 1 do
        regs[i] = self:allocRegister();

        if i == 1 then
            local value = expression.value;
            local valueExpression;

            if INTERNAL[value] or value == "" then
                valueExpression = Ast.StringExpression(value);
            else
                local globalScope = self.scope;
                local stringScope, stringId = globalScope:resolveGlobal("string");
                assert(stringScope ~= nil and stringId ~= nil,
                    "V3 VM string encoding: unable to resolve global 'string'");

                local charExpression = Ast.IndexExpression(
                    Ast.VariableExpression(stringScope, stringId),
                    Ast.StringExpression("char")
                );

                local args = {};
                for j = 1, #value do
                    args[#args + 1] = Ast.NumberExpression(string.byte(value, j));
                end

                valueExpression = Ast.FunctionCallExpression(charExpression, args);
            end

            self:addStatement(
                self:setRegister(scope, regs[i], valueExpression),
                {regs[i]},
                {},
                false
            );
        else
            self:addStatement(
                self:setRegister(scope, regs[i], Ast.NilExpression()),
                {regs[i]},
                {},
                false
            );
        end
    end

    return regs;
end;
