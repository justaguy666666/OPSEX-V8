 
 
 
 
 

local Ast = require("prometheus.ast");

return function(self, expression, funcDepth, numReturns)
    local scope = self.activeBlock.scope;
    local regs = {};
    for i = 1, numReturns do
        regs[i] = self:allocRegister();
        if i == 1 then
            local fusionId = nil;
            local fusionOnLeft = false;
            local fusionNode = nil;
            if self.v8Mode and self.vmFusionMap and self.vmFusionVar then
                local leftKind = expression.lhs and expression.lhs.kind;
                local rightKind = expression.rhs and expression.rhs.kind;
                if leftKind and self.vmFusionMap[expression.kind] and self.vmFusionMap[expression.kind][leftKind] then
                    local pairId = self.vmFusionMap[expression.kind][leftKind];
                    fusionId = self.vmFusionHandlerMap[pairId].left;
                    fusionOnLeft = true;
                    fusionNode = expression.lhs;
                elseif rightKind and self.vmFusionMap[expression.kind] and self.vmFusionMap[expression.kind][rightKind] then
                    local pairId = self.vmFusionMap[expression.kind][rightKind];
                    fusionId = self.vmFusionHandlerMap[pairId].right;
                    fusionOnLeft = false;
                    fusionNode = expression.rhs;
                end
            end

            if fusionId and fusionNode then
                local aReg, bReg, cReg;
                if fusionOnLeft then
                    aReg = self:compileExpression(fusionNode.lhs, funcDepth, 1)[1];
                    bReg = self:compileExpression(fusionNode.rhs, funcDepth, 1)[1];
                    cReg = self:compileExpression(expression.rhs, funcDepth, 1)[1];
                else
                    aReg = self:compileExpression(expression.lhs, funcDepth, 1)[1];
                    bReg = self:compileExpression(fusionNode.lhs, funcDepth, 1)[1];
                    cReg = self:compileExpression(fusionNode.rhs, funcDepth, 1)[1];
                end

                local aExpr = self:register(scope, aReg);
                local bExpr = self:register(scope, bReg);
                local cExpr = self:register(scope, cReg);
                scope:addReferenceToHigherScope(self.scope, self.vmFusionVar);
                local fusedExpr = Ast.FunctionCallExpression(
                    Ast.IndexExpression(Ast.VariableExpression(self.scope, self.vmFusionVar), Ast.NumberExpression(fusionId)),
                    {aExpr, bExpr, cExpr}
                );
                self:addStatement(self:setRegister(scope, regs[i], fusedExpr), {regs[i]}, {aReg, bReg, cReg}, true);
                self.vmMicroOpCount = (self.vmMicroOpCount or 0) + 1;
                self.vmFusionUseCount = (self.vmFusionUseCount or 0) + 1;
                self:freeRegister(cReg, false);
                self:freeRegister(bReg, false);
                self:freeRegister(aReg, false);
            else
                local lhsReg = self:compileExpression(expression.lhs, funcDepth, 1)[1];
                local rhsReg = self:compileExpression(expression.rhs, funcDepth, 1)[1];

                local lhsExpr = self:register(scope, lhsReg);
                local rhsExpr = self:register(scope, rhsReg);
                local opId = self.vmOpMap and self.vmOpMap[expression.kind];
                local binaryExpr;
                if opId and self.vmOpsVar then
                    scope:addReferenceToHigherScope(self.scope, self.vmOpsVar);
                    binaryExpr = Ast.FunctionCallExpression(
                        Ast.IndexExpression(Ast.VariableExpression(self.scope, self.vmOpsVar), Ast.NumberExpression(opId)),
                        {lhsExpr, rhsExpr}
                    );
                    self.vmMicroOpCount = (self.vmMicroOpCount or 0) + 1;
                else
                    binaryExpr = Ast[expression.kind](lhsExpr, rhsExpr);
                end
                self:addStatement(self:setRegister(scope, regs[i], binaryExpr), {regs[i]}, {lhsReg, rhsReg}, true);
                self:freeRegister(rhsReg, false);
                self:freeRegister(lhsReg, false);
            end
        else
            self:addStatement(self:setRegister(scope, regs[i], Ast.NilExpression()), {regs[i]}, {}, false);
        end
    end
    return regs;
end;
