local Ast = require("prometheus.ast");

return function(self, expression, funcDepth, numReturns)
    local scope = self.activeBlock.scope;
    local regs = {};
    for i = 1, numReturns do
        regs[i] = self:allocRegister();
        if i == 1 then
            local rhsReg = self:compileExpression(expression.rhs, funcDepth, 1)[1];
            local rhsExpr = self:register(scope, rhsReg);
            local opId = self.vmOpMap and self.vmOpMap[Ast.AstKind.LenExpression];
            local value;
            if opId and self.vmOpsVar then
                scope:addReferenceToHigherScope(self.scope, self.vmOpsVar);
                value = Ast.FunctionCallExpression(
                    Ast.IndexExpression(Ast.VariableExpression(self.scope, self.vmOpsVar), Ast.NumberExpression(opId)),
                    {rhsExpr}
                );
                self.vmMicroOpCount = (self.vmMicroOpCount or 0) + 1;
            else
                value = Ast.LenExpression(rhsExpr);
            end
            self:addStatement(self:setRegister(scope, regs[i], value), {regs[i]}, {rhsReg}, true);
            self:freeRegister(rhsReg, false);
        else
            self:addStatement(self:setRegister(scope, regs[i], Ast.NilExpression()), {regs[i]}, {}, false);
        end
    end
    return regs;
end;
