 
 
 
 
 

local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");
local util = require("prometheus.util");
local constants = require("prometheus.compiler.constants");
local AstKind = Ast.AstKind;


return function(Compiler)
    local function hasAnyEntries(tbl)
        return type(tbl) == "table" and next(tbl) ~= nil;
    end

    local function unionLookupTables(a, b)
        local out = {};
        for k, v in pairs(a or {}) do
            out[k] = v;
        end
        for k, v in pairs(b or {}) do
            out[k] = v;
        end
        return out;
    end

    local function canMergeParallelAssignmentStatements(statA, statB)
        if type(statA) ~= "table" or type(statB) ~= "table" then
            return false;
        end

        if statA.usesUpvals or statB.usesUpvals then
            return false;
        end

        local a = statA.statement;
        local b = statB.statement;
        if type(a) ~= "table" or type(b) ~= "table" then
            return false;
        end
        if a.kind ~= AstKind.AssignmentStatement or b.kind ~= AstKind.AssignmentStatement then
            return false;
        end

        if type(a.lhs) ~= "table" or type(a.rhs) ~= "table" or type(b.lhs) ~= "table" or type(b.rhs) ~= "table" then
            return false;
        end

        if #a.lhs ~= #a.rhs or #b.lhs ~= #b.rhs then
            return false;
        end

         
        local function hasUnsafeRhs(rhsList)
            for _, rhsExpr in ipairs(rhsList) do
                if type(rhsExpr) ~= "table" then
                    return true;
                end
                local kind = rhsExpr.kind;
                if kind == AstKind.FunctionCallExpression or kind == AstKind.PassSelfFunctionCallExpression or kind == AstKind.VarargExpression then
                    return true;
                end
            end
            return false;
        end
        if hasUnsafeRhs(a.rhs) or hasUnsafeRhs(b.rhs) then
            return false;
        end

        local aReads = type(statA.reads) == "table" and statA.reads or {};
        local aWrites = type(statA.writes) == "table" and statA.writes or {};
        local bReads = type(statB.reads) == "table" and statB.reads or {};
        local bWrites = type(statB.writes) == "table" and statB.writes or {};

         
         
        if not hasAnyEntries(aWrites) and not hasAnyEntries(bWrites) then
            return false;
        end

        for r in pairs(aReads) do
            if bWrites[r] then
                return false;
            end
        end

        for r, b in pairs(aWrites) do
            if bWrites[r] or bReads[r] then
                return false;
            end
        end

        return true;
    end

    local function mergeParallelAssignmentStatements(statA, statB)
        local lhs = {};
        local rhs = {};
        local aLhs, bLhs = statA.statement.lhs, statB.statement.lhs;
        local aRhs, bRhs = statA.statement.rhs, statB.statement.rhs;
        for i = 1, #aLhs do lhs[i] = aLhs[i]; end
        for i = 1, #bLhs do lhs[#aLhs + i] = bLhs[i]; end
        for i = 1, #aRhs do rhs[i] = aRhs[i]; end
        for i = 1, #bRhs do rhs[#aRhs + i] = bRhs[i]; end

        return {
            statement = Ast.AssignmentStatement(lhs, rhs),
            writes = unionLookupTables(statA.writes, statB.writes),
            reads = unionLookupTables(statA.reads, statB.reads),
            usesUpvals = statA.usesUpvals or statB.usesUpvals,
        };
    end

    local function mergeAdjacentParallelAssignments(blockstats)
        local merged = {};
        local i = 1;
        while i <= #blockstats do
            local stat = blockstats[i];
            i = i + 1;

            while i <= #blockstats and canMergeParallelAssignmentStatements(stat, blockstats[i]) do
                stat = mergeParallelAssignmentStatements(stat, blockstats[i]);
                i = i + 1;
            end

            table.insert(merged, stat);
        end
        return merged;
    end

    function Compiler:emitContainerFuncBody()
        local blocks = {};

        util.shuffle(self.blocks);

        for i, block in ipairs(self.blocks) do
            local id = block.id;
            local blockstats = block.statements;

            for i = 2, #blockstats do
                local stat = blockstats[i];
                local reads = stat.reads;
                local writes = stat.writes;
                local maxShift = 0;
                local usesUpvals = stat.usesUpvals;
                for shift = 1, i - 1 do
                    local stat2 = blockstats[i - shift];

                    if stat2.usesUpvals and usesUpvals then
                        break;
                    end

                    local reads2 = stat2.reads;
                    local writes2 = stat2.writes;
                    local f = true;

                    for r, b in pairs(reads2) do
                        if(writes[r]) then
                            f = false;
                            break;
                        end
                    end

                    if f then
                        for r, b in pairs(writes2) do
                            if(writes[r]) then
                                f = false;
                                break;
                            end
                            if(reads[r]) then
                                f = false;
                                break;
                            end
                        end
                    end

                    if not f then
                        break
                    end

                    maxShift = shift;
                end

                local shift = math.random(0, maxShift);
                for j = 1, shift do
                    blockstats[i - j], blockstats[i - j + 1] = blockstats[i - j + 1], blockstats[i - j];
                end
            end

            local mergedBlockStats = mergeAdjacentParallelAssignments(blockstats);
            for _=1, 7 do
                mergedBlockStats = mergeAdjacentParallelAssignments(mergedBlockStats);
            end

            blockstats = {};
            for _, stat in ipairs(mergedBlockStats) do
                table.insert(blockstats, stat.statement);
            end

            local block = { id = id, index = i, block = Ast.Block(blockstats, block.scope) }
             
             
             
             
             
            table.insert(blocks, block);
        end

        table.sort(blocks, function(a, b) return a.id < b.id end);

         
         
        local function buildBlockThresholdCondition(scope, leftId, rightId, useAndOr)
            local bound = math.floor((leftId + rightId) / 2);
            local posExpr = self:pos(scope);
            local boundExpr = Ast.NumberExpression(bound);

            local function branchCall(kind, lhs, rhs)
                local opId = self.vmBranchOpMap[kind];
                assert(opId, "missing VM branch opcode for " .. tostring(kind));
                scope:addReferenceToHigherScope(self.scope, self.vmBranchOpsVar);
                self.vmBranchMicroOpCount = (self.vmBranchMicroOpCount or 0) + 1;
                return Ast.FunctionCallExpression(
                    Ast.IndexExpression(
                        Ast.VariableExpression(self.scope, self.vmBranchOpsVar),
                        Ast.NumberExpression(opId)
                    ),
                    {lhs, rhs}
                );
            end

            if useAndOr then
                return branchCall(AstKind.LessThanExpression, posExpr, boundExpr);
            else
                local variant = math.random(1, 2);
                if variant == 1 then
                    return branchCall(AstKind.LessThanExpression, posExpr, boundExpr);
                else
                    return branchCall(AstKind.GreaterThanExpression, boundExpr, posExpr);
                end
            end
        end

         
         
         
         
        local buildElseifChain
        local function buildBucketDispatch(tb, pScope)
            local bucketCount = self.v7Mode and math.random(3, 8) or math.random(2, 5)
            local buckets = {}
            for i = 1, bucketCount do buckets[i] = {} end

             
             
             
             
             
            local bucketMul
            local bucketAdd
            if self.v6Mode then
                bucketMul = self.blockIdMul or 1
                bucketAdd = self.blockIdAdd or 0
            else
                bucketMul = 1
                bucketAdd = 0
            end

            for i = 1, #tb do
                local bucket = ((tb[i].id * bucketMul + bucketAdd) % bucketCount) + 1
                buckets[bucket][#buckets[bucket] + 1] = tb[i]
            end

            local function buildExactChain(bucketBlocks, index, scope)
                if index > #bucketBlocks then
                    return Ast.Block({}, Scope:new(scope))
                end

                local ifScope = Scope:new(scope)
                local block = bucketBlocks[index]
                block.block.scope:setParent(ifScope)
                local posExpr = self:pos(ifScope)
                local condition = Ast.FunctionCallExpression(
                    Ast.IndexExpression(
                        Ast.VariableExpression(self.scope, self.vmBranchOpsVar),
                        Ast.NumberExpression(self.vmBranchOpMap[AstKind.EqualsExpression])
                    ),
                    {posExpr, Ast.NumberExpression(block.id)}
                )
                ifScope:addReferenceToHigherScope(self.scope, self.vmBranchOpsVar)
                self.vmBranchMicroOpCount = (self.vmBranchMicroOpCount or 0) + 1

                local elseBody = buildExactChain(bucketBlocks, index + 1, ifScope)
                return Ast.Block({
                    Ast.IfStatement(condition, block.block, {}, elseBody)
                }, ifScope)
            end

            local bucketOrder = {};
            for i = 1, bucketCount do bucketOrder[i] = i end
            if self.v7Mode and (self.vmRepresentationFamily or 1) % 2 == 0 then
                for i = 1, math.floor(bucketCount / 2) do
                    local j = bucketCount - i + 1;
                    bucketOrder[i], bucketOrder[j] = bucketOrder[j], bucketOrder[i]
                end
            end

            local function buildBucketChain(index, scope)
                if index > bucketCount then
                    return Ast.Block({}, Scope:new(scope))
                end

                local bucketIndex = bucketOrder[index]
                local bucketBlocks = buckets[bucketIndex]
                local nextScope = Scope:new(scope)
                local elseBody = buildBucketChain(index + 1, nextScope)

                if #bucketBlocks == 0 then
                    return elseBody
                end

                 
                 
                 
                 
                local bucketBody
                if self.vmDispatchStrategy == 3 and #bucketBlocks > 2 then
                    bucketBody = buildElseifChain(bucketBlocks, 1, #bucketBlocks, nextScope)
                else
                    bucketBody = buildExactChain(bucketBlocks, 1, nextScope)
                end

                local residueBase = self:pos(nextScope)
                local residue = Ast.ModExpression(
                    Ast.AddExpression(
                        Ast.MulExpression(residueBase, Ast.NumberExpression(bucketMul), false),
                        Ast.NumberExpression(bucketAdd), false
                    ),
                    Ast.NumberExpression(bucketCount)
                )
                local condition = Ast.FunctionCallExpression(
                    Ast.IndexExpression(
                        Ast.VariableExpression(self.scope, self.vmBranchOpsVar),
                        Ast.NumberExpression(self.vmBranchOpMap[AstKind.EqualsExpression])
                    ),
                    {residue, Ast.NumberExpression(bucketIndex - 1)}
                )
                nextScope:addReferenceToHigherScope(self.scope, self.vmBranchOpsVar)
                self.vmBranchMicroOpCount = (self.vmBranchMicroOpCount or 0) + 1

                return Ast.Block({
                    Ast.IfStatement(condition, bucketBody, {}, elseBody)
                }, nextScope)
            end

            return buildBucketChain(1, pScope)
        end

         
        buildElseifChain = function(tb, l, r, pScope)
             
            if r < l then
                local emptyScope = Scope:new(pScope);
                return Ast.Block({}, emptyScope);
            end

            local len = r - l + 1;

             
            if len == 1 then
                tb[l].block.scope:setParent(pScope);
                return tb[l].block;
            end

             
             
            local chainLimit = 3 + math.random(0, 2);

             
            if len <= chainLimit then
                local ifScope = Scope:new(pScope);
                local elseifs = {};

                 
                tb[l].block.scope:setParent(ifScope);
                local firstCondition = buildBlockThresholdCondition(ifScope, tb[l].id, tb[l + 1].id, false);
                local firstBlock = tb[l].block;

                 
                for i = l + 1, r - 1 do
                    tb[i].block.scope:setParent(ifScope);
                    local condition = buildBlockThresholdCondition(ifScope, tb[i].id, tb[i + 1].id, false);
                    table.insert(elseifs, {
                        condition = condition,
                        body = tb[i].block
                    });
                end

                 
                tb[r].block.scope:setParent(ifScope);
                local elseBlock = tb[r].block;

                return Ast.Block({
                    Ast.IfStatement(firstCondition, firstBlock, elseifs, elseBlock);
                }, ifScope);
            end

             
             
             
            local halfBias = math.random(0, 1);
            local mid = l + (halfBias == 0 and math.floor(len / 2) or math.ceil(len / 2));
            if mid <= l then mid = l + 1 end
            if mid > r then mid = r end
            local leftMaxId = tb[mid - 1].id;
            local rightMinId = tb[mid].id;
             
             
            local bound = math.floor((leftMaxId + rightMinId) / 2);
            local ifScope = Scope:new(pScope);

            local lBlock = buildElseifChain(tb, l, mid - 1, ifScope);
            local rBlock = buildElseifChain(tb, mid, r, ifScope);

             
            local condStyle = math.random(1, 3);
            local condition;
            local trueBlock, falseBlock;

            local posExpr = self:pos(ifScope);
            local boundExpr = Ast.NumberExpression(bound);
            local function branchCall(kind, lhs, rhs)
                local opId = self.vmBranchOpMap[kind];
                assert(opId, "missing VM branch opcode for " .. tostring(kind));
                ifScope:addReferenceToHigherScope(self.scope, self.vmBranchOpsVar);
                self.vmBranchMicroOpCount = (self.vmBranchMicroOpCount or 0) + 1;
                return Ast.FunctionCallExpression(
                    Ast.IndexExpression(
                        Ast.VariableExpression(self.scope, self.vmBranchOpsVar),
                        Ast.NumberExpression(opId)
                    ),
                    {lhs, rhs}
                );
            end

            if condStyle == 1 then
                condition = branchCall(AstKind.LessThanExpression, posExpr, boundExpr);
                trueBlock, falseBlock = lBlock, rBlock;
            elseif condStyle == 2 then
                condition = branchCall(AstKind.GreaterThanExpression, boundExpr, posExpr);
                trueBlock, falseBlock = lBlock, rBlock;
            else
                condition = branchCall(AstKind.GreaterThanExpression, posExpr, boundExpr);
                trueBlock, falseBlock = rBlock, lBlock;
            end

            return Ast.Block({
                Ast.IfStatement(condition, trueBlock, {}, falseBlock);
            }, ifScope);
        end

        local stats = {}

        local whileBody
        local closureDispatchDeclaration
        local dispatchRouterDeclaration

         
         
         
         
        local dispatchTopology = self.v8Mode and (self.vmDispatchTopology or 1) or 1
        local function addContainerCaptureReferences(scope)
            for containerId = 1, self.containerFuncScope:getMaxId() do
                scope:addReferenceToHigherScope(self.containerFuncScope, containerId)
            end
        end

        local function buildClosureDispatchTopology(withRouter)
            local dispatchEntries = {}
            for _, item in ipairs(blocks) do
                local closureScope = Scope:new(self.containerFuncScope)
                addContainerCaptureReferences(closureScope)
                item.block.scope:setParent(closureScope)
                local fn = Ast.FunctionLiteralExpression({}, item.block)
                dispatchEntries[#dispatchEntries + 1] = Ast.KeyedTableEntry(
                    Ast.NumberExpression(item.id),
                    fn
                )
            end

            local dispatchTable = Ast.TableConstructorExpression(dispatchEntries)
            closureDispatchDeclaration = Ast.LocalVariableDeclaration(
                self.containerFuncScope,
                {self.vmDispatchTableVar},
                {dispatchTable}
            )
            self.containerFuncScope:addReferenceToHigherScope(self.containerFuncScope, self.vmDispatchTableVar)

            local dispatchLookup = Ast.IndexExpression(
                Ast.VariableExpression(self.containerFuncScope, self.vmDispatchTableVar),
                self:pos(self.containerFuncScope)
            )
            local dispatchCall = Ast.FunctionCallStatement(dispatchLookup, {})

            if not withRouter then
                return Ast.Block({dispatchCall}, self.whileScope)
            end

             
             
             
             
            local routerScope = Scope:new(self.containerFuncScope)
            addContainerCaptureReferences(routerScope)
            routerScope:addReferenceToHigherScope(self.containerFuncScope, self.vmDispatchTableVar)
            local routerLookup = Ast.IndexExpression(
                Ast.VariableExpression(self.containerFuncScope, self.vmDispatchTableVar),
                self:pos(routerScope)
            )
            local routerCall = Ast.FunctionCallStatement(routerLookup, {})
            local routerVar = self.containerFuncScope:addVariable()
            dispatchRouterDeclaration = Ast.LocalVariableDeclaration(
                self.containerFuncScope,
                {routerVar},
                {Ast.FunctionLiteralExpression({}, Ast.Block({routerCall}, routerScope))}
            )
            local outerCall = Ast.FunctionCallStatement(
                Ast.VariableExpression(self.containerFuncScope, routerVar),
                {}
            )
            return Ast.Block({outerCall}, self.whileScope)
        end

        if self.v8Mode and dispatchTopology == 3 then
             
            whileBody = buildClosureDispatchTopology(false)
        elseif self.v8Mode and dispatchTopology == 4 then
             
            whileBody = buildClosureDispatchTopology(true)
        elseif self.v8Mode and self.vmExecutionFamily == 4 then
             
             
             
             
             
            local bucketWidth = self.vmExecutionBucketWidth or 3
            local bucketEntries = {}
            local bucketTables = {}
            for bucket = 0, bucketWidth - 1 do
                local entries = {}
                for _, item in ipairs(blocks) do
                    if (item.id % bucketWidth) == bucket then
                        local closureScope = Scope:new(self.containerFuncScope)
                        addContainerCaptureReferences(closureScope)
                        item.block.scope:setParent(closureScope)
                        entries[#entries + 1] = Ast.KeyedTableEntry(
                            Ast.NumberExpression(item.id),
                            Ast.FunctionLiteralExpression({}, item.block)
                        )
                    end
                end
                bucketTables[bucket + 1] = Ast.TableConstructorExpression(entries)
            end
            for bucket = 1, bucketWidth do
                bucketEntries[bucket] = Ast.KeyedTableEntry(
                    Ast.NumberExpression(bucket),
                    bucketTables[bucket]
                )
            end
            closureDispatchDeclaration = Ast.LocalVariableDeclaration(
                self.containerFuncScope,
                {self.vmDispatchTableVar},
                {Ast.TableConstructorExpression(bucketEntries)}
            )
            self.containerFuncScope:addReferenceToHigherScope(self.containerFuncScope, self.vmDispatchTableVar)
            local bucketLookup = Ast.IndexExpression(
                Ast.VariableExpression(self.containerFuncScope, self.vmDispatchTableVar),
                Ast.AddExpression(
                    Ast.ModExpression(self:pos(self.containerFuncScope), Ast.NumberExpression(bucketWidth)),
                    Ast.NumberExpression(1),
                    false
                )
            )
            local exactLookup = Ast.IndexExpression(
                bucketLookup,
                self:pos(self.containerFuncScope)
            )
            whileBody = Ast.Block({Ast.FunctionCallStatement(exactLookup, {})}, self.whileScope)
        elseif self.v8Mode and self.vmExecutionFamily == 5 then
             
             
             
             
            local keyEntries = {}
            local modulus = self.vmExecutionKeyModulus or 2^24
            local mul = self.vmExecutionKeyMul or 1
            local add = self.vmExecutionKeyAdd or 0
            for _, item in ipairs(blocks) do
                local key = (item.id * mul + add) % modulus
                local closureScope = Scope:new(self.containerFuncScope)
                addContainerCaptureReferences(closureScope)
                item.block.scope:setParent(closureScope)
                keyEntries[#keyEntries + 1] = Ast.KeyedTableEntry(
                    Ast.NumberExpression(key),
                    Ast.FunctionLiteralExpression({}, item.block)
                )
            end
            closureDispatchDeclaration = Ast.LocalVariableDeclaration(
                self.containerFuncScope,
                {self.vmDispatchTableVar},
                {Ast.TableConstructorExpression(keyEntries)}
            )
            self.containerFuncScope:addReferenceToHigherScope(self.containerFuncScope, self.vmDispatchTableVar)
            local transformedPos = Ast.ModExpression(
                Ast.AddExpression(
                    Ast.MulExpression(self:pos(self.containerFuncScope), Ast.NumberExpression(mul), false),
                    Ast.NumberExpression(add),
                    false
                ),
                Ast.NumberExpression(modulus)
            )
            whileBody = Ast.Block({
                Ast.FunctionCallStatement(
                    Ast.IndexExpression(
                        Ast.VariableExpression(self.containerFuncScope, self.vmDispatchTableVar),
                        transformedPos
                    ),
                    {}
                )
            }, self.whileScope)
        elseif self.v8Mode and self.vmExecutionFamily == 3 then
             
             
             
            local dispatchEntries = {}
            for _, item in ipairs(blocks) do
                local closureScope = Scope:new(self.containerFuncScope)
                for containerId = 1, self.containerFuncScope:getMaxId() do
                    closureScope:addReferenceToHigherScope(self.containerFuncScope, containerId)
                end
                item.block.scope:setParent(closureScope)
                local fn = Ast.FunctionLiteralExpression({}, item.block)
                dispatchEntries[#dispatchEntries + 1] = Ast.KeyedTableEntry(
                    Ast.NumberExpression(item.id),
                    fn
                )
            end
            local dispatchTable = Ast.TableConstructorExpression(dispatchEntries)
            closureDispatchDeclaration = Ast.LocalVariableDeclaration(
                self.containerFuncScope,
                {self.vmDispatchTableVar},
                {dispatchTable}
            )
            self.containerFuncScope:addReferenceToHigherScope(self.containerFuncScope, self.vmDispatchTableVar)
            whileBody = Ast.Block({
                Ast.FunctionCallStatement(
                    Ast.IndexExpression(
                        Ast.VariableExpression(self.containerFuncScope, self.vmDispatchTableVar),
                        self:pos(self.containerFuncScope)
                    ),
                    {}
                )
            }, self.whileScope)
        elseif self.vmExecutionFamily == 2 then
             
             
             
            if self.vmDispatchStrategy >= 2 then
                whileBody = buildBucketDispatch(blocks, self.containerFuncScope)
            else
                whileBody = buildElseifChain(blocks, 1, #blocks, self.containerFuncScope)
            end
        elseif self.vmDispatchStrategy >= 2 then
            whileBody = buildBucketDispatch(blocks, self.containerFuncScope)
        else
            whileBody = buildElseifChain(blocks, 1, #blocks, self.containerFuncScope)
        end
        if self.whileScope then
             
            self.whileScope:setParent(self.containerFuncScope);
        end

         
         
         
         
        if self.v8Mode and self.vmEntangleModulus and self.vmContextVar then
            self.containerFuncScope:addReferenceToHigherScope(self.scope, self.vmContextVar)
            local entangleRef = Ast.IndexExpression(
                Ast.VariableExpression(self.scope, self.vmContextVar),
                Ast.NumberExpression(self.vmContextKeyMap.entangle)
            )
            local integrityRef = Ast.VariableExpression(self.containerFuncScope, self.vmStateIntegrityVar)
            local posRef = Ast.VariableExpression(self.containerFuncScope, self.posVar)
            local integrityUpdate = Ast.ModExpression(
                Ast.AddExpression(
                    Ast.MulExpression(
                        integrityRef,
                        Ast.NumberExpression(self.vmStateIntegrityMul or 1),
                        false
                    ),
                    Ast.AddExpression(posRef, entangleRef, false),
                    false
                ),
                Ast.NumberExpression(self.vmStateIntegrityModulus or 65536)
            )
            local entangleUpdate = Ast.ModExpression(
                Ast.AddExpression(
                    Ast.MulExpression(
                        entangleRef,
                        Ast.NumberExpression(self.vmEntangleMul),
                        false
                    ),
                    Ast.AddExpression(
                        Ast.VariableExpression(self.containerFuncScope, self.vmStateIntegrityVar),
                        posRef,
                        false
                    ),
                    false
                ),
                Ast.NumberExpression(self.vmEntangleModulus)
            )
            local entanglePrefix = Ast.Block({
                Ast.AssignmentStatement(
                    {Ast.AssignmentVariable(self.containerFuncScope, self.vmStateIntegrityVar)},
                    {integrityUpdate}
                ),
                Ast.AssignmentStatement(
                    {Ast.AssignmentIndexing(
                        Ast.VariableExpression(self.scope, self.vmContextVar),
                        Ast.NumberExpression(self.vmContextKeyMap.entangle)
                    )},
                    {entangleUpdate}
                ),
                whileBody
            }, self.containerFuncScope)
            whileBody = entanglePrefix
        end

        self.whileScope:addReferenceToHigherScope(self.containerFuncScope, self.returnVar, 1);
        self.whileScope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);

         
         
        self.containerFuncScope:addReferenceToHigherScope(self.scope, self.vmBranchOpsVar);
        self.containerFuncScope:addReferenceToHigherScope(self.scope, self.unpackVar);

        local declarations = {
            self.returnVar,
        }

         
         
         
        if self.v5Mode then
     
     
     
else
             
            local registerIds = {};
            for i in pairs(self.registerVars) do
                registerIds[#registerIds + 1] = i;
            end
            table.sort(registerIds);
            for _, i in ipairs(registerIds) do
                local var = self.registerVars[i];
                if(i ~= self.maxRegs) then
                    table.insert(declarations, var);
                end
            end
        end

        if self.v8Mode and self.vmStateFamilyVar then
            local familyEntries = {}
            for i = 1, (self.vmStateFamilyCount or 0) do
                local f = self.vmStateFamilies[i]
                familyEntries[#familyEntries + 1] = Ast.TableEntry(Ast.TableConstructorExpression({
                    Ast.TableEntry(Ast.NumberExpression(f.mul)),
                    Ast.TableEntry(Ast.NumberExpression(f.add)),
                    Ast.TableEntry(Ast.NumberExpression(f.inverse)),
                }))
            end
            table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, {self.vmStateFamilyVar}, {Ast.TableConstructorExpression(familyEntries)}))
        end

        if self.v6Mode and self.vmIntegrityVar then
            self.containerFuncScope:addReferenceToHigherScope(self.containerFuncScope, self.vmIntegrityVar)
            table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, {self.vmIntegrityVar}, {Ast.NumberExpression(self.vmRollingStateInit or 1)}))
        end
        if self.v8Mode and self.vmStateIntegrityVar then
            self.containerFuncScope:addReferenceToHigherScope(self.containerFuncScope, self.vmStateIntegrityVar)
            table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, {self.vmStateIntegrityVar}, {Ast.NumberExpression(self.vmStateIntegrityInit or 1)}))
        end

        if self.v5Mode or (self.v8Mode and self.vmExecutionFamily == 2) then
             
             
            table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, {self.vmStateVar}, {Ast.TableConstructorExpression({})}));
        elseif self.maxUsedRegister >= self.maxRegs then
            table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, {self.registerVars[self.maxRegs]}, {Ast.TableConstructorExpression({})}));
        end

         
         
         
         
        local shuffledDeclarations = util.shuffle(declarations);
        local declarationIndex = 1;
        while declarationIndex <= #shuffledDeclarations do
            local remaining = #shuffledDeclarations - declarationIndex + 1;
            local chunkSize = math.min(remaining, math.random(2, 4));
            local chunk = {};
            for j = 0, chunkSize - 1 do
                chunk[#chunk + 1] = shuffledDeclarations[declarationIndex + j];
            end
            table.insert(stats, Ast.LocalVariableDeclaration(self.containerFuncScope, chunk, {}));
            declarationIndex = declarationIndex + chunkSize;
        end

        if closureDispatchDeclaration then
            table.insert(stats, closureDispatchDeclaration)
        end
        if dispatchRouterDeclaration then
            table.insert(stats, dispatchRouterDeclaration)
        end

        if self.v8Mode and self.vmContextVar then
             
             
             
            table.insert(stats, Ast.AssignmentStatement(
                {Ast.AssignmentIndexing(
                    Ast.VariableExpression(self.scope, self.vmContextVar),
                    Ast.NumberExpression(self.vmContextKeyMap.entangle)
                )},
                {Ast.NumberExpression(self.vmEntangleInit)}
            ));
        end

        table.insert(stats, Ast.WhileStatement(whileBody, Ast.VariableExpression(self.containerFuncScope, self.posVar)));


        table.insert(stats, Ast.AssignmentStatement({
            Ast.AssignmentVariable(self.containerFuncScope, self.posVar)
        }, {
            Ast.LenExpression(Ast.VariableExpression(self.containerFuncScope, self.detectGcCollectVar))
        }));

        table.insert(stats, Ast.ReturnStatement{
            Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.unpackVar), {
                Ast.VariableExpression(self.containerFuncScope, self.returnVar)
            });
        });

        return Ast.Block(stats, self.containerFuncScope);
    end
end
