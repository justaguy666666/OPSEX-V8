 
 
 
 
 

local Ast = require("prometheus.ast");
local constants = require("prometheus.compiler.constants");
local randomStrings = require("prometheus.randomStrings");


return function(Compiler)
    function Compiler:freeRegister(id, force)
        if force or not (self.registers[id] == self.VAR_REGISTER) then
            self.usedRegisters = self.usedRegisters - 1;
            self.registers[id] = false
        end
    end

    function Compiler:isVarRegister(id)
        return self.registers[id] == self.VAR_REGISTER;
    end

    function Compiler:allocRegister(isVar)
        self.usedRegisters = self.usedRegisters + 1;

        if not isVar then
            if not self.registers[self.POS_REGISTER] then
                self.registers[self.POS_REGISTER] = true;
                return self.POS_REGISTER;
            end

            if not self.registers[self.RETURN_REGISTER] then
                self.registers[self.RETURN_REGISTER] = true;
                return self.RETURN_REGISTER;
            end
        end

        local id = 0;
        if self.usedRegisters < self.maxRegs * constants.MAX_REGS_MUL then
            repeat
                id = math.random(1, self.maxRegs - 1);
            until not self.registers[id];
        else
            repeat
                id = id + 1;
            until not self.registers[id];
        end

        if id > self.maxUsedRegister then
            self.maxUsedRegister = id;
        end

        if(isVar) then
            self.registers[id] = self.VAR_REGISTER;
        else
            self.registers[id] = true
        end
        return id;
    end

    function Compiler:isUpvalue(scope, id)
        return self.upvalVars[scope] and self.upvalVars[scope][id];
    end

    function Compiler:makeUpvalue(scope, id)
        if(not self.upvalVars[scope]) then
            self.upvalVars[scope] = {}
        end
        self.upvalVars[scope][id] = true;
    end

    function Compiler:getVarRegister(scope, id, functionDepth, potentialId)
        if(not self.registersForVar[scope]) then
            self.registersForVar[scope] = {};
            self.scopeFunctionDepths[scope] = functionDepth;
        end

        local reg = self.registersForVar[scope][id];
        if not reg then
            if potentialId and self.registers[potentialId] ~= self.VAR_REGISTER and potentialId ~= self.POS_REGISTER and potentialId ~= self.RETURN_REGISTER then
                self.registers[potentialId] = self.VAR_REGISTER;
                reg = potentialId;
            else
                reg = self:allocRegister(true);
            end
            self.registersForVar[scope][id] = reg;
        end
        return reg;
    end

    function Compiler:getRegisterVarId(id)
        local varId = self.registerVars[id];
        if not varId then
            varId = self.containerFuncScope:addVariable();
            self.registerVars[id] = varId;
        end
        return varId;
    end

    function Compiler:vmStateSlot(id)
        local modulus = self.vmStateModulus or 65536;
        local mul = self.vmStateMul or 1;
        local add = self.vmStateAdd or 0;
        return ((id * mul + add) % modulus) + 1;
    end

    function Compiler:vmState(scope)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.vmStateVar);
        return Ast.VariableExpression(self.containerFuncScope, self.vmStateVar);
    end

     
     
     
     
    function Compiler:vmStateFamily(scope, familyId)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.vmStateFamilyVar);
        return Ast.IndexExpression(
            Ast.VariableExpression(self.containerFuncScope, self.vmStateFamilyVar),
            Ast.NumberExpression(familyId)
        );
    end

    function Compiler:vmStateEncode(scope, value, familyId)
        if not self.v8Mode then return value end
        local f = familyId or 1;
        local family = self:vmStateFamily(scope, f);
        local mul = Ast.IndexExpression(family, Ast.NumberExpression(1));
        local add = Ast.IndexExpression(family, Ast.NumberExpression(2));
        local payload = Ast.ModExpression(
            Ast.AddExpression(
                Ast.MulExpression(value, mul, false),
                add,
                false
            ),
            Ast.NumberExpression(self.vmStateModulus)
        );
         
        return Ast.AddExpression(
            Ast.AddExpression(
                Ast.MulExpression(payload, Ast.NumberExpression(self.vmStateFamilyCount), false),
                Ast.NumberExpression(f - 1),
                false
            ),
            Ast.NumberExpression(1),
            false
        );
    end

    function Compiler:vmStateEncodeLiteral(value, familyId)
        if not self.v8Mode then return Ast.NumberExpression(value) end
        local f = familyId or 1;
        local family = self.vmStateFamilies[f];
        assert(family, "missing V8 state family " .. tostring(f));
        local payload = ((value * family.mul + family.add) % self.vmStateModulus);
        local token = payload * self.vmStateFamilyCount + (f - 1) + 1;
        return Ast.NumberExpression(token);
    end

    function Compiler:vmStateFamilyForTarget(target)
        if not self.v8Mode then return 1 end
         
         
         
        self.vmStateEdgeCount = (self.vmStateEdgeCount or 0) + 1;
        local family = math.random(1, self.vmStateFamilyCount);
        self.vmStateEdgeFamilies[self.vmStateEdgeCount] = family;
        return family;
    end

    function Compiler:register(scope, id)
        if id == self.POS_REGISTER then
            return self:pos(scope);
        end

        if id == self.RETURN_REGISTER then
            return self:getReturn(scope);
        end

        if self.v5Mode or (self.v8Mode and self.vmExecutionFamily == 2) then
            return Ast.IndexExpression(self:vmState(scope), Ast.NumberExpression(self:vmStateSlot(id)));
        end

        if id < self.maxRegs then
            local vid = self:getRegisterVarId(id);
            scope:addReferenceToHigherScope(self.containerFuncScope, vid);
            return Ast.VariableExpression(self.containerFuncScope, vid);
        end

        local vid = self:getRegisterVarId(self.maxRegs);
        scope:addReferenceToHigherScope(self.containerFuncScope, vid);
        return Ast.IndexExpression(Ast.VariableExpression(self.containerFuncScope, vid), Ast.NumberExpression((id - self.maxRegs) + 1));
    end

    function Compiler:registerList(scope, ids)
        local l = {};
        for i, id in ipairs(ids) do
            table.insert(l, self:register(scope, id));
        end
        return l;
    end

    function Compiler:registerAssignment(scope, id)
        if id == self.POS_REGISTER then
            return self:posAssignment(scope);
        end
        if id == self.RETURN_REGISTER then
            return self:returnAssignment(scope);
        end

        if self.v5Mode or (self.v8Mode and self.vmExecutionFamily == 2) then
            return Ast.AssignmentIndexing(self:vmState(scope), Ast.NumberExpression(self:vmStateSlot(id)));
        end

        if id < self.maxRegs then
            local vid = self:getRegisterVarId(id);
            scope:addReferenceToHigherScope(self.containerFuncScope, vid);
            return Ast.AssignmentVariable(self.containerFuncScope, vid);
        end

        local vid = self:getRegisterVarId(self.maxRegs);
        scope:addReferenceToHigherScope(self.containerFuncScope, vid);
        return Ast.AssignmentIndexing(Ast.VariableExpression(self.containerFuncScope, vid), Ast.NumberExpression((id - self.maxRegs) + 1));
    end

    function Compiler:setRegister(scope, id, val, compundArg)
        if id == self.POS_REGISTER and not compundArg then
            return self:setPosExpression(scope, val);
        end
        if(compundArg) then
            return compundArg(self:registerAssignment(scope, id), val);
        end
        return Ast.AssignmentStatement({
            self:registerAssignment(scope, id)
        }, {
            val
        });
    end

    function Compiler:setRegisters(scope, ids, vals)
        local idStats = {};
        for i, id in ipairs(ids) do
            table.insert(idStats, self:registerAssignment(scope, id));
        end

        return Ast.AssignmentStatement(idStats, vals);
    end

    function Compiler:copyRegisters(scope, to, from)
        local idStats = {};
        local vals = {};
        for i, id in ipairs(to) do
            local fromId = from[i];
            if(fromId ~= id) then
                table.insert(idStats, self:registerAssignment(scope, id));
                table.insert(vals, self:register(scope, fromId));
            end
        end

        if(#idStats > 0 and #vals > 0) then
            return Ast.AssignmentStatement(idStats, vals);
        end
    end

    function Compiler:resetRegisters()
        self.registers = {};
    end

    function Compiler:pos(scope)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);
         
         
         
         
        return Ast.VariableExpression(self.containerFuncScope, self.posVar);
    end

    function Compiler:posAssignment(scope)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);
        return Ast.AssignmentVariable(self.containerFuncScope, self.posVar);
    end

     
     
     
    function Compiler:setPosExpression(scope, value)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);
        if self.v8Mode then
            return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar)}, {value});
        end
        if self.v6Mode and self.vmIntegrityVar then
            scope:addReferenceToHigherScope(self.containerFuncScope, self.vmIntegrityVar);
            local mix = Ast.ModExpression(
                Ast.AddExpression(
                    Ast.MulExpression(Ast.VariableExpression(self.containerFuncScope, self.vmIntegrityVar), Ast.NumberExpression(self.vmRollingStateMul), false),
                    Ast.AddExpression(value, Ast.NumberExpression(self.vmRollingStateAdd), false), false
                ), Ast.NumberExpression(self.vmRollingStateModulus), false
            );
            return Ast.AssignmentStatement(
                {Ast.AssignmentVariable(self.containerFuncScope, self.posVar), Ast.AssignmentVariable(self.containerFuncScope, self.vmIntegrityVar)},
                {value, mix}
            );
        end
        return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar)}, {value});
    end

    function Compiler:args(scope)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.argsVar);
        return Ast.VariableExpression(self.containerFuncScope, self.argsVar);
    end

    function Compiler:unpack(scope)
        scope:addReferenceToHigherScope(self.scope, self.unpackVar);
        return Ast.VariableExpression(self.scope, self.unpackVar);
    end

    function Compiler:env(scope)
        scope:addReferenceToHigherScope(self.scope, self.envVar);
        return Ast.VariableExpression(self.scope, self.envVar);
    end

    function Compiler:jmp(scope, to)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);
        local nextPos = (type(to) == "table" and to.kind) and to or Ast.NumberExpression(to);
        if self.v8Mode then
            return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar)}, {nextPos});
        end
        if self.v6Mode and self.vmIntegrityVar and nextPos.kind == AstKind.NumberExpression then
            scope:addReferenceToHigherScope(self.containerFuncScope, self.vmIntegrityVar);
            local mix = Ast.ModExpression(
                Ast.AddExpression(
                    Ast.MulExpression(Ast.VariableExpression(self.containerFuncScope, self.vmIntegrityVar), Ast.NumberExpression(self.vmRollingStateMul), false),
                    Ast.AddExpression(nextPos, Ast.NumberExpression(self.vmRollingStateAdd), false), false
                ), Ast.NumberExpression(self.vmRollingStateModulus), false
            );
            return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar), Ast.AssignmentVariable(self.containerFuncScope, self.vmIntegrityVar)}, {nextPos, mix});
        end
        return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar)},{nextPos});
    end

    function Compiler:setPos(scope, val)
        local v = val and Ast.NumberExpression(val) or Ast.IndexExpression(self:env(scope), randomStrings.randomStringNode(math.random(12, 14)));
        scope:addReferenceToHigherScope(self.containerFuncScope, self.posVar);
        if self.v8Mode then
            return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar)}, {v});
        end
        if self.v6Mode and self.vmIntegrityVar and val then
            scope:addReferenceToHigherScope(self.containerFuncScope, self.vmIntegrityVar);
            local mix = Ast.ModExpression(
                Ast.AddExpression(
                    Ast.MulExpression(Ast.VariableExpression(self.containerFuncScope, self.vmIntegrityVar), Ast.NumberExpression(self.vmRollingStateMul), false),
                    Ast.AddExpression(v, Ast.NumberExpression(self.vmRollingStateAdd), false), false
                ), Ast.NumberExpression(self.vmRollingStateModulus), false
            );
            return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar), Ast.AssignmentVariable(self.containerFuncScope, self.vmIntegrityVar)}, {v, mix});
        end
        return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.posVar)}, {v});
    end

    function Compiler:setReturn(scope, val)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.returnVar);
        return Ast.AssignmentStatement({Ast.AssignmentVariable(self.containerFuncScope, self.returnVar)}, {val});
    end

    function Compiler:getReturn(scope)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.returnVar);
        return Ast.VariableExpression(self.containerFuncScope, self.returnVar);
    end

    function Compiler:returnAssignment(scope)
        scope:addReferenceToHigherScope(self.containerFuncScope, self.returnVar);
        return Ast.AssignmentVariable(self.containerFuncScope, self.returnVar);
    end

    function Compiler:setUpvalueMember(scope, idExpr, valExpr, compoundConstructor)
        scope:addReferenceToHigherScope(self.scope, self.upvaluesTable);
        if compoundConstructor then
            return compoundConstructor(Ast.AssignmentIndexing(Ast.VariableExpression(self.scope, self.upvaluesTable), idExpr), valExpr);
        end
        return Ast.AssignmentStatement({Ast.AssignmentIndexing(Ast.VariableExpression(self.scope, self.upvaluesTable), idExpr)}, {valExpr});
    end

    function Compiler:getUpvalueMember(scope, idExpr)
        scope:addReferenceToHigherScope(self.scope, self.upvaluesTable);
        return Ast.IndexExpression(Ast.VariableExpression(self.scope, self.upvaluesTable), idExpr);
    end
end

