 
 
 
 
 

local Step = require("prometheus.step")
local Ast = require("prometheus.ast")
local Parser = require("prometheus.parser")
local Enums = require("prometheus.enums")
local visitast = require("prometheus.visitast");
local util = require("prometheus.util")
local AstKind = Ast.AstKind;

local EncryptStrings = Step:extend()
EncryptStrings.Description = "This Step will encrypt strings within your Program."
EncryptStrings.Name = "Encrypt Strings"

EncryptStrings.SettingsDescriptor = {
    Variant = {
        type = "number",
        default = 1,
        min = 1,
        max = 3,
    }
}

function EncryptStrings:init(_) end


function EncryptStrings:CreateEncryptionService()
	local usedSeeds = {};

	 
	 
	 
	local function randomBits(bits)
		local value = 0
		local remaining = bits
		while remaining > 0 do
			local chunkBits = math.min(22, remaining)
			local chunkMax = 2 ^ chunkBits - 1
			value = value * 2 ^ chunkBits + math.random(0, chunkMax)
			remaining = remaining - chunkBits
		end
		return value
	end

	local secret_key_6 = math.random(0, 63)  
	local secret_key_7 = math.random(0, 127)  
	local secret_key_44 = randomBits(44)  
	local secret_key_8 = math.random(0, 255);  

	local floor = math.floor

	local function primitive_root_257(idx)
		local g, m, d = 1, 128, 2 * idx + 1
		repeat
			g, m, d = g * g * (d >= m and 3 or 1) % 257, m / 2, d % m
		until m < 1
		return g
	end

	local param_mul_8 = primitive_root_257(secret_key_7)
	local param_mul_45 = secret_key_6 * 4 + 1
	local param_add_45 = secret_key_44 * 2 + 1

	local state_45 = 0
	local state_8 = 2

	local prev_values = {}
	local function set_seed(seed_53)
		state_45 = seed_53 % 35184372088832
		state_8 = seed_53 % 255 + 2
		prev_values = {}
	end

	local function gen_seed()
		local seed;
		repeat
			seed = randomBits(45);
		until not usedSeeds[seed];
		usedSeeds[seed] = true;
		return seed;
	end

	local function get_random_32()
		state_45 = (state_45 * param_mul_45 + param_add_45) % 35184372088832
		repeat
			state_8 = state_8 * param_mul_8 % 257
		until state_8 ~= 1
		local r = state_8 % 32
		local n = floor(state_45 / 2 ^ (13 - (state_8 - r) / 32)) % 2 ^ 32 / 2 ^ r
		return floor(n % 1 * 2 ^ 32) + floor(n)
	end

	local function get_next_pseudo_random_byte()
		if #prev_values == 0 then
			local rnd = get_random_32()  
			local low_16 = rnd % 65536
			local high_16 = (rnd - low_16) / 65536
			local b1 = low_16 % 256
			local b2 = (low_16 - b1) / 256
			local b3 = high_16 % 256
			local b4 = (high_16 - b3) / 256
			prev_values = { b1, b2, b3, b4 }
		end
		 
		return table.remove(prev_values)
	end

	local function encrypt(str)
		local seed = gen_seed();
		set_seed(seed)
		local len = string.len(str)
		local out = {}
		local prevVal = secret_key_8;
		for i = 1, len do
			local byte = string.byte(str, i);
			out[i] = string.char((byte - (get_next_pseudo_random_byte() + prevVal)) % 256);
			prevVal = byte;
		end
		return table.concat(out), seed;
	end

    local function genCode()
        local decoderVariant = tonumber(self.Variant) or 1
        local decoderBlock

        if decoderVariant == 2 then
            decoderBlock = [==[
	local prev_values = {}
	local prev_index = 0
	local function reset_decoder()
		prev_values = {}
		prev_index = 0
	end
	local function get_next_pseudo_random_byte()
		if prev_index < 1 then
			state_45 = (state_45 * ]==] .. tostring(param_mul_45) .. [==[ + ]==] .. tostring(param_add_45) .. [==[) % 35184372088832
			repeat
				state_8 = state_8 * ]==] .. tostring(param_mul_8) .. [==[ % 257
			until state_8 ~= 1
			local r = state_8 % 32
			local shift = 13 - (state_8 - r) / 32
			local n = floor(state_45 / 2 ^ shift) % 4294967296 / 2 ^ r
			local rnd = floor(n % 1 * 4294967296) + floor(n)
			local low_16 = rnd % 65536
			local high_16 = (rnd - low_16) / 65536
			prev_values = { low_16 % 256, (low_16 - low_16 % 256) / 256, high_16 % 256, (high_16 - high_16 % 256) / 256 }
			prev_index = 4
		end
		local value = prev_values[prev_index]
		prev_index = prev_index - 1
		return value
	end
]==]
        elseif decoderVariant == 3 then
            decoderBlock = [==[
	local b1, b2, b3, b4 = 0, 0, 0, 0
	local byte_index = 0
	local function reset_decoder()
		byte_index = 0
	end
	local function get_next_pseudo_random_byte()
		if byte_index == 0 then
			state_45 = (state_45 * ]==] .. tostring(param_mul_45) .. [==[ + ]==] .. tostring(param_add_45) .. [==[) % 35184372088832
			repeat
				state_8 = state_8 * ]==] .. tostring(param_mul_8) .. [==[ % 257
			until state_8 ~= 1
			local r = state_8 % 32
			local shift = 13 - (state_8 - r) / 32
			local n = floor(state_45 / 2 ^ shift) % 4294967296 / 2 ^ r
			local rnd = floor(n % 1 * 4294967296) + floor(n)
			local low_16 = rnd % 65536
			local high_16 = (rnd - low_16) / 65536
			b1, b2, b3, b4 = low_16 % 256, (low_16 - low_16 % 256) / 256, high_16 % 256, (high_16 - high_16 % 256) / 256
			byte_index = 4
		end
		local value
		if byte_index == 4 then value = b4
		elseif byte_index == 3 then value = b3
		elseif byte_index == 2 then value = b2
		else value = b1 end
		byte_index = byte_index - 1
		return value
	end
]==]
        else
            decoderBlock = [==[
	local prev_values = {}
	local function reset_decoder()
		prev_values = {}
	end
	local function get_next_pseudo_random_byte()
		if #prev_values == 0 then
			state_45 = (state_45 * ]==] .. tostring(param_mul_45) .. [==[ + ]==] .. tostring(param_add_45) .. [==[) % 35184372088832
			repeat
				state_8 = state_8 * ]==] .. tostring(param_mul_8) .. [==[ % 257
				until state_8 ~= 1
			local r = state_8 % 32
			local shift = 13 - (state_8 - r) / 32
			local n = floor(state_45 / 2 ^ shift) % 4294967296 / 2 ^ r
			local rnd = floor(n % 1 * 4294967296) + floor(n)
			local low_16 = rnd % 65536
			local high_16 = (rnd - low_16) / 65536
			prev_values = { low_16 % 256, (low_16 - low_16 % 256) / 256, high_16 % 256, (high_16 - high_16 % 256) / 256 }
		end
		local n = #prev_values
		local value = prev_values[n]
		prev_values[n] = nil
		return value
	end
]==]
        end

        local code = [=[
do
	]=] .. table.concat(util.shuffle{
            "local floor = math.floor",
            "local random = math.random",
            "local remove = table.remove",
            "local char = string.char",
            "local state_45 = 0",
            "local state_8 = 2",
            "local charmap = {}",
            "local nums = {}"
        }, "\n") .. [=[
	for i = 1, 256 do
		nums[i] = i;
	end

	repeat
		local idx = random(1, #nums);
		local n = remove(nums, idx);
		charmap[n] = char(n - 1);
	until #nums == 0;

]=] .. decoderBlock .. [=[

	local realStrings = {};
	STRINGS = setmetatable({}, {
		__index = realStrings;
		__metatable = nil;
	});
	function DECRYPT(str, seed)
		local realStringsLocal = realStrings;
		if(realStringsLocal[seed]) then return seed; else
			reset_decoder();
			local chars = charmap;
			state_45 = seed % 35184372088832
			state_8 = seed % 255 + 2
			local len = #str;
			realStringsLocal[seed] = "";
			local prevVal = ]=] .. tostring(secret_key_8) .. [=[;
			local s = "";
			for i=1, len, 1 do
				prevVal = (string.byte(str, i) + get_next_pseudo_random_byte() + prevVal) % 256
				s = s .. chars[prevVal + 1];
			end
			realStringsLocal[seed] = s;
		end
		return seed;
	end
end]=]

        return code
    end

    return {
        encrypt = encrypt,
        param_mul_45 = param_mul_45,
        param_mul_8 = param_mul_8,
        param_add_45 = param_add_45,
		secret_key_8 = secret_key_8,
        genCode = genCode,
    }
end

function EncryptStrings:apply(ast, _)
    local Encryptor = self:CreateEncryptionService();

	local code = Encryptor.genCode();
	local newAst = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code);
	local doStat = newAst.body.statements[1];

	local scope = ast.body.scope;
	local decryptVar = scope:addVariable();
	local stringsVar = scope:addVariable();

	doStat.body.scope:setParent(ast.body.scope);

	visitast(newAst, nil, function(node, data)
		if(node.kind == AstKind.FunctionDeclaration) then
			if(node.scope:getVariableName(node.id) == "DECRYPT") then
				data.scope:removeReferenceToHigherScope(node.scope, node.id);
				data.scope:addReferenceToHigherScope(scope, decryptVar);
				node.scope = scope;
				node.id = decryptVar;
			end
		end
		if(node.kind == AstKind.AssignmentVariable or node.kind == AstKind.VariableExpression) then
			if(node.scope:getVariableName(node.id) == "STRINGS") then
				data.scope:removeReferenceToHigherScope(node.scope, node.id);
				data.scope:addReferenceToHigherScope(scope, stringsVar);
				node.scope = scope;
				node.id = stringsVar;
			end
		end
	end)

	 
	 
	 
	 
	 
	 
	local decoderKeywords = {
		"and", "break", "do", "else", "elseif", "end", "false", "for",
		"function", "if", "in", "local", "nil", "not", "or", "repeat",
		"return", "then", "true", "until", "while", "continue", "type",
		"export", "typeof"
	}
	local alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	local function makeDecoderName()
		local length = math.random(9, 15)
		local out = {}
		for i = 1, length do
			local index = math.random(1, #alphabet)
			out[i] = string.sub(alphabet, index, index)
		end
		return table.concat(out)
	end
	if doStat.body and doStat.body.scope then
		doStat.body.scope:renameVariables({
			Keywords = decoderKeywords,
			generateName = function() return makeDecoderName() end,
		})
	end

	visitast(ast, nil, function(node, data)
		if(node.kind == AstKind.StringExpression) then
			data.scope:addReferenceToHigherScope(scope, stringsVar);
			data.scope:addReferenceToHigherScope(scope, decryptVar);
			local encrypted, seed = Encryptor.encrypt(node.value);
			return Ast.IndexExpression(Ast.VariableExpression(scope, stringsVar), Ast.FunctionCallExpression(Ast.VariableExpression(scope, decryptVar), {
				Ast.StringExpression(encrypted), Ast.NumberExpression(seed),
			}));
		end
	end)


	 
	table.insert(ast.body.statements, 1, doStat);
	table.insert(ast.body.statements, 1, Ast.LocalVariableDeclaration(scope, util.shuffle{ decryptVar, stringsVar }, {}));
	return ast
end

return EncryptStrings
