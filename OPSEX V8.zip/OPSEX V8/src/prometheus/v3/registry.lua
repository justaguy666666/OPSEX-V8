local R = {
passes = {}
}

function R.register(p)
assert(
type(p) == "table"
and type(p.name) == "string"
and type(p.transform) == "function",
"invalid V3 pass"
)

  
assert(
    not R.passes[p.name],
    "duplicate V3 pass: " .. p.name
)

R.passes[p.name] = p
  

end

function R.get(name)
return R.passes[name]
end

function R.list()
local result = {}

  
for _, pass in pairs(R.passes) do
    result[#result + 1] = pass
end

table.sort(
    result,
    function(a, b)
        return a.name < b.name
    end
)

return result
  

end

function R.resolve(config)
local result = {}

  
for _, name in ipairs(config.order or {}) do
    local pass = R.passes[name]

    if pass then
        local explicitlyEnabled =
            config.enabled
            and config.enabled[name]

        local explicitlyDisabled =
            config.enabled
            and config.enabled[name] == false

        if explicitlyEnabled
            or (
                explicitlyDisabled == false
                and pass.enabledByDefault ~= false
            )
        then
            result[#result + 1] = pass
        end
    end
end

return result
  

end

return R
