local Ast = require("prometheus.ast")
local K = Ast.AstKind

local V = {}

local function fail(pass, message)
    return false, (pass or "unknown") .. ": " .. message
end

local function validNode(node)
    return type(node) == "table"
        and type(node.kind) == "string"
end

local function requireTable(value, pass, path, name)
    if type(value) ~= "table" then
        return fail(
            pass,
            path .. "." .. name .. " must be a table"
        )
    end

    return true
end

local validateExpression
local validateStatement
local validateBlock

 
 
 

validateExpression = function(node, pass, path)
    if not validNode(node) then
        return fail(pass, path .. ": invalid expression")
    end

    local kind = node.kind

    if kind == K.NumberExpression then
        if type(node.value) ~= "number" then
            return fail(pass, path .. ".value must be a number")
        end
        return true
    end

    if kind == K.StringExpression then
        if type(node.value) ~= "string" then
            return fail(pass, path .. ".value must be a string")
        end
        return true
    end

    if kind == K.BooleanExpression then
        if type(node.value) ~= "boolean" then
            return fail(pass, path .. ".value must be a boolean")
        end
        return true
    end

    if kind == K.NilExpression
        or kind == K.VarargExpression
        or kind == K.VariableExpression
        or kind == K.AssignmentVariable
    then
        return true
    end

    if kind == K.NotExpression
        or kind == K.NegateExpression
        or kind == K.LenExpression
    then
        if not validNode(node.rhs) then
            return fail(pass, path .. ".rhs: invalid expression")
        end

        return validateExpression(
            node.rhs,
            pass,
            path .. ".rhs"
        )
    end

    if kind == K.OrExpression
        or kind == K.AndExpression
        or kind == K.LessThanExpression
        or kind == K.GreaterThanExpression
        or kind == K.LessThanOrEqualsExpression
        or kind == K.GreaterThanOrEqualsExpression
        or kind == K.NotEqualsExpression
        or kind == K.EqualsExpression
        or kind == K.StrCatExpression
        or kind == K.AddExpression
        or kind == K.SubExpression
        or kind == K.MulExpression
        or kind == K.DivExpression
        or kind == K.ModExpression
        or kind == K.PowExpression
    then
        if not validNode(node.lhs) then
            return fail(pass, path .. ".lhs: invalid expression")
        end

        if not validNode(node.rhs) then
            return fail(pass, path .. ".rhs: invalid expression")
        end

        local ok, err = validateExpression(
            node.lhs,
            pass,
            path .. ".lhs"
        )

        if not ok then
            return false, err
        end

        return validateExpression(
            node.rhs,
            pass,
            path .. ".rhs"
        )
    end

    if kind == K.IndexExpression
        or kind == K.AssignmentIndexing
    then
        if not validNode(node.base) then
            return fail(pass, path .. ".base: invalid expression")
        end

        if not validNode(node.index) then
            return fail(pass, path .. ".index: invalid expression")
        end

        local ok, err = validateExpression(
            node.base,
            pass,
            path .. ".base"
        )

        if not ok then
            return false, err
        end

        return validateExpression(
            node.index,
            pass,
            path .. ".index"
        )
    end

    if kind == K.FunctionCallExpression
        or kind == K.PassSelfFunctionCallExpression
    then
        if not validNode(node.base) then
            return fail(pass, path .. ".base: invalid expression")
        end

        local ok, err = validateExpression(
            node.base,
            pass,
            path .. ".base"
        )

        if not ok then
            return false, err
        end

        if node.args ~= nil then
            ok, err = requireTable(
                node.args,
                pass,
                path,
                "args"
            )

            if not ok then
                return false, err
            end

            for i, arg in ipairs(node.args) do
                ok, err = validateExpression(
                    arg,
                    pass,
                    string.format(
                        "%s.args[%d]",
                        path,
                        i
                    )
                )

                if not ok then
                    return false, err
                end
            end
        end

        return true
    end

    if kind == K.FunctionLiteralExpression then
        if node.body ~= nil then
            return validateBlock(
                node.body,
                pass,
                path .. ".body"
            )
        end

        return true
    end

    if kind == K.TableConstructorExpression then
        if node.entries == nil then
            return true
        end

        local ok, err = requireTable(
            node.entries,
            pass,
            path,
            "entries"
        )

        if not ok then
            return false, err
        end

        for i, entry in ipairs(node.entries) do
            if not validNode(entry) then
                return fail(
                    pass,
                    string.format(
                        "%s.entries[%d]: invalid table entry",
                        path,
                        i
                    )
                )
            end

            if entry.kind == K.TableEntry then
                if not validNode(entry.value) then
                    return fail(
                        pass,
                        string.format(
                            "%s.entries[%d].value: invalid expression",
                            path,
                            i
                        )
                    )
                end

                ok, err = validateExpression(
                    entry.value,
                    pass,
                    string.format(
                        "%s.entries[%d].value",
                        path,
                        i
                    )
                )

                if not ok then
                    return false, err
                end

            elseif entry.kind == K.KeyedTableEntry then
                if not validNode(entry.key) then
                    return fail(
                        pass,
                        string.format(
                            "%s.entries[%d].key: invalid expression",
                            path,
                            i
                        )
                    )
                end

                if not validNode(entry.value) then
                    return fail(
                        pass,
                        string.format(
                            "%s.entries[%d].value: invalid expression",
                            path,
                            i
                        )
                    )
                end

                ok, err = validateExpression(
                    entry.key,
                    pass,
                    string.format(
                        "%s.entries[%d].key",
                        path,
                        i
                    )
                )

                if not ok then
                    return false, err
                end

                ok, err = validateExpression(
                    entry.value,
                    pass,
                    string.format(
                        "%s.entries[%d].value",
                        path,
                        i
                    )
                )

                if not ok then
                    return false, err
                end
            end
        end

        return true
    end

    if kind == K.IfElseExpression then
        if not validNode(node.condition) then
            return fail(
                pass,
                path .. ".condition: invalid expression"
            )
        end

        local ok, err = validateExpression(
            node.condition,
            pass,
            path .. ".condition"
        )

        if not ok then
            return false, err
        end

        if not validNode(node.true_value) then
            return fail(
                pass,
                path .. ".true_value: invalid expression"
            )
        end

        ok, err = validateExpression(
            node.true_value,
            pass,
            path .. ".true_value"
        )

        if not ok then
            return false, err
        end

        if node.elseifs ~= nil then
            if type(node.elseifs) ~= "table" then
                return fail(
                    pass,
                    path .. ".elseifs must be a table"
                )
            end

            for i, elseifNode in ipairs(node.elseifs) do
                if type(elseifNode) ~= "table" then
                    return fail(
                        pass,
                        string.format(
                            "%s.elseifs[%d]: invalid elseif expression",
                            path,
                            i
                        )
                    )
                end

                if not validNode(elseifNode.condition) then
                    return fail(
                        pass,
                        string.format(
                            "%s.elseifs[%d].condition: invalid expression",
                            path,
                            i
                        )
                    )
                end

                ok, err = validateExpression(
                    elseifNode.condition,
                    pass,
                    string.format(
                        "%s.elseifs[%d].condition",
                        path,
                        i
                    )
                )

                if not ok then
                    return false, err
                end

                local value =
                    elseifNode.value
                    or elseifNode.true_value

                if not validNode(value) then
                    return fail(
                        pass,
                        string.format(
                            "%s.elseifs[%d].value: invalid expression",
                            path,
                            i
                        )
                    )
                end

                ok, err = validateExpression(
                    value,
                    pass,
                    string.format(
                        "%s.elseifs[%d].value",
                        path,
                        i
                    )
                )

                if not ok then
                    return false, err
                end
            end
        end

        if node.false_value ~= nil then
            return validateExpression(
                node.false_value,
                pass,
                path .. ".false_value"
            )
        end

        return true
    end

    return true
end

 
 
 

validateBlock = function(block, pass, path)
    if not validNode(block) then
        return fail(pass, path .. ": invalid block")
    end

    if block.kind ~= K.Block then
        return fail(
            pass,
            path .. ": expected Block, got " .. tostring(block.kind)
        )
    end

    if type(block.statements) ~= "table" then
        return fail(
            pass,
            path .. ".statements must be a table"
        )
    end

    for i, statement in ipairs(block.statements) do
        local ok, err = validateStatement(
            statement,
            pass,
            string.format("%s.statements[%d]", path, i)
        )

        if not ok then
            return false, err
        end
    end

    return true
end

 
 
 

validateStatement = function(statement, pass, path)
    if not validNode(statement) then
        return fail(pass, path .. ": invalid statement")
    end

    local kind = statement.kind

    if kind == K.NopStatement
        or kind == K.BreakStatement
        or kind == K.ContinueStatement
    then
        return true
    end

    if kind == K.FunctionCallStatement
        or kind == K.PassSelfFunctionCallStatement
    then
        local expression =
            statement.expression
            or statement.func
            or statement.base

        if not validNode(expression) then
            return fail(
                pass,
                path .. ": function call statement missing call expression"
            )
        end

        return validateExpression(
            expression,
            pass,
            path .. ".expression"
        )
    end

    if kind == K.AssignmentStatement then
        if type(statement.lhs) ~= "table" then
            return fail(pass, path .. ".lhs must be a table")
        end

        if type(statement.rhs) ~= "table" then
            return fail(pass, path .. ".rhs must be a table")
        end

        for i, expression in ipairs(statement.lhs) do
            local ok, err = validateExpression(
                expression,
                pass,
                string.format("%s.lhs[%d]", path, i)
            )

            if not ok then
                return false, err
            end
        end

        for i, expression in ipairs(statement.rhs) do
            local ok, err = validateExpression(
                expression,
                pass,
                string.format("%s.rhs[%d]", path, i)
            )

            if not ok then
                return false, err
            end
        end

        return true
    end

    if kind == K.CompoundAddStatement
        or kind == K.CompoundSubStatement
        or kind == K.CompoundMulStatement
        or kind == K.CompoundDivStatement
        or kind == K.CompoundPowStatement
        or kind == K.CompoundModStatement
        or kind == K.CompoundConcatStatement
    then
        if not validNode(statement.lhs) then
            return fail(pass, path .. ".lhs: invalid expression")
        end

        if not validNode(statement.rhs) then
            return fail(pass, path .. ".rhs: invalid expression")
        end

        local ok, err = validateExpression(
            statement.lhs,
            pass,
            path .. ".lhs"
        )

        if not ok then
            return false, err
        end

        return validateExpression(
            statement.rhs,
            pass,
            path .. ".rhs"
        )
    end

    if kind == K.ReturnStatement then
        if statement.args ~= nil
            and type(statement.args) ~= "table"
        then
            return fail(pass, path .. ".args must be a table")
        end

        for i, expression in ipairs(statement.args or {}) do
            local ok, err = validateExpression(
                expression,
                pass,
                string.format("%s.args[%d]", path, i)
            )

            if not ok then
                return false, err
            end
        end

        return true
    end

    if kind == K.LocalVariableDeclaration then
        if type(statement.ids) ~= "table" then
            return fail(pass, path .. ".ids must be a table")
        end

        if statement.expressions ~= nil
            and type(statement.expressions) ~= "table"
        then
            return fail(
                pass,
                path .. ".expressions must be a table"
            )
        end

        for i, expression in ipairs(statement.expressions or {}) do
            local ok, err = validateExpression(
                expression,
                pass,
                string.format(
                    "%s.expressions[%d]",
                    path,
                    i
                )
            )

            if not ok then
                return false, err
            end
        end

        return true
    end

    if kind == K.DoStatement then
        return validateBlock(
            statement.body,
            pass,
            path .. ".body"
        )
    end

    if kind == K.WhileStatement then
        if not validNode(statement.condition) then
            return fail(
                pass,
                path .. ".condition: invalid expression"
            )
        end

        local ok, err = validateExpression(
            statement.condition,
            pass,
            path .. ".condition"
        )

        if not ok then
            return false, err
        end

        return validateBlock(
            statement.body,
            pass,
            path .. ".body"
        )
    end

    if kind == K.RepeatStatement then
        local ok, err = validateBlock(
            statement.body,
            pass,
            path .. ".body"
        )

        if not ok then
            return false, err
        end

        if not validNode(statement.condition) then
            return fail(
                pass,
                path .. ".condition: invalid expression"
            )
        end

        return validateExpression(
            statement.condition,
            pass,
            path .. ".condition"
        )
    end

    if kind == K.ForStatement then
        for _, field in ipairs({
            "initialValue",
            "finalValue",
            "incrementBy"
        }) do
            if not validNode(statement[field]) then
                return fail(
                    pass,
                    path .. "." .. field .. ": invalid expression"
                )
            end

            local ok, err = validateExpression(
                statement[field],
                pass,
                path .. "." .. field
            )

            if not ok then
                return false, err
            end
        end

        return validateBlock(
            statement.body,
            pass,
            path .. ".body"
        )
    end

    if kind == K.ForInStatement then
        if type(statement.expressions) ~= "table" then
            return fail(
                pass,
                path .. ".expressions must be a table"
            )
        end

        for i, expression in ipairs(statement.expressions) do
            local ok, err = validateExpression(
                expression,
                pass,
                string.format(
                    "%s.expressions[%d]",
                    path,
                    i
                )
            )

            if not ok then
                return false, err
            end
        end

        return validateBlock(
            statement.body,
            pass,
            path .. ".body"
        )
    end

    if kind == K.IfStatement then
        if not validNode(statement.condition) then
            return fail(
                pass,
                path .. ".condition: invalid expression"
            )
        end

        local ok, err = validateExpression(
            statement.condition,
            pass,
            path .. ".condition"
        )

        if not ok then
            return false, err
        end

        ok, err = validateBlock(
            statement.body,
            pass,
            path .. ".body"
        )

        if not ok then
            return false, err
        end

        if statement.elseifs ~= nil
            and type(statement.elseifs) ~= "table"
        then
            return fail(
                pass,
                path .. ".elseifs must be a table"
            )
        end

         
         
         
         
         
         
         
         
         
         

        for i, elseifNode in ipairs(statement.elseifs or {}) do
            if type(elseifNode) ~= "table" then
                return fail(
                    pass,
                    string.format(
                        "%s.elseifs[%d]: invalid elseif record",
                        path,
                        i
                    )
                )
            end

            if not validNode(elseifNode.condition) then
                return fail(
                    pass,
                    string.format(
                        "%s.elseifs[%d].condition: invalid expression",
                        path,
                        i
                    )
                )
            end

            ok, err = validateExpression(
                elseifNode.condition,
                pass,
                string.format(
                    "%s.elseifs[%d].condition",
                    path,
                    i
                )
            )

            if not ok then
                return false, err
            end

            ok, err = validateBlock(
                elseifNode.body,
                pass,
                string.format(
                    "%s.elseifs[%d].body",
                    path,
                    i
                )
            )

            if not ok then
                return false, err
            end
        end

        if statement.elsebody ~= nil then
            return validateBlock(
                statement.elsebody,
                pass,
                path .. ".elsebody"
            )
        end

        return true
    end

    if kind == K.FunctionDeclaration
        or kind == K.LocalFunctionDeclaration
    then
        return validateBlock(
            statement.body,
            pass,
            path .. ".body"
        )
    end

    return true
end

 
 
 

function V.validate(ast, pass)
    if type(ast) ~= "table" then
        return fail(pass, "AST is not a table")
    end

    if ast.kind == K.TopNode then
        if not ast.body then
            return fail(pass, "TopNode has no body")
        end

        return validateBlock(
            ast.body,
            pass,
            "TopNode.body"
        )
    end

    if ast.kind == K.Block then
        return validateBlock(
            ast,
            pass,
            "Block"
        )
    end

    if not ast.kind then
        return fail(pass, "AST node has no kind")
    end

    return true
end

return V