local Ast = require("prometheus.ast")
local K = Ast.AstKind

local M = {
    name = "cleanup",
    version = "4.0.0",
    enabledByDefault = true,
    stage = 90
}

local cleanStatement
local cleanBlock

local function cleanElseifs(statement)
    local list = statement.elseifs

    if type(list) ~= "table" then
        statement.elseifs = {}
        return 0
    end

    local changed = 0
    local output = {}

    for _, entry in ipairs(list) do
        if type(entry) == "table"
            and entry.condition
            and entry.body
            and entry.body.kind == K.Block
        then
            changed = changed + cleanBlock(entry.body)
            output[#output + 1] = entry
        else
             
             
            changed = changed + 1
        end
    end

    statement.elseifs = output
    return changed
end

cleanStatement = function(statement)
    if type(statement) ~= "table" then
        return 0
    end

    local kind = statement.kind
    local changed = 0

    if kind == K.IfStatement then
        changed = changed + cleanBlock(statement.body)
        changed = changed + cleanElseifs(statement)

        if statement.elsebody then
            changed = changed + cleanBlock(statement.elsebody)
        end

    elseif kind == K.WhileStatement
        or kind == K.RepeatStatement
        or kind == K.ForStatement
        or kind == K.ForInStatement
        or kind == K.DoStatement
    then
        changed = changed + cleanBlock(statement.body)

    elseif kind == K.FunctionDeclaration
        or kind == K.LocalFunctionDeclaration
    then
        changed = changed + cleanBlock(statement.body)
    end

    return changed
end

cleanBlock = function(block)
    if not block or block.kind ~= K.Block then
        return 0
    end

    if type(block.statements) ~= "table" then
        block.statements = {}
        return 0
    end

    local changed = 0
    local output = {}

    for _, statement in ipairs(block.statements) do
        if statement then
            changed = changed + cleanStatement(statement)

             
             
             
            if statement.kind == K.DoStatement
                and statement.body
                and statement.body.kind == K.Block
                and type(statement.body.statements) == "table"
                and #statement.body.statements == 0
            then
                changed = changed + 1
            else
                output[#output + 1] = statement
            end
        else
            changed = changed + 1
        end
    end

    block.statements = output
    return changed
end

function M.transform(ast, c)
    local block = ast

    if ast and ast.kind == K.TopNode then
        block = ast.body
    end

    local changed = 0

    if block and block.kind == K.Block then
        changed = cleanBlock(block)
    end

    c:recordStatistic("cleanup.removed", changed)
    c:recordPass("cleanup")

    return ast
end

return M
