local Ast = require("prometheus.ast")
local Scope = require("prometheus.scope")
local K = Ast.AstKind

local M = {
    name = "structure",
    version = "4.1.0",
    enabledByDefault = true,
    stage = 50
}

local MIN_GROUP = 2
local MAX_GROUP = 3
local MAX_DEPTH = 3
local WRAPPER_VARIANTS = 3

local function randomRange(c, min, max)
    if max <= min then
        return min
    end
    return c.random:integer(min, max)
end

local function canGroup(statement)
    if not statement then
        return false
    end

    local kind = statement.kind

     
     
    if kind == K.NopStatement
        or kind == K.ReturnStatement
        or kind == K.BreakStatement
        or kind == K.ContinueStatement
        or kind == K.LocalVariableDeclaration
        or kind == K.LocalFunctionDeclaration
        or kind == K.FunctionDeclaration
    then
        return false
    end

     
    if kind == K.IfStatement
        or kind == K.WhileStatement
        or kind == K.RepeatStatement
        or kind == K.ForStatement
        or kind == K.ForInStatement
        or kind == K.DoStatement
    then
        return false
    end

    return true
end

local function makeDo(statements, scope)
    return Ast.DoStatement(
        Ast.Block(statements, scope)
    )
end

local function makeRepeat(statements, parentScope)
    local repeatScope = Scope:new(parentScope)
    local body = Ast.Block(statements, repeatScope)

     
     
     
     
    return Ast.RepeatStatement(
        Ast.BooleanExpression(true),
        body,
        parentScope
    )
end

local function makeConditional(statements, parentScope, c)
     
     
     
     
    local base = c.random:integer(7, 97)
    local offset = c.random:integer(3, 31)
    local left = Ast.SubExpression(
        Ast.AddExpression(
            Ast.NumberExpression(base),
            Ast.NumberExpression(offset),
            false
        ),
        Ast.NumberExpression(offset),
        false
    )

    local right = Ast.NumberExpression(base)
    local condition = Ast.EqualsExpression(left, right, false)

    return Ast.IfStatement(
        condition,
        Ast.Block(statements, parentScope),
        {},
        nil
    )
end

local function makeWrapper(statements, parentScope, c)
    local variant = c.random:integer(1, WRAPPER_VARIANTS)

    if variant == 1 then
        return makeDo(statements, parentScope)
    elseif variant == 2 then
        return makeRepeat(statements, parentScope)
    end

    return makeConditional(statements, parentScope, c)
end

local function transformBlock(block, c, depth)
    if not block
        or block.kind ~= K.Block
        or type(block.statements) ~= "table"
    then
        return 0
    end

    depth = depth or 0
    local statements = block.statements
    local changed = 0

     
    for _, statement in ipairs(statements) do
        if statement then
            local kind = statement.kind

            if kind == K.IfStatement then
                changed = changed + transformBlock(statement.body, c, depth + 1)

                for _, elseifNode in ipairs(statement.elseifs or {}) do
                    if elseifNode and elseifNode.body then
                        changed = changed + transformBlock(
                            elseifNode.body, c, depth + 1
                        )
                    end
                end

                if statement.elsebody then
                    changed = changed + transformBlock(
                        statement.elsebody, c, depth + 1
                    )
                end

            elseif kind == K.WhileStatement
                or kind == K.RepeatStatement
                or kind == K.ForStatement
                or kind == K.ForInStatement
                or kind == K.DoStatement
            then
                changed = changed + transformBlock(
                    statement.body, c, depth + 1
                )

            elseif kind == K.FunctionDeclaration
                or kind == K.LocalFunctionDeclaration
            then
                changed = changed + transformBlock(
                    statement.body, c, depth + 1
                )
            end
        end
    end

    if depth >= MAX_DEPTH or #statements < MIN_GROUP then
        return changed
    end

    local result = {}
    local i = 1

    while i <= #statements do
        local statement = statements[i]

        if not canGroup(statement) then
            result[#result + 1] = statement
            i = i + 1
        else
            local runStart = i
            local runEnd = i

            while runEnd + 1 <= #statements
                and canGroup(statements[runEnd + 1])
            do
                runEnd = runEnd + 1
            end

            local runLength = runEnd - runStart + 1

            if runLength < MIN_GROUP then
                result[#result + 1] = statement
                i = i + 1
            else
                local pos = runStart

                while pos <= runEnd do
                    local remaining = runEnd - pos + 1

                    if remaining < MIN_GROUP then
                        result[#result + 1] = statements[pos]
                        pos = pos + 1
                    else
                        local size = randomRange(
                            c,
                            MIN_GROUP,
                            math.min(MAX_GROUP, remaining)
                        )

                        local grouped = {}

                        for j = 0, size - 1 do
                            grouped[#grouped + 1] = statements[pos + j]
                        end

                        result[#result + 1] = makeWrapper(
                            grouped,
                            block.scope,
                            c
                        )

                        changed = changed + 1
                        pos = pos + size
                    end
                end

                i = runEnd + 1
            end
        end
    end

    block.statements = result
    return changed
end

function M.transform(ast, c)
    local block = ast

    if ast and ast.kind == K.TopNode then
        block = ast.body
    end

    local changed = 0

    if block and block.kind == K.Block then
        changed = transformBlock(block, c, 0)
    end

    c:recordStatistic("structure.groups", changed)
    c:recordPass("structure")

    return ast
end

return M
