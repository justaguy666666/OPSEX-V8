local Ast = require("prometheus.ast")
local visitAst = require("prometheus.visitast")
local K = Ast.AstKind

local M = {
    name = "controlflow",
    version = "8.0.0",
    enabledByDefault = false,
    stage = 60
}

local function boolean(value)
    return Ast.BooleanExpression(value)
end

 
 
 
local function doubleNot(condition)
    return Ast.NotExpression(
        Ast.NotExpression(condition, false),
        false
    )
end

local function andTrue(condition)
    return Ast.AndExpression(condition, boolean(true), false)
end

local function orFalse(condition)
    return Ast.OrExpression(condition, boolean(false), false)
end

local function normalized(condition)
    return Ast.NotExpression(
        Ast.NotExpression(
            Ast.AndExpression(condition, boolean(true), false),
            false
        ),
        false
    )
end

local function demorgan(condition)
    if not condition then
        return condition, false
    end

    if condition.kind == K.AndExpression then
         
         
        return Ast.NotExpression(
            Ast.OrExpression(
                Ast.NotExpression(condition.lhs, false),
                Ast.NotExpression(condition.rhs, false),
                false
            ),
            false
        ), true
    end

    if condition.kind == K.OrExpression then
         
         
        return Ast.NotExpression(
            Ast.AndExpression(
                Ast.NotExpression(condition.lhs, false),
                Ast.NotExpression(condition.rhs, false),
                false
            ),
            false
        ), true
    end

    return condition, false
end

local function mixedTruth(condition, c)
     
     
     
    local result = condition
    local count = c.random:integer(3, 7)

    for _ = 1, count do
        local choice = c.random:integer(1, 5)

        if choice == 1 then
            result = doubleNot(result)
        elseif choice == 2 then
            result = andTrue(result)
        elseif choice == 3 then
            result = orFalse(result)
        elseif choice == 4 then
            result = normalized(result)
        else
            result = Ast.OrExpression(
                Ast.AndExpression(
                    result,
                    boolean(true),
                    false
                ),
                boolean(false),
                false
            )
        end
    end

    return result
end

local function noisyTruth(condition, c)
    local result = mixedTruth(condition, c)

     
     
    if c.random:boolean(0.35) then
        result = doubleNot(result)
    end

    return result
end

local variants = {
    doubleNot,
    andTrue,
    orFalse,
    normalized,
    noisyTruth,
    mixedTruth
}

local function transformCondition(condition, c)
    if not condition then
        return condition
    end

     
     
     
    if c.random:boolean(0.45) then
        local rewritten, changed = demorgan(condition)
        if changed then
            return rewritten
        end
    end

    return variants[c.random:integer(1, #variants)](condition, c)
end

local function invertSimpleIf(node)
    if not node.condition then
        return false
    end

     
     
     
    if node.elsebody and #(node.elseifs or {}) == 0 then
        local oldBody = node.body
        node.body = node.elsebody
        node.elsebody = oldBody
        node.condition = Ast.NotExpression(node.condition, false)
        return true
    end

    return false
end

local function transformNode(node, c)
    local changed = 0

    if node.kind == K.IfStatement then
        if node.condition then
            node.condition = transformCondition(node.condition, c)
            changed = changed + 1

             
             
            if c.random:integer(1, 2) == 1 and invertSimpleIf(node) then
                changed = changed + 1
            end
        end

        for _, elseifNode in ipairs(node.elseifs or {}) do
            if elseifNode and elseifNode.condition then
                elseifNode.condition = transformCondition(
                    elseifNode.condition,
                    c
                )
                changed = changed + 1
            end
        end
    elseif node.kind == K.WhileStatement
        or node.kind == K.RepeatStatement
    then
        if node.condition then
            node.condition = transformCondition(node.condition, c)
            changed = changed + 1
        end
    end

    return node, changed
end

function M.transform(ast, c)
    local changed = 0

    ast = visitAst(ast, nil, function(node)
        local replacement, count = transformNode(node, c)
        changed = changed + count
        return replacement
    end, {})

    c:recordStatistic("controlflow.conditions", changed)
    c:recordPass("controlflow")

    return ast
end

return M
