local Ast = require("prometheus.ast")
local Scope = require("prometheus.scope")
local visitAst = require("prometheus.visitast")
local K = Ast.AstKind

local M = {
    name = "strings",
    version = "5.2.0",
    enabledByDefault = false,
    stage = 40
}

 
 
 
 
 

local MIN_LENGTH = 1
local MIN_ENCODE = 2
local MAX_ENCODE = 7

local function number(value)
    return Ast.NumberExpression(value)
end

local function add(lhs, rhs)
    return Ast.AddExpression(lhs, rhs, false)
end

local function sub(lhs, rhs)
    return Ast.SubExpression(lhs, rhs, false)
end

local function mul(lhs, rhs)
    return Ast.MulExpression(lhs, rhs, false)
end

local function div(lhs, rhs)
    return Ast.DivExpression(lhs, rhs, false)
end

local function mod(lhs, rhs)
    return Ast.ModExpression(lhs, rhs, false)
end

local function randomInt(c, a, b)
    return c.random:integer(a, b)
end

local function resolveStringChar(ast)
    local scope, id = ast.globalScope:resolveGlobal("string")
    assert(
        scope ~= nil and id ~= nil,
        "V3 strings: unable to resolve global 'string'"
    )

    return Ast.IndexExpression(
        Ast.VariableExpression(scope, id),
        Ast.StringExpression("char")
    )
end

local function encodedByte(value, c)
    local key = randomInt(c, 5, 251)
    local mulKey = randomInt(c, 3, 31)

     
    local shifted = add(number(value), number(key))
    local scaled = mul(shifted, number(mulKey))
    local offset = mul(number(key), number(mulKey))

    return div(sub(scaled, offset), number(mulKey))
end

local function buildEncodedString(ast, value, c)
    local char = resolveStringChar(ast)
    local args = {}

    for i = 1, #value do
        args[#args + 1] = encodedByte(string.byte(value, i), c)
    end

    return Ast.FunctionCallExpression(char, args)
end

local function shuffled(values, c)
    local out = {}
    for i, value in ipairs(values) do
        out[i] = value
    end

    for i = #out, 2, -1 do
        local j = randomInt(c, 1, i)
        out[i], out[j] = out[j], out[i]
    end

    return out
end

local function collectStrings(ast)
    local values = {}
    local seen = {}

    visitAst(ast, nil, function(node)
        if node.kind ~= K.StringExpression then
            return node
        end

        local value = node.value
        if type(value) == "string" and #value >= MIN_LENGTH then
            if not seen[value] then
                seen[value] = true
                values[#values + 1] = value
            end
        end

        return node
    end, {})

    return values
end

local function indexExpression(index, c)
     
     
     
    local a = randomInt(c, 17, 97)
    local b = randomInt(c, 7, 41)
    local encoded = index * b + a

    return div(
        sub(number(encoded), number(a)),
        number(b)
    )
end

function M.transform(ast, c)
    local values = collectStrings(ast)
    if #values == 0 then
        c:recordStatistic("strings.pool", 0)
        c:recordStatistic("strings.runtime", 0)
        c:recordPass("strings")
        return ast
    end

    local ordered = shuffled(values, c)
    local positions = {}

    for index, value in ipairs(ordered) do
        positions[value] = index
    end

    local parentScope = ast.body and ast.body.scope
    if not parentScope then
        c:recordStatistic("strings.pool", 0)
        c:recordStatistic("strings.runtime", 0)
        c:recordPass("strings")
        return ast
    end

    local poolId = parentScope:addVariable(nil)
    local helperId = parentScope:addVariable(nil)
    local entries = {}

    for _, value in ipairs(ordered) do
         
         
         
         
        local slot = Ast.TableConstructorExpression({
            Ast.TableEntry(buildEncodedString(ast, value, c))
        })

        entries[#entries + 1] = Ast.TableEntry(slot)
    end

    local pool = Ast.TableConstructorExpression(entries)
    local declaration = Ast.LocalVariableDeclaration(
        parentScope,
        {poolId},
        {pool}
    )

     
     
     
    local helperScope = Scope:new(parentScope)
    local helperArg = helperScope:addVariable(nil)
    local helperPool = Ast.IndexExpression(
        Ast.VariableExpression(parentScope, poolId),
        Ast.VariableExpression(helperScope, helperArg)
    )
    local helperSlot = Ast.IndexExpression(
        helperPool,
        Ast.NumberExpression(1)
    )
    local helperBody = Ast.Block({
        Ast.ReturnStatement({helperSlot})
    }, helperScope)
    local helper = Ast.LocalFunctionDeclaration(
        parentScope,
        helperId,
        {Ast.VariableExpression(helperScope, helperArg)},
        helperBody
    )

    local changed = 0
    local bytes = 0

    ast = visitAst(ast, nil, function(node)
        if node.kind ~= K.StringExpression then
            return node
        end

        local value = node.value
        if type(value) ~= "string" or #value < MIN_LENGTH then
            return node
        end

        local index = positions[value]
        if not index then
            return node
        end

        changed = changed + 1
        bytes = bytes + #value

        local poolIndex = indexExpression(index, c)
        local pooled = Ast.IndexExpression(
            Ast.VariableExpression(parentScope, poolId),
            poolIndex
        )

         
         
         
        local slotVariant = c.random:integer(1, 3)
        local slotIndex
        if slotVariant == 1 then
            slotIndex = Ast.AddExpression(
                Ast.NumberExpression(1),
                Ast.NumberExpression(0),
                false
            )
        elseif slotVariant == 2 then
            slotIndex = Ast.SubExpression(
                Ast.NumberExpression(2),
                Ast.NumberExpression(1),
                false
            )
        else
            slotIndex = Ast.ModExpression(
                Ast.NumberExpression(3),
                Ast.NumberExpression(2),
                false
            )
        end

        local selected = Ast.AddExpression(
            poolIndex,
            Ast.SubExpression(slotIndex, Ast.NumberExpression(1), false),
            false
        )

        return Ast.FunctionCallExpression(
            Ast.VariableExpression(parentScope, helperId),
            {selected}
        )
    end, {})

     
     
     
    local body = ast.body
    if body and body.kind == K.Block then
        table.insert(body.statements, 1, helper)
        table.insert(body.statements, 1, declaration)
    end

    c:recordStatistic("strings.pool", #ordered)
    c:recordStatistic("strings.helper", 1)
    c:recordStatistic("strings.runtime", changed)
    c:recordStatistic("strings.bytes", bytes)
    c:recordStatistic("strings.encoded", #ordered)
    c:recordPass("strings")

    return ast
end

return M
