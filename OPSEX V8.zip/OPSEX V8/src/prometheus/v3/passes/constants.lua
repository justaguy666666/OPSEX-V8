local Ast = require("prometheus.ast")
local visitAst = require("prometheus.visitast")
local K = Ast.AstKind

local M = {
    name = "constants",
    version = "5.0.0",
    enabledByDefault = false,
    stage = 30
}

local binary = {
    [K.AddExpression] = Ast.AddExpression,
    [K.SubExpression] = Ast.SubExpression,
    [K.MulExpression] = Ast.MulExpression,
    [K.DivExpression] = Ast.DivExpression,
    [K.ModExpression] = Ast.ModExpression,
    [K.StrCatExpression] = Ast.StrCatExpression,
    [K.LessThanExpression] = Ast.LessThanExpression,
    [K.GreaterThanExpression] = Ast.GreaterThanExpression,
    [K.LessThanOrEqualsExpression] = Ast.LessThanOrEqualsExpression,
    [K.GreaterThanOrEqualsExpression] = Ast.GreaterThanOrEqualsExpression,
    [K.NotEqualsExpression] = Ast.NotEqualsExpression,
    [K.EqualsExpression] = Ast.EqualsExpression
}

local unary = {
    [K.NotExpression] = Ast.NotExpression,
    [K.NegateExpression] = Ast.NegateExpression,
    [K.LenExpression] = Ast.LenExpression
}

 
 
local SAFE_INTEGER = 100000000
local MAX_FACTOR = 97
local BOOLEAN_VARIANTS = 4

local function isLiteral(node)
    if not node then
        return false
    end

    return node.kind == K.NumberExpression
        or node.kind == K.StringExpression
        or node.kind == K.BooleanExpression
        or node.kind == K.NilExpression
end

local function randomInt(c, min, max)
    return c.random:integer(min, max)
end

local function number(value)
    return Ast.NumberExpression(value)
end

local function add(lhs, rhs)
    return Ast.AddExpression(lhs, rhs, false)
end

local function sub(lhs, rhs)
    return Ast.SubExpression(lhs, rhs, false)
end

local function mul(lhs, rhs)
    return Ast.MulExpression(lhs, rhs, false)
end

local function div(lhs, rhs)
    return Ast.DivExpression(lhs, rhs, false)
end

local function decomposition(value, c)
    local count = randomInt(c, 3, 5)
    local parts = {}
    local remaining = value

    for i = 1, count - 1 do
        local piece = randomInt(c, -1000000, 1000000)
        parts[#parts + 1] = piece
        remaining = remaining - piece
    end

    parts[#parts + 1] = remaining
    return parts
end

local function additive(value, c)
    local parts = decomposition(value, c)
    local result = number(parts[1])

    if c.random:boolean(0.5) then
        for i = 2, #parts do
            result = add(result, number(parts[i]))
        end
    else
        for i = 2, #parts do
            result = sub(result, number(-parts[i]))
        end
    end

    return result
end


local function obfuscateInteger(value, c)
    if type(value) ~= "number"
        or value ~= math.floor(value)
        or math.abs(value) > SAFE_INTEGER
    then
        return nil
    end

     
     
     
     
     
    if value >= 0 and c.random:boolean(0.25) then
        local root = math.floor(math.sqrt(value))
        if root * root == value and root <= 10000 then
            local exponent = c.random:boolean(0.5) and 2 or 2.0
            return Ast.PowExpression(
                number(root),
                number(exponent),
                false
            )
        end
    elseif value < 0 and c.random:boolean(0.18) then
        local magnitude = -value
        local root = math.floor(math.sqrt(magnitude))
        if root * root == magnitude and root <= 10000 then
            local exponent = c.random:boolean(0.5) and 2 or 2.0
            local power = Ast.PowExpression(
                number(root),
                number(exponent),
                false
            )
            return Ast.NegateExpression(power, false)
        end
    end

     
     
    if c.random:boolean(0.65) then
        return additive(value, c)
    end

    local offset = randomInt(c, -1000, 1000)
    local factor = randomInt(c, 3, MAX_FACTOR)

    local shifted = additive(value + offset, c)
    local scaled = mul(shifted, number(factor))
    local restored = div(scaled, number(factor))

    return sub(restored, number(offset))
end


local function obfuscateBoolean(value, c)
    if type(value) ~= "boolean" then
        return nil
    end

    local left = randomInt(c, 2, 97)
    local right = left
    local a = obfuscateInteger(left, c) or number(left)
    local b

    if value then
        local variant = randomInt(c, 1, BOOLEAN_VARIANTS)
        if variant == 1 then
            b = obfuscateInteger(right, c) or number(right)
            return Ast.EqualsExpression(a, b, false)
        elseif variant == 2 then
            b = obfuscateInteger(right - 1, c) or number(right - 1)
            return Ast.NotEqualsExpression(a, b, false)
        elseif variant == 3 then
            b = obfuscateInteger(right - 1, c) or number(right - 1)
            return Ast.GreaterThanExpression(a, b, false)
        else
            b = obfuscateInteger(right - 1, c) or number(right - 1)
            return Ast.LessThanExpression(b, a, false)
        end
    end

    local variant = randomInt(c, 1, BOOLEAN_VARIANTS)
    if variant == 1 then
        b = obfuscateInteger(right - 1, c) or number(right - 1)
        return Ast.EqualsExpression(a, b, false)
    elseif variant == 2 then
        b = obfuscateInteger(right, c) or number(right)
        return Ast.NotEqualsExpression(a, b, false)
    elseif variant == 3 then
        b = obfuscateInteger(right - 1, c) or number(right - 1)
        return Ast.LessThanExpression(a, b, false)
    else
        b = obfuscateInteger(right, c) or number(right)
        return Ast.GreaterThanExpression(a, b, false)
    end
end


local function foldBinary(node)
    local ctor = binary[node.kind]

    if not ctor
        or not isLiteral(node.lhs)
        or not isLiteral(node.rhs)
    then
        return nil
    end

    local ok, result = pcall(
        ctor,
        node.lhs,
        node.rhs,
        true
    )

    if ok and result then
        return result
    end

    return nil
end

local function foldUnary(node)
    local ctor = unary[node.kind]

    if not ctor or not isLiteral(node.rhs) then
        return nil
    end

    local ok, result = pcall(
        ctor,
        node.rhs,
        true
    )

    if ok and result then
        return result
    end

    return nil
end

function M.transform(ast, c)
    local folded = 0
    local obfuscated = 0

    ast = visitAst(
        ast,
        nil,
        function(node)
            local result = foldBinary(node)

            if result then
                folded = folded + 1
                node = result
            else
                result = foldUnary(node)

                if result then
                    folded = folded + 1
                    node = result
                end
            end

            if node.kind == K.NumberExpression then
                local replacement =
                    obfuscateInteger(node.value, c)

                if replacement then
                    obfuscated = obfuscated + 1
                    return replacement
                end
            elseif node.kind == K.BooleanExpression then
                local replacement =
                    obfuscateBoolean(node.value, c)

                if replacement then
                    obfuscated = obfuscated + 1
                    return replacement
                end
            end

            return node
        end,
        {}
    )

    c:recordStatistic("constants.folded", folded)
    c:recordStatistic("constants.obfuscated", obfuscated)
    c:recordPass("constants")

    return ast
end

return M
