local StepNumbers = require("prometheus.steps.NumbersToExpressions")
local StepConstantArray = require("prometheus.steps.ConstantArray")
local StepEncryptStrings = require("prometheus.steps.EncryptStrings")

local M = {
    name = "prometheus",
    version = "2.0.0",
    enabledByDefault = false,
    stage = 50
}

local function applyStep(stepClass, settings, ast, seed)
    local step = stepClass:new(settings or {})

     
     
    if seed then
        math.randomseed(seed)
    end

    local result = step:apply(ast)
    return result or ast
end

function M.transform(ast, c)
    local cfg = c.config.prometheus or {}

    if cfg.numbers ~= false then
        ast = applyStep(
            StepNumbers,
            {
                Threshold = cfg.numberThreshold or 0.85,
                InternalThreshold = cfg.numberInternalThreshold or 0.20,
                NumberRepresentationMutation = false,
                AllowedNumberRepresentations = {"normal", "scientific", "hex"}
            },
            ast,
            c:getSeed()
        )
        c:recordStatistic("prometheus.numbers", 1)
    end

    if cfg.constantArray ~= false then
        ast = applyStep(
            StepConstantArray,
            {
                Threshold = cfg.constantThreshold or 0.45,
                StringsOnly = false,
                Shuffle = true,
                Rotate = true,
                LocalWrapperThreshold = 0,
                LocalWrapperCount = 0,
                Encoding = "mixed"
            },
            ast,
            c:getSeed() + 1
        )
        c:recordStatistic("prometheus.constant_array", 1)
    end

    if cfg.encryptStrings == true then
        ast = applyStep(
            StepEncryptStrings,
            {
                Variant = c.random:integer(1, 3)
            },
            ast,
            c:getSeed() + 2
        )
        c:recordStatistic("prometheus.encrypt_strings", 1)
    else
        c:recordStatistic("prometheus.encrypt_strings", 0)
    end

     
     
     
     
    c:recordStatistic("prometheus.steps", 1)
    c:recordStatistic("prometheus.vmify", 0)
    c:recordPass("prometheus")

    return ast
end

return M
