local LegacyVmify = require("prometheus.steps.Vmify")
local Ast = require("prometheus.ast")
local visitAst = require("prometheus.visitast")
local K = Ast.AstKind

local M = {
    name = "vmify",
    version = "1.3.0",
    enabledByDefault = false,
    stage = 80
}

 
 
 
 
 
 
local function requiresVmFallback(ast)
     
     
     
     
    local hasClosure = false
    local hasIndexedAssignment = false

    visitAst(ast, nil, function(node)
        if node.kind == K.FunctionLiteralExpression
            or node.kind == K.LocalFunctionDeclaration
            or node.kind == K.FunctionDeclaration
        then
            local scope = node.body and node.body.scope
            if scope and scope.variablesFromHigherScopes then
                for _, refs in pairs(scope.variablesFromHigherScopes) do
                    for _, count in pairs(refs) do
                        if count and count > 0 then
                            hasClosure = true
                            break
                        end
                    end
                    if hasClosure then
                        break
                    end
                end
            end
        elseif node.kind == K.AssignmentIndexing then
            hasIndexedAssignment = true
        end

        return node
    end, {})

     
     
     
    return hasClosure or hasIndexedAssignment
end

function M.transform(ast, c)
    if requiresVmFallback(ast) then
        c:recordStatistic("vmify.skipped_unsupported", 1)
        c:diagnostic(
            "warning",
            "legacy Vmify skipped for unsupported closure/upvalue or indexed-assignment combination; source-level V3 obfuscation remains active"
        )
        return ast
    end

    local seed = tonumber(c:getSeed()) or 0
    math.randomseed(seed)

    local config = require("config")
    local alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local parts = {}
    for i = 1, 9 do
        local index = c.random:integer(1, #alphabet)
        parts[i] = alphabet:sub(index, index)
    end
    config.IdentPrefix = "__opsex_"

    local step = LegacyVmify:new({})
    local ok, result = pcall(step.apply, step, ast)
    if not ok then
        c:recordStatistic("vmify.failed", 1)
        c:diagnostic(
            "warning",
            "legacy Vmify failed; source-level V3 obfuscation output retained: " .. tostring(result)
        )
        return ast
    end

    c:recordStatistic("vmify.compiled", 1)
    c:recordPass("vmify")
    return result
end

return M
