local K = {
    "and", "break", "do", "else", "elseif", "end",
    "false", "for", "function", "if", "in", "local",
    "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while", "continue", "type",
    "export", "typeof"
}

local M = {
    name = "identifiers",
    version = "4.0.0",
    enabledByDefault = true,
    stage = 20
}

local ALPHABET = "abcdefghijklmnopqrstuvwxyz"
local ALPHABET_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
local OPSEX_IDENT_PREFIX = "__opsex_"

local function randomInt(c, min, max)
    return c.random:integer(min, max)
end

local function randomLetter(c)
    if c.random:boolean(0.35) then
        local index = randomInt(
            c,
            1,
            #ALPHABET_UPPER
        )

        return string.sub(
            ALPHABET_UPPER,
            index,
            index
        )
    end

    local index = randomInt(
        c,
        1,
        #ALPHABET
    )

    return string.sub(
        ALPHABET,
        index,
        index
    )
end

local function randomIdentifier(c, length)
    local result = randomLetter(c)

    for _ = 2, length do
        local choice = randomInt(c, 1, 4)

        if choice <= 3 then
            local index = randomInt(
                c,
                1,
                #ALPHABET
            )

            result = result .. string.sub(
                ALPHABET,
                index,
                index
            )
        else
            result = result .. tostring(
                randomInt(c, 0, 9)
            )
        end
    end

    return result
end

local function makeGenerator(c)
    local generated = {}

    return function(index)
         
         
         
         
        local length = randomInt(c, 6, 13)
        local name

        repeat
            name = randomIdentifier(c, length)
        until not generated[name]

        generated[name] = true

        return name
    end
end

function M.transform(ast, c)
    if not ast.globalScope then
        c:diagnostic(
            "warning",
            "AST has no global scope",
            "identifiers"
        )

        c:recordPass("identifiers")
        return ast
    end

    ast.globalScope:renameVariables({
        Keywords = K,
        prefix = OPSEX_IDENT_PREFIX,
        generateName = makeGenerator(c)
    })

    c:recordStatistic(
        "identifiers.renamed",
        1
    )

    c:recordPass("identifiers")

    return ast
end

return M