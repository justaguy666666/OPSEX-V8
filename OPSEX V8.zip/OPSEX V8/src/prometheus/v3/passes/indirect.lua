local Ast = require("prometheus.ast")
local visitAst = require("prometheus.visitast")
local K = Ast.AstKind

local M = {
    name = "indirect",
    version = "3.1.0",
    enabledByDefault = false,
    stage = 45
}

 
 
 
 
 
 
 
 
 
 
 
 

local function methodKey(name, c)
    local length = #name
    if length < 2 then
        return Ast.StringExpression(name)
    end

    local cut = c.random:integer(1, length - 1)
    local left = string.sub(name, 1, cut)
    local right = string.sub(name, cut + 1)

    return Ast.StrCatExpression(
        Ast.StringExpression(left),
        Ast.StringExpression(right),
        false
    )
end

local function cloneVariable(variable)
    return Ast.VariableExpression(variable.scope, variable.id)
end

local function propertyKey(name, c)
    local length = #name
    if length < 2 then
        return Ast.StringExpression(name)
    end

    local parts = {}
    local remaining = length
    local start = 1

    while remaining > 0 do
        local maxChunk = math.min(remaining, 4)
        local chunk = c.random:integer(1, maxChunk)
        parts[#parts + 1] = Ast.StringExpression(
            string.sub(name, start, start + chunk - 1)
        )
        start = start + chunk
        remaining = remaining - chunk
    end

    local result = parts[1]
    for i = 2, #parts do
        result = Ast.StrCatExpression(result, parts[i], false)
    end

    return result
end

local function transformIndex(node, c)
    if node.kind ~= K.IndexExpression then
        return node, false
    end

    local base = node.base
    local index = node.index

     
     
     
     
     
    if not base
        or base.kind ~= K.VariableExpression
        or not index
        or index.kind ~= K.StringExpression
        or type(index.value) ~= "string"
        or #index.value < 2
    then
        return node, false
    end

    if not c.random:boolean(0.65) then
        return node, false
    end

    node.index = propertyKey(index.value, c)
    return node, true
end

local function transformFunctionCall(node, c)
    if node.kind ~= K.FunctionCallExpression then
        return node, false
    end

     
     
     
     
     
     
     
     
     
     
     
     
     
    if (c.config and c.config.v5 == true)
        or (c.config and c.config.enabled and c.config.enabled.vmify)
    then
        return node, false
    end

    local base = node.base
     
     
     
     
     
    if not base or base.kind ~= K.VariableExpression then
        return node, false
    end

    if base.scope and base.scope.isGlobal then
        return node, false
    end

    if not c.random:boolean(0.45) then
        return node, false
    end

    local holder = Ast.TableConstructorExpression({
        Ast.TableEntry(Ast.VariableExpression(base.scope, base.id))
    })

     
     
     
    local selector
    local variant = c.random:integer(1, 3)

    if variant == 1 then
        selector = Ast.AddExpression(
            Ast.NumberExpression(1),
            Ast.NumberExpression(0),
            false
        )
    elseif variant == 2 then
        selector = Ast.SubExpression(
            Ast.NumberExpression(2),
            Ast.NumberExpression(1),
            false
        )
    else
        selector = Ast.ModExpression(
            Ast.NumberExpression(3),
            Ast.NumberExpression(2),
            false
        )
    end

    local indexed = Ast.IndexExpression(holder, selector)

    node.base = indexed
    return node, true
end

local function transformMethod(node, c)
    if node.kind ~= K.PassSelfFunctionCallExpression then
        return node, false
    end

    local base = node.base
    if not base or base.kind ~= K.VariableExpression then
        return node, false
    end

    local method = node.passSelfFunctionName
    if type(method) ~= "string" or #method < 2 then
        return node, false
    end

    local receiver = cloneVariable(base)
    local indexed = Ast.IndexExpression(
        cloneVariable(base),
        methodKey(method, c)
    )

    local args = {receiver}
    for _, arg in ipairs(node.args or {}) do
        args[#args + 1] = arg
    end

    return Ast.FunctionCallExpression(indexed, args), true
end

function M.transform(ast, c)
    local methodsChanged = 0
    local propertiesChanged = 0
    local functionsChanged = 0

    ast = visitAst(ast, nil, function(node)
        local replacement, didChange = transformFunctionCall(node, c)
        if didChange then
            functionsChanged = functionsChanged + 1
            return replacement
        end

        replacement, didChange = transformMethod(node, c)
        if didChange then
            methodsChanged = methodsChanged + 1
            return replacement
        end

        replacement, didChange = transformIndex(node, c)
        if didChange then
            propertiesChanged = propertiesChanged + 1
        end

        return replacement
    end, {})

    c:recordStatistic("indirect.functions", functionsChanged)
    c:recordStatistic("indirect.methods", methodsChanged)
    c:recordStatistic("indirect.properties", propertiesChanged)
    c:recordPass("indirect")

    return ast
end

return M
