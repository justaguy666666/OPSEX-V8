local Ast = require("prometheus.ast")
local K = Ast.AstKind

local M = {
    name = "normalize",
    version = "4.0.1",
    enabledByDefault = true,
    stage = 10
}

local normalizeExpression
local normalizeStatement
local normalizeBlock

local expressionKinds = {
    [K.BooleanExpression] = true,
    [K.NumberExpression] = true,
    [K.StringExpression] = true,
    [K.NilExpression] = true,
    [K.VarargExpression] = true,

    [K.OrExpression] = true,
    [K.AndExpression] = true,

    [K.LessThanExpression] = true,
    [K.GreaterThanExpression] = true,
    [K.LessThanOrEqualsExpression] = true,
    [K.GreaterThanOrEqualsExpression] = true,
    [K.NotEqualsExpression] = true,
    [K.EqualsExpression] = true,

    [K.StrCatExpression] = true,
    [K.AddExpression] = true,
    [K.SubExpression] = true,
    [K.MulExpression] = true,
    [K.DivExpression] = true,
    [K.ModExpression] = true,
    [K.PowExpression] = true,

    [K.NotExpression] = true,
    [K.LenExpression] = true,
    [K.NegateExpression] = true,

    [K.IndexExpression] = true,
    [K.AssignmentIndexing] = true,

    [K.FunctionCallExpression] = true,
    [K.PassSelfFunctionCallExpression] = true,

    [K.VariableExpression] = true,
    [K.AssignmentVariable] = true,

    [K.FunctionLiteralExpression] = true,
    [K.TableConstructorExpression] = true,
    [K.IfElseExpression] = true
}

local function isExpression(node)
    return type(node) == "table"
        and expressionKinds[node.kind] == true
end

local function normalizeList(list)
    if type(list) ~= "table" then
        return
    end

    for i, node in ipairs(list) do
        list[i] = normalizeExpression(node)
    end
end

normalizeExpression = function(node)
    if not isExpression(node) then
        return node
    end

    local k = node.kind

    if k == K.NotExpression
        or k == K.LenExpression
        or k == K.NegateExpression
    then
        node.rhs = normalizeExpression(node.rhs)

    elseif k == K.OrExpression
        or k == K.AndExpression
        or k == K.LessThanExpression
        or k == K.GreaterThanExpression
        or k == K.LessThanOrEqualsExpression
        or k == K.GreaterThanOrEqualsExpression
        or k == K.NotEqualsExpression
        or k == K.EqualsExpression
        or k == K.StrCatExpression
        or k == K.AddExpression
        or k == K.SubExpression
        or k == K.MulExpression
        or k == K.DivExpression
        or k == K.ModExpression
        or k == K.PowExpression
    then
        node.lhs = normalizeExpression(node.lhs)
        node.rhs = normalizeExpression(node.rhs)

    elseif k == K.IndexExpression
        or k == K.AssignmentIndexing
    then
        node.base = normalizeExpression(node.base)
        node.index = normalizeExpression(node.index)

    elseif k == K.FunctionCallExpression
        or k == K.PassSelfFunctionCallExpression
    then
        node.base = normalizeExpression(node.base)
        normalizeList(node.args)

    elseif k == K.FunctionLiteralExpression then
        normalizeBlock(node.body)

    elseif k == K.TableConstructorExpression then
        if type(node.entries) == "table" then
            for _, entry in ipairs(node.entries) do
                if type(entry) == "table" then
                    if entry.kind == K.TableEntry then
                        entry.value =
                            normalizeExpression(entry.value)

                    elseif entry.kind == K.KeyedTableEntry then
                        entry.key =
                            normalizeExpression(entry.key)

                        entry.value =
                            normalizeExpression(entry.value)
                    end
                end
            end
        end

    elseif k == K.IfElseExpression then
        node.condition =
            normalizeExpression(node.condition)

         
        node.true_value =
            normalizeExpression(node.true_value)

        if type(node.elseifs) == "table" then
            for _, elseifNode in ipairs(node.elseifs) do
                if type(elseifNode) == "table" then
                    elseifNode.condition =
                        normalizeExpression(
                            elseifNode.condition
                        )

                    if elseifNode.value ~= nil then
                        elseifNode.value =
                            normalizeExpression(
                                elseifNode.value
                            )
                    elseif elseifNode.true_value ~= nil then
                        elseifNode.true_value =
                            normalizeExpression(
                                elseifNode.true_value
                            )
                    end
                end
            end
        end

        node.false_value =
            normalizeExpression(node.false_value)
    end

    return node
end

local function normalizeElseifs(statement)
    if type(statement.elseifs) ~= "table" then
        statement.elseifs = {}
        return
    end

     
     
     
     
     
     
     
     

    for i, elseifNode in ipairs(statement.elseifs) do
        if type(elseifNode) == "table" then
            elseifNode.condition =
                normalizeExpression(
                    elseifNode.condition
                )

            if elseifNode.body then
                normalizeBlock(elseifNode.body)
            end

            statement.elseifs[i] = elseifNode
        end
    end
end

normalizeStatement = function(statement)
    if type(statement) ~= "table" then
        return statement
    end

    local k = statement.kind

    if k == K.AssignmentStatement then
        normalizeList(statement.lhs)
        normalizeList(statement.rhs)

    elseif k == K.CompoundAddStatement
        or k == K.CompoundSubStatement
        or k == K.CompoundMulStatement
        or k == K.CompoundDivStatement
        or k == K.CompoundPowStatement
        or k == K.CompoundModStatement
        or k == K.CompoundConcatStatement
    then
        statement.lhs =
            normalizeExpression(statement.lhs)

        statement.rhs =
            normalizeExpression(statement.rhs)

    elseif k == K.FunctionCallStatement
        or k == K.PassSelfFunctionCallStatement
    then
        if statement.base then
            statement.base =
                normalizeExpression(statement.base)
        elseif statement.expression then
            statement.expression =
                normalizeExpression(statement.expression)
        elseif statement.func then
            statement.func =
                normalizeExpression(statement.func)
        end

        normalizeList(statement.args)

    elseif k == K.ReturnStatement then
        normalizeList(statement.args)

    elseif k == K.LocalVariableDeclaration then
        normalizeList(statement.expressions)

    elseif k == K.IfStatement then
        statement.condition =
            normalizeExpression(statement.condition)

        normalizeBlock(statement.body)

        normalizeElseifs(statement)

        if statement.elsebody then
            normalizeBlock(statement.elsebody)
        end

    elseif k == K.WhileStatement then
        statement.condition =
            normalizeExpression(statement.condition)

        normalizeBlock(statement.body)

    elseif k == K.RepeatStatement then
        normalizeBlock(statement.body)

        statement.condition =
            normalizeExpression(statement.condition)

    elseif k == K.ForStatement then
        statement.initialValue =
            normalizeExpression(
                statement.initialValue
            )

        statement.finalValue =
            normalizeExpression(
                statement.finalValue
            )

        statement.incrementBy =
            normalizeExpression(
                statement.incrementBy
            )

        normalizeBlock(statement.body)

    elseif k == K.ForInStatement then
        normalizeList(statement.expressions)
        normalizeBlock(statement.body)

    elseif k == K.DoStatement then
        normalizeBlock(statement.body)

    elseif k == K.FunctionDeclaration
        or k == K.LocalFunctionDeclaration
    then
        normalizeBlock(statement.body)
    end

    return statement
end

normalizeBlock = function(block)
    if not block or block.kind ~= K.Block then
        return block
    end

    if type(block.statements) ~= "table" then
        block.statements = {}
        return block
    end

    for i, statement in ipairs(block.statements) do
        block.statements[i] =
            normalizeStatement(statement)
    end

    return block
end

function M.transform(ast, c)
    local block = ast

    if ast and ast.kind == K.TopNode then
        block = ast.body
    end

    if block and block.kind == K.Block then
        normalizeBlock(block)
    end

    c:recordPass("normalize")

    return ast
end

return M