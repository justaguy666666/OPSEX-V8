local M = {}

local function hasPass(history, name)
    for _, pass in ipairs(history or {}) do
        if pass == name then
            return true
        end
    end

    return false
end

function M.create(ctx)
    local s = ctx.statistics or {}
    local history = ctx.history or {}
    local vm = hasPass(history, "vmify")
    local vmSkipped = (s["vmify.skipped_unsupported"] or 0) > 0
    local vmFailed = (s["vmify.failed"] or 0) > 0

    local vmStatus
    if vm then
        vmStatus = "ENABLED — custom VM compiler integrated"
    elseif vmSkipped then
        vmStatus = "PARTIALLY ENABLED — legacy VM skipped for unsupported AST combination"
    elseif vmFailed then
        vmStatus = "PARTIALLY ENABLED — legacy VM failed; source-level V3 output retained"
    else
        vmStatus = "NOT EXECUTED"
    end

    return {
        mode = "v3-standard",
        pipeline = history,
        passes = history,
        statistics = s,
        vmify = vmStatus,
        deterministic = true
    }
end

return M
