 
local R = require("prometheus.v3.random")

local C = {}

function C.create(config)
    config = config or {}

    local seed = tonumber(config.seed) or 0

    local context = {
        config = config,
        seed = seed,

        history = {},
        statistics = {},
        diagnostics = {},

        random = R.new(seed)
    }

    function context:recordPass(name)
        self.history[#self.history + 1] = name
    end

    function context:recordStatistic(name, value)
        if value == nil then
            value = 1
        end

        self.statistics[name] =
            (self.statistics[name] or 0) + value
    end

    function context:diagnostic(level, message)
        self.diagnostics[#self.diagnostics + 1] = {
            level = level,
            message = message
        }
    end

    function context:getSeed()
        return self.seed
    end

    function context:nextRandom()
        return self.random:next()
    end

    function context:nextRandomInt(a, b)
        return self.random:integer(a, b)
    end

    return context
end

return C
  
