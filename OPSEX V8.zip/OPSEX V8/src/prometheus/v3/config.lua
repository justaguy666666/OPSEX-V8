local C = {}

 
 
 
 
 
 
local STANDARD = {
    name = "v3-standard",

    order = {
        "normalize",
        "identifiers",
        "constants",
        "strings",
        "indirect",
        "structure",
        "prometheus",
        "controlflow",
        "cleanup",
        "vmify"
    },

    enabled = {
        normalize = true,
        identifiers = true,
        constants = true,
        strings = true,
        indirect = true,
        structure = true,
        prometheus = true,
        controlflow = true,
        cleanup = true,
        vmify = true
    },

     
     
     
    prometheus = {
        numbers = true,
        numberThreshold = 0.65,
        numberInternalThreshold = 0.20,
        constantArray = false,
        splitStrings = false,
        encryptStrings = false
    }
}

local defaults = {
    seed = 0,
    enabled = {},
    order = {}
}

local function copy(value)
    if type(value) ~= "table" then
        return value
    end

    local result = {}
    for key, item in pairs(value) do
        result[key] = copy(item)
    end

    return result
end

local function merge(base, override)
    local result = copy(base)

    if type(override) ~= "table" then
        return result
    end

    for key, value in pairs(override) do
        if type(value) == "table"
            and type(result[key]) == "table"
        then
            result[key] = merge(result[key], value)
        else
            result[key] = copy(value)
        end
    end

    return result
end

function C.create(options)
    options = options or {}

    if options.preset and options.preset ~= "v3-standard" then
        error("V3 has one mode: v3-standard")
    end

    local config = merge(defaults, STANDARD)
    config.preset = "v3-standard"

    return merge(config, options)
end

function C.get(name)
    if name == "v3-standard" then
        return STANDARD
    end

    return nil
end

function C.has(name)
    return name == "v3-standard"
end

function C.list()
    return {"v3-standard"}
end

function C.presets()
    return {
        ["v3-standard"] = STANDARD
    }
end

C.defaults = defaults

return C
