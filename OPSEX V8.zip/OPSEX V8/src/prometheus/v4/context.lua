local Random = require("prometheus.v3.random")

local C = {}
function C.create(config)
    local c = {
        config = config,
        seed = tonumber(config.seed) or 0,
        random = Random.new(tonumber(config.seed) or 0),
        history = {},
        statistics = {},
        diagnostics = {},
        analysis = nil,
        plan = nil,
    }
    function c:pass(name) self.history[#self.history + 1] = name end
    function c:stat(name, n) self.statistics[name] = (self.statistics[name] or 0) + (n or 1) end
    function c:recordStatistic(name, n) self.statistics[name] = (self.statistics[name] or 0) + (n or 1) end
    function c:recordPass(name) self.history[#self.history + 1] = name end
    function c:warn(msg) self.diagnostics[#self.diagnostics + 1] = {level="warning", message=msg} end
    function c:nextRandomInt(a,b) return self.random:integer(a,b) end
    function c:nextRandom() return self.random:next() end
    return c
end
return C
