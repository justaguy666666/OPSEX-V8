 
 
 
 
 

local Transformations = {}

local function copyArray(t)
    local out = {}
    if not t then
        return out
    end

    for i = 1, #t do
        out[i] = t[i]
    end

    return out
end

local function cloneInstruction(ins)
    local out = {}

    if type(ins) ~= "table" then
        return ins
    end

    for k, v in pairs(ins) do
        out[k] = v
    end

    return out
end

local function cloneInstructions(instructions)
    local out = {}

    if not instructions then
        return out
    end

    for i = 1, #instructions do
        out[i] = cloneInstruction(instructions[i])
    end

    return out
end

local function hasSideEffects(region)
    return region
        and (
            region.sideEffects == true
            or region.hasSideEffects == true
            or (region.effects and #region.effects > 0)
        )
end

local function isSafeForReordering(region)
    if not region then
        return false
    end

    if hasSideEffects(region) then
        return false
    end

    if region.captures and #region.captures > 0 then
        return false
    end

    if region.externalReferences and #region.externalReferences > 0 then
        return false
    end

    return true
end

local function reverseIndependentInstructions(region)
    local instructions = region.instructions

    if not instructions or #instructions < 2 then
        return false
    end

    if not isSafeForReordering(region) then
        return false
    end

    local reversed = {}

    for i = #instructions, 1, -1 do
        reversed[#reversed + 1] = cloneInstruction(instructions[i])
    end

    region.originalInstructions = instructions
    region.instructions = reversed
    region.transformationApplied = true
    region.transformation = "independent-order"

    return true
end

local function rotateStraightLineRegion(region)
    local instructions = region.instructions

    if not instructions or #instructions < 3 then
        return false
    end

    if not isSafeForReordering(region) then
        return false
    end

    local rotated = {}

     
     
     
    for i = 2, #instructions do
        rotated[#rotated + 1] = cloneInstruction(instructions[i])
    end

    rotated[#rotated + 1] = cloneInstruction(instructions[1])

    region.originalInstructions = instructions
    region.instructions = rotated
    region.transformationApplied = true
    region.transformation = "straight-line-rotation"

    return true
end

local function annotateRegion(region, name)
    region.v4Transformation = name
    region.v4Transformed = true

    if not region.transformations then
        region.transformations = {}
    end

    region.transformations[#region.transformations + 1] = name
end

local function transformStraightLine(region, rng)
    if not region then
        return false
    end

    if region.kind ~= "straight-line" then
        return false
    end

     
     
    if not region.reorderSafe and not isSafeForReordering(region) then
        return false
    end

    local choice = 0

    if rng and rng.nextRandomInt then
        choice = rng:nextRandomInt(0, 1)
    end

    local changed

    if choice == 0 then
        changed = reverseIndependentInstructions(region)
    else
        changed = rotateStraightLineRegion(region)
    end

    if changed then
        annotateRegion(region, "straight-line")
    end

    return changed
end

local function transformConditional(region)
    if not region or region.kind ~= "conditional" then
        return false
    end

     
     
     
    annotateRegion(region, "conditional-region")
    return true
end

local function transformLoop(region)
    if not region then
        return false
    end

    if region.kind ~= "loop" and region.kind ~= "nested-loop" then
        return false
    end

     
     
    annotateRegion(region, "loop-region")
    return true
end

local function transformFunction(region)
    if not region then
        return false
    end

    if region.kind ~= "function"
        and region.kind ~= "closure"
        and region.kind ~= "callback" then
        return false
    end

    annotateRegion(region, "function-region")
    return true
end

local function transformDataRegion(region, rng)
    if not region then
        return false
    end

    if region.kind ~= "table-heavy"
        and region.kind ~= "stateful" then
        return false
    end

     
     
    annotateRegion(region, "data-region")

    return true
end

local function transformAPIRegion(region)
    if not region or region.kind ~= "API-heavy" then
        return false
    end

     
     
     
    annotateRegion(region, "api-region")

    return true
end

function Transformations.apply(region, rng, options)
    options = options or {}

    if not region then
        return false
    end

    region.transformations = region.transformations or {}

    local changed = false

    if region.kind == "straight-line" then
        changed = transformStraightLine(region, rng)

    elseif region.kind == "conditional" then
        changed = transformConditional(region)

    elseif region.kind == "loop"
        or region.kind == "nested-loop" then
        changed = transformLoop(region)

    elseif region.kind == "function"
        or region.kind == "closure"
        or region.kind == "callback" then
        changed = transformFunction(region)

    elseif region.kind == "table-heavy"
        or region.kind == "stateful" then
        changed = transformDataRegion(region, rng)

    elseif region.kind == "API-heavy" then
        changed = transformAPIRegion(region)
    end

    if changed then
        region.transformationCount =
            (region.transformationCount or 0) + 1
    end

    return changed
end

function Transformations.applyAll(regions, rng, options)
    local transformed = 0

    if not regions then
        return transformed
    end

    for i = 1, #regions do
        if Transformations.apply(regions[i], rng, options) then
            transformed = transformed + 1
        end
    end

    return transformed
end

function Transformations.describe(region)
    if not region then
        return "none"
    end

    if not region.transformations
        or #region.transformations == 0 then
        return "none"
    end

    return table.concat(region.transformations, ",")
end

return Transformations