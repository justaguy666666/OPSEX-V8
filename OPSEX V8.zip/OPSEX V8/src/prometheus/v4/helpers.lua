 
 
 
 

local Helpers = {}

local function key_for(region, index)
    local kind = tostring(region.kind or "unknown")
    local id = tostring(region.id or index)
    return kind .. ":" .. id
end

function Helpers.generate(regions, plans, seed)
    local helpers = {}
    local seen = {}

    for i, region in ipairs(regions or {}) do
        if region.v4_transformed then
            local key = key_for(region, i)
            if not seen[key] then
                seen[key] = true
                helpers[#helpers + 1] = {
                    id = "v4_helper_" .. tostring(i),
                    region = key,
                    kind = region.kind or "contextual",
                    seed = seed,
                    contract = {
                        inputs = region.inputs or {},
                        outputs = region.outputs or {},
                        captures = region.captures or {},
                        side_effects = region.side_effects or {},
                    },
                }
            end
        end
    end

    return helpers
end

return Helpers
