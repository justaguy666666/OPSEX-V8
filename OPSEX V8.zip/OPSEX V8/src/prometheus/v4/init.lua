return {
    Config=require("prometheus.v4.config"),
    Pipeline=require("prometheus.v4.pipeline"),
    Context=require("prometheus.v4.context"),
    Report=require("prometheus.v4.report"),
    apply=function(ast,config) return require("prometheus.v4.pipeline").run(ast,config) end
}
