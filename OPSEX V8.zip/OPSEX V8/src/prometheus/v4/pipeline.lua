local Config=require("prometheus.v4.config")
local Context=require("prometheus.v4.context")
local Analysis=require("prometheus.v4.analysis")
local CFG=require("prometheus.v4.cfg")
local IR=require("prometheus.v4.ir")
local Regions=require("prometheus.v4.regions")
local Planner=require("prometheus.v4.planner")
local Transforms=require("prometheus.v4.transforms")
local Validator=require("prometheus.v4.validator")
local visitAst=require("prometheus.visitast")
local Ast=require("prometheus.ast")
local K=Ast.AstKind
local V3Config=require("prometheus.v3.config")
local V3Context=require("prometheus.v3.context")
local P={}

local SOURCE_PASSES={
     
     
     
    "normalize","identifiers","indirect","cleanup"
}


local function vmSafeProgram(ast)
    local blocked = {
        [K.FunctionLiteralExpression]=true,
        [K.FunctionDeclaration]=true,
        [K.LocalFunctionDeclaration]=true,
        [K.VarargExpression]=true,
        [K.AssignmentIndexing]=true,
    }
    local unsafe = nil
    visitAst(ast,nil,function(node)
        if node and blocked[node.kind] then
            unsafe = node.kind
            return node
        end
        return node
    end,{})
    return unsafe == nil, unsafe
end

local function maybeVirtualize(ast,c)
    local p=c.config.planner or {}
    if not p.enableSelectiveVirtualization then
        c:stat("virtualization.regions",0)
        c:stat("virtualization.vm",0)
        return ast
    end

    if c.random:next() >= (p.virtualizationRate or 0) then
        c:stat("virtualization.regions",0)
        c:stat("virtualization.not_selected",1)
        return ast
    end

    local safe,reason=vmSafeProgram(ast)
    if not safe then
        c:stat("virtualization.regions",0)
        c:stat("virtualization.skipped_unsupported",1)
        c:warn("V4 VM skipped unsupported construct: "..tostring(reason))
        return ast
    end

    local seed=tonumber(c.seed) or 0
    local oldRandomSeed=math.randomseed
    math.randomseed(seed)
    local Compiler=require("prometheus.compiler.compiler")
    local ok,result=pcall(function()
        return Compiler:new({v5 = c.config.v5 == true}):compile(ast)
    end)
     
    math.randomseed(seed)
    if not ok or type(result)~="table" then
        c:stat("virtualization.regions",0)
        c:stat("virtualization.failed",1)
        c:warn("V4 VM compilation failed; safe source output retained: "..tostring(result))
        return ast
    end

    c:stat("virtualization.regions",1)
    c:stat("virtualization.vm",1)
    c:stat("virtualization.instructions",c.ir and c.ir.instructions or 0)
    c:stat("virtualization.micro_ops",result.__v4_vm_micro_ops or 0)
    c:stat("virtualization.branch_ops",result.__v4_vm_branch_ops or 0)
    c:stat("virtualization.branch_micro_ops",result.__v4_vm_branch_ops or 0)
    if result.__v5_vm_dispatch_strategy then
        c:stat("virtualization.dispatch_strategy." .. tostring(result.__v5_vm_dispatch_strategy), 1)
    end
    c:pass("v4-selective-vm")
    return result
end

local function runSourceObfuscation(ast,c)
    local cfg=V3Config.create({seed=c.seed or 0,preset="v3-standard"})
    cfg.v7 = c.config and c.config.v7 == true
    cfg.enabled.vmify=false
    cfg.prometheus=cfg.prometheus or {}
    cfg.prometheus.constantArray=false
    cfg.prometheus.encryptStrings=false
    cfg.prometheus.splitStrings=false
    cfg.prometheus.numbers=false
    cfg.prometheus.numberThreshold=0
    cfg.prometheus.numberInternalThreshold=0
    cfg.enabled.constants=false
    cfg.enabled.controlflow=false
    cfg.enabled.strings=false

    local v3=V3Context.create(cfg)
    for _,name in ipairs(SOURCE_PASSES) do
        local pass=require("prometheus.v3.passes."..name)
        local ok,result=pcall(pass.transform,ast,v3)
        if not ok then
            error("V4 source pass "..name.." failed: "..tostring(result),0)
        end
        if result then ast=result end
    end

    for name,value in pairs(v3.statistics or {}) do
        c:stat("v4.source."..name,value)
    end
    c:stat("v4.source-passes",#SOURCE_PASSES)
    c:pass("v4-source-obfuscation")
    return ast
end

function P.run(ast,config)
    config=Config.create(config)
    local c=Context.create(config)

     
     
     
     
    math.randomseed(tonumber(c.seed) or 0)

    c.analysis=Analysis.run(ast); c:pass("semantic-analysis")
    c.cfg=CFG.build(ast); c:pass("cfg")
    c.ir=IR.build(ast,c.cfg); c:pass("ir")
    c.regions=Regions.classify(ast,c.cfg,c.ir,c.analysis,config); c:pass("region-classification")
    c.plan=Planner.plan(c.analysis,c.regions,config,c.random); c:pass("transformation-planner")

     
     
    ast=runSourceObfuscation(ast,c)

     
     
     
    if config.v5 == true and not config.v6 then
        Transforms.protectStrings(ast,c)
        c:pass("v5-constant-hardening")
    end

     
     
     
     
    if (config.planner and config.planner.enableSelectiveVirtualization) then
        ast=maybeVirtualize(ast,c)
    else
         
        Transforms.apply(ast,c.plan,c); c:pass("region-transformations")
    end

    local ok,err=Validator.validate(ast)
    if not ok then error(err,0) end
    c:pass("validation")

    c:stat("regions.analyzed",#c.regions)
    if config.planner.enableMetrics then
        c:stat("metrics.ast-nodes",c.analysis and (c.analysis.statements or 0) or 0)
        c:stat("metrics.ir-values",c.ir.values or 0)
        c:stat("metrics.ir-side-effects",c.ir.sideEffects or 0)
        c:stat("metrics.ir-dependencies",c.ir.dependencies or 0)
        c:stat("metrics.cfg-branches",c.cfg.branches or 0)
        c:stat("metrics.cfg-loops",c.cfg.loops or 0)
    end
    local transformed=0
    for _,r in ipairs(c.regions) do
        if #(r.candidateTransformations or {})>0 then transformed=transformed+1 end
    end
    c:stat("regions.planned",transformed)
    c:stat("cfg.blocks",#c.cfg.blocks)
    c:stat("cfg.back_edges",c.cfg.backEdges)
    c:stat("ir.instructions",c.ir.instructions)
    return ast,c
end
return P

