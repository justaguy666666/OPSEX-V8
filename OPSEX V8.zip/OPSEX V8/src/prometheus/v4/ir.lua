local Ast=require("prometheus.ast")
local K=Ast.AstKind
local I={}

local function op(k)
    if k==K.LocalVariableDeclaration then return "def" end
    if k==K.AssignmentStatement then return "assign" end
    if k==K.FunctionCallStatement or k==K.PassSelfFunctionCallStatement then return "call" end
    if k==K.ReturnStatement then return "return" end
    if k==K.IfStatement then return "branch" end
    if k==K.WhileStatement or k==K.RepeatStatement or k==K.ForStatement or k==K.ForInStatement then return "loop" end
    if k==K.FunctionDeclaration or k==K.LocalFunctionDeclaration then return "function" end
    return "statement"
end

local function effectFor(node)
    local k=node and node.kind
    if k==K.FunctionCallStatement or k==K.PassSelfFunctionCallStatement
        or k==K.FunctionCallExpression or k==K.PassSelfFunctionCallExpression then
        return "call"
    end
    if k==K.AssignmentStatement then return "write" end
    if k==K.ReturnStatement then return "return" end
    if k==K.IfStatement then return "branch" end
    if k==K.WhileStatement or k==K.RepeatStatement or k==K.ForStatement or k==K.ForInStatement then return "loop" end
    if k==K.FunctionDeclaration or k==K.LocalFunctionDeclaration or k==K.FunctionLiteralExpression then return "closure" end
    return "local"
end

local function usesExpr(e,uses)
    if type(e)~="table" then return end
    if e.kind==K.VariableExpression or e.kind==K.AssignmentVariable then
        uses[#uses+1]={scope=e.scope,id=e.id}
    end
    for _,k in ipairs({"lhs","rhs","base","index","condition","true_value","false_value"}) do
        if e[k] then usesExpr(e[k],uses) end
    end
    for _,a in ipairs(e.args or {}) do usesExpr(a,uses) end
end

local function valueKey(v)
    if not v then return "?" end
    return tostring(v.scope)..":"..tostring(v.id)
end

function I.build(ast,cfg)
    local ir={blocks={},definitions=0,uses=0,instructions=0,values=0,sideEffects=0,dependencies=0}
    local valueMap={}
    local nextValue=0

    local function valueFor(ref)
        local key=valueKey(ref)
        if not valueMap[key] then
            nextValue=nextValue+1
            valueMap[key]={id=nextValue,scope=ref.scope,varId=ref.id}
            ir.values=nextValue
        end
        return valueMap[key]
    end

    for _,b in ipairs(cfg.blocks) do
        local ib={id=b.id,kind=b.kind,instructions={},succ=b.succ,pred=b.pred,loopDepth=b.loopDepth or 0}
        for _,st in ipairs(b.statements) do
            local ins={op=op(st.kind),kind=st.kind,ast=st,uses={},defs={},effect=effectFor(st),sideEffect=false}
            if ins.effect=="call" or ins.effect=="write" or ins.effect=="closure" or ins.effect=="loop" then
                ins.sideEffect=true
                ir.sideEffects=ir.sideEffects+1
            end
            if st.kind==K.LocalVariableDeclaration then
                for _,id in ipairs(st.ids or {}) do
                    local d={scope=st.scope,id=id,value=valueFor({scope=st.scope,id=id})}
                    ins.defs[#ins.defs+1]=d
                    ir.definitions=ir.definitions+1
                end
            elseif st.kind==K.AssignmentStatement then
                for _,lhs in ipairs(st.lhs or {}) do
                    if lhs.id then
                        local d={scope=lhs.scope,id=lhs.id,value=valueFor({scope=lhs.scope,id=lhs.id})}
                        ins.defs[#ins.defs+1]=d
                        ir.definitions=ir.definitions+1
                    end
                end
            end
            local exprs={}
            for _,e in ipairs(st.expressions or {}) do exprs[#exprs+1]=e end
            for _,e in ipairs(st.rhs or {}) do exprs[#exprs+1]=e end
            for _,e in ipairs(st.lhs or {}) do exprs[#exprs+1]=e end
            if st.base then exprs[#exprs+1]=st.base end
            if st.condition then exprs[#exprs+1]=st.condition end
            for _,e in ipairs(exprs) do usesExpr(e,ins.uses) end
            for i,u in ipairs(ins.uses) do
                u.value=valueFor(u)
                if i>1 then ir.dependencies=ir.dependencies+1 end
            end
            ir.uses=ir.uses+#ins.uses
            ir.instructions=ir.instructions+1
            ib.instructions[#ib.instructions+1]=ins
        end
        ir.blocks[#ir.blocks+1]=ib
    end
    return ir
end
return I
