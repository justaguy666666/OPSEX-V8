local P={}
local function add(a,x) a[#a+1]=x end

local function shuffle(a,rng)
    if not rng then return end
    for i=#a,2,-1 do
        local j=rng:integer(1,i)
        a[i],a[j]=a[j],a[i]
    end
end

function P.plan(analysis,regions,config,rng)
    local plan={mode="full-v4",regions={},seed=config.seed}
    local p=config.planner or {}
    for _,r in ipairs(regions) do
        local actions={}
        if r.type=="straight-line" then
            if p.enableDataflowTransform and r.complexity>=2 and rng:next()<p.dataflowRate then
                add(actions,"dataflow")
            end
        elseif r.type=="conditional" then
            if p.enableConditionTransform then add(actions,"condition-state") end
            if p.enableCfgRestructure and not r.metadata.hasReturn and not r.metadata.hasBreak
                and not r.metadata.hasContinue and not r.metadata.hasFunction and r.complexity<=p.maxRegionSize then
                if rng:next()<p.cfgRestructureRate then add(actions,"cfg-dispatch") end
            end
        elseif r.type=="loop" then
            add(actions,"loop-metadata")
        elseif r.type=="api-heavy" then
            add(actions,"call-region")
        elseif r.type=="table-heavy" then
            add(actions,"table-boundary")
        elseif r.type=="function" then
            add(actions,"scope-aware")
        end
        if r.metadata.definitions>0 and r.metadata.uses>0 then add(actions,"dependency-aware") end
        if #r.metadata.externalReferences>0 then add(actions,"external-aware") end
        if analysis and analysis.captures>0 and r.type~="loop" then add(actions,"capture-aware") end
        if r.metadata.hasReturn then add(actions,"return-aware") end
        if r.metadata.hasBreak or r.metadata.hasContinue then add(actions,"exit-aware") end
        if #actions>1 then shuffle(actions,rng) end
        r.candidateTransformations=actions
        plan.regions[#plan.regions+1]=r
    end
    return plan
end
return P
