 
 
 

local Emitter = {}

local function clone(value)
    if type(value) ~= "table" then
        return value
    end

    local out = {}
    for k, v in pairs(value) do
        out[k] = clone(v)
    end
    return out
end

local function emitInstruction(instruction)
    assert(type(instruction) == "table", "invalid V4 instruction")

    local node = {
        op = instruction.op,
        args = clone(instruction.args),
        value = clone(instruction.value),
        target = instruction.target,
        source = clone(instruction.source),
    }

    return node
end

local function emitRegion(region)
    assert(type(region) == "table", "invalid V4 region")
    assert(type(region.kind) == "string", "V4 region missing kind")

    local out = {
        id = region.id,
        kind = region.kind,
        instructions = {},
        inputs = clone(region.inputs),
        outputs = clone(region.outputs),
        captures = clone(region.captures),
        externalReferences = clone(region.externalReferences),
        sideEffects = clone(region.sideEffects),
        transformations = clone(region.transformations),
        reconstructed = region.reconstructed == true,
        emitted = true,
    }

    for i, instruction in ipairs(region.instructions or {}) do
        out.instructions[i] = emitInstruction(instruction)
    end

    return out
end

function Emitter.region(region)
    return emitRegion(region)
end

function Emitter.regions(regions)
    local out = {}

    for i, region in ipairs(regions or {}) do
        out[i] = emitRegion(region)
    end

    return out
end

function Emitter.build(reconstructed)
    assert(type(reconstructed) == "table",
        "V4 emitter requires reconstructed program")

    local regions = Emitter.regions(reconstructed.regions)

    local instructions = {}

    for _, region in ipairs(regions) do
        for _, instruction in ipairs(region.instructions) do
            instructions[#instructions + 1] = instruction
        end
    end

    return {
        regions = regions,
        instructions = instructions,
        regionCount = #regions,
        instructionCount = #instructions,
        emitted = true,
    }
end

function Emitter.validate(output)
    if type(output) ~= "table" then
        return false, "emitter output must be a table"
    end

    if output.emitted ~= true then
        return false, "emitter output is not marked emitted"
    end

    if type(output.regions) ~= "table" then
        return false, "emitter regions missing"
    end

    if type(output.instructions) ~= "table" then
        return false, "emitter instructions missing"
    end

    return true
end

return Emitter
