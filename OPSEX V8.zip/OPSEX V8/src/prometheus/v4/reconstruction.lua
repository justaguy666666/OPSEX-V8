 
 
 
 
 
 
 
 

local Reconstruction = {}

local function clone(value)
    if type(value) ~= "table" then
        return value
    end

    local out = {}

    for k, v in pairs(value) do
        out[k] = clone(v)
    end

    return out
end

local function cloneInstructions(instructions)
    local out = {}

    if not instructions then
        return out
    end

    for i = 1, #instructions do
        out[i] = clone(instructions[i])
    end

    return out
end

local function appendAll(dst, src)
    for i = 1, #src do
        dst[#dst + 1] = src[i]
    end
end

local function validateRegion(region)
    assert(type(region) == "table", "invalid V4 region")

    assert(
        type(region.kind) == "string",
        "V4 region is missing kind"
    )

    if region.instructions ~= nil then
        assert(
            type(region.instructions) == "table",
            "V4 region instructions must be a table"
        )
    end

    return true
end

local function reconstructRegion(region)
    validateRegion(region)

    local result = {
        id = region.id,
        kind = region.kind,
        instructions = cloneInstructions(region.instructions),
        transformations = clone(region.transformations),
        transformationCount = region.transformationCount or 0,
        reconstructed = true,
    }

     
    result.inputs = clone(region.inputs)
    result.outputs = clone(region.outputs)
    result.captures = clone(region.captures)
    result.externalReferences = clone(region.externalReferences)
    result.sideEffects = clone(region.sideEffects)
    result.scope = clone(region.scope)

    return result
end

function Reconstruction.region(region)
    return reconstructRegion(region)
end

function Reconstruction.regions(regions)
    local out = {}

    if not regions then
        return out
    end

    for i = 1, #regions do
        out[i] = reconstructRegion(regions[i])
    end

    return out
end

function Reconstruction.linearize(regions)
    local instructions = {}

    if not regions then
        return instructions
    end

    for i = 1, #regions do
        local region = reconstructRegion(regions[i])
        appendAll(instructions, region.instructions)
    end

    return instructions
end

function Reconstruction.validate(regions)
    if type(regions) ~= "table" then
        return false, "regions must be a table"
    end

    for i = 1, #regions do
        local ok, err = pcall(validateRegion, regions[i])

        if not ok then
            return false, "region " .. tostring(i) .. ": " .. tostring(err)
        end
    end

    return true
end

function Reconstruction.build(regions)
    local ok, err = Reconstruction.validate(regions)

    if not ok then
        return nil, err
    end

    return {
        regions = Reconstruction.regions(regions),
        instructions = Reconstruction.linearize(regions),
        regionCount = #regions,
        reconstructed = true,
    }
end

return Reconstruction