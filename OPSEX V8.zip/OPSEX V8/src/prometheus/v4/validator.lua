local Base=require("prometheus.v3.validator")
local V={}
function V.validate(ast)
    return Base.validate(ast,"v4")
end
return V
