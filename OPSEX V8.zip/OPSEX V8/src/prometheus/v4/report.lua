local Report = {}

function Report.create(ctx, inputSize, outputSize, compileTime)
    local statistics = {}

    if ctx and ctx.statistics then
        for name, value in pairs(ctx.statistics) do
            statistics[name] = value
        end
    end

    return {
        inputSize = inputSize or 0,
        outputSize = outputSize or 0,
        compileTime = compileTime or 0,

        deterministic = true,

        pipeline = ctx and ctx.history or {},

        statistics = statistics,

        diagnostics = ctx and ctx.diagnostics or {},
        seed = ctx and ctx.seed or 0,
    }
end

return Report