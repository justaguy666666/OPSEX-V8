 
 
 

local ok, Transform = pcall(require, "prometheus.v4.transform")
if not ok then
    Transform = require("prometheus.v4.transform")
end

local Integration = {}

function Integration.apply(regions, plans, rng)
    assert(type(regions) == "table", "V4 integration: regions must be a table")

    local transformed = Transform.apply_all(regions, plans or {}, rng)

    local transformed_count = 0
    for _, region in ipairs(transformed) do
        if region.v4_transformed then
            transformed_count = transformed_count + 1
        end
    end

    return transformed, {
        regions = #transformed,
        transformed = transformed_count,
    }
end

return Integration
