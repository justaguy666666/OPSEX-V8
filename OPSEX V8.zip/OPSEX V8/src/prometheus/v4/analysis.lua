local Ast = require("prometheus.ast")
local K = Ast.AstKind
local visitAst = require("prometheus.visitast")

local A = {}
local function inc(t,k,n) t[k]=(t[k] or 0)+(n or 1) end

local function exprInfo(node, out, currentFunction)
    if type(node) ~= "table" then return end
    inc(out.nodeKinds,node.kind)
    if node.kind==K.NumberExpression or node.kind==K.StringExpression or node.kind==K.BooleanExpression or node.kind==K.NilExpression then
        out.literals=out.literals+1
    elseif node.kind==K.VariableExpression or node.kind==K.AssignmentVariable then
        out.variableUses=out.variableUses+1
        local scope=node.scope
        if scope and scope.isGlobal then out.globalUses=out.globalUses+1 else out.localUses=out.localUses+1 end
        if currentFunction and scope and scope ~= currentFunction.scope then out.captures=out.captures+1 end
        if scope and scope.referenceCounts then out.references=out.references+1 end
    elseif node.kind==K.FunctionCallExpression or node.kind==K.PassSelfFunctionCallExpression then out.calls=out.calls+1
    elseif node.kind==K.TableConstructorExpression then out.tables=out.tables+1
    end
end

function A.run(ast)
    local o={nodeKinds={},functions=0,closures=0,calls=0,literals=0,tables=0,variableUses=0,localUses=0,globalUses=0,loops=0,branches=0,returns=0,assignments=0,blocks=0,statements=0,scopes=0,captures=0,references=0,sideEffectingCalls=0}
    local fnStack={}
    visitAst(ast,function(node,data)
        if node.kind==K.FunctionDeclaration or node.kind==K.LocalFunctionDeclaration or node.kind==K.FunctionLiteralExpression then
            fnStack[#fnStack+1]={scope=(node.body and node.body.scope) or data.scope,node=node}
            o.functions=o.functions+1
            if node.kind==K.FunctionLiteralExpression then o.closures=o.closures+1 end
        end
        if node.kind==K.Block then o.blocks=o.blocks+1 end
        if node.kind==K.IfStatement then o.branches=o.branches+1 end
        if node.kind==K.WhileStatement or node.kind==K.RepeatStatement or node.kind==K.ForStatement or node.kind==K.ForInStatement then o.loops=o.loops+1 end
        if node.kind==K.ReturnStatement then o.returns=o.returns+1 end
        if node.kind==K.AssignmentStatement then o.assignments=o.assignments+1 end
        if node.kind~=K.Block and node.kind~=K.TopNode then o.statements=o.statements+1 end
        exprInfo(node,o,fnStack[#fnStack])
        return node
    end,function(node)
        if node.kind==K.FunctionDeclaration or node.kind==K.LocalFunctionDeclaration or node.kind==K.FunctionLiteralExpression then fnStack[#fnStack]=nil end
        return node
    end,{})
    local function scopes(s)
        if not s then return end
        o.scopes=o.scopes+1
        for _,c in ipairs(s.children or {}) do scopes(c) end
    end
    scopes(ast.globalScope)
    return o
end
return A
