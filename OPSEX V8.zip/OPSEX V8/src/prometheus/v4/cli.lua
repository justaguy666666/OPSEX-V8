local Parser = require("prometheus.parser")
local Unparser = require("prometheus.unparser")
local V = require("prometheus.v4")
local E = require("prometheus.enums")
local Report = require("prometheus.v4.report")

local M = {}

M.Report = Report

function M.apply(source, luaVersion, pretty, seed, enableVm)
    local c = V.Config.create({
        seed = seed or 0,
        LuaVersion = luaVersion or E.LuaVersion.LuaU,
        PrettyPrint = pretty or false,
        planner = {
            enableSelectiveVirtualization = enableVm == true,
            virtualizationRate = enableVm and 1.0 or 0,
        }
    })

    local ast = Parser:new({
        LuaVersion = c.LuaVersion
    }):parse(source)

    local out, ctx = V.apply(ast, c)

    return Unparser:new({
        LuaVersion = c.LuaVersion,
        PrettyPrint = c.PrettyPrint
    }):unparse(out), ctx
end

return M