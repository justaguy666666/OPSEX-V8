local C = {}

local DEFAULT = {
    mode = "full-v4",
    seed = 0,
    LuaVersion = nil,
    PrettyPrint = false,
    planner = {
        maxRegionSize = 8,
        enableIdentifierTransform = true,
        enableDataflowTransform = true,
        enableConditionTransform = true,
        enableCfgRestructure = true,
        enableStringDiversification = true,
        enableStringProtection = true,
         
        enableSelectiveVirtualization = false,
        virtualizationRate = 0.45,
        virtualizationMaxOps = 18,
        enableMetrics = true,
        cfgRestructureRate = 0.45,
        stringStrategyRate = 1.0,
        dataflowRate = 0.25,
    }
}

local function copy(v)
    if type(v) ~= "table" then return v end
    local r = {}
    for k, x in pairs(v) do r[k] = copy(x) end
    return r
end

function C.create(options)
    options = options or {}
    local r = copy(DEFAULT)
    for k, v in pairs(options) do
        if type(v) == "table" and type(r[k]) == "table" then
            for a, b in pairs(v) do r[k][a] = copy(b) end
        else
            r[k] = copy(v)
        end
    end
    r.mode = "full-v4"
    return r
end

return C
