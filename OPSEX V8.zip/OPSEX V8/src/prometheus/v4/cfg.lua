local Ast=require("prometheus.ast")
local K=Ast.AstKind
local C={}
local function newBlock(g,kind,label)
    local b={id=#g.blocks+1,kind=kind or "basic",label=label or "",statements={},succ={},pred={},loopDepth=0}
    g.blocks[#g.blocks+1]=b; return b
end
local function link(a,b,label)
    if not a or not b then return end
    a.succ[#a.succ+1]={to=b.id,label=label}
    b.pred[#b.pred+1]=a.id
end
local function walkBlock(astBlock,g,entry,depth)
    local current=entry
    depth=depth or 0
    for _,st in ipairs(astBlock.statements or {}) do
        local k=st.kind
        if k==K.IfStatement then
            current.statements[#current.statements+1]=st
            local join=newBlock(g,"join","if-join"); local thenB=newBlock(g,"branch","then"); thenB.loopDepth=depth
            link(current,thenB,"true")
            walkBlock(st.body,g,thenB,depth)
            link(thenB.exit or thenB,join,"fallthrough")
            local prev=current
            for _,eif in ipairs(st.elseifs or {}) do
                local eb=newBlock(g,"branch","elseif"); link(prev,eb,"false/elseif"); walkBlock(eif.body,g,eb,depth); link(eb.exit or eb,join,"fallthrough"); prev=current
            end
            if st.elsebody then
                local elseB=newBlock(g,"branch","else"); link(current,elseB,"false"); walkBlock(st.elsebody,g,elseB,depth); link(elseB.exit or elseB,join,"fallthrough")
            else link(current,join,"false") end
            current=join
        elseif k==K.WhileStatement or k==K.RepeatStatement or k==K.ForStatement or k==K.ForInStatement then
            current.statements[#current.statements+1]=st
            local header=newBlock(g,"loop-header","loop"); link(current,header,"loop-enter")
            header.loopDepth=depth+1
            local body=newBlock(g,"loop-body","body"); body.loopDepth=depth+1
            local exit=newBlock(g,"loop-exit","exit"); link(header,body,"body"); link(header,exit,"exit")
            walkBlock(st.body,g,body,depth+1); link(body.exit or body,header,"back")
            g.backEdges=g.backEdges+1; current=exit
        else
            current.statements[#current.statements+1]=st
        end
    end
    current.exit=current
    return current
end
function C.build(ast)
    local g={blocks={},entry=nil,exits={},backEdges=0,branches=0,loops=0}
    local entry=newBlock(g,"entry","root"); g.entry=entry
    local exit=walkBlock(ast.body,g,entry,0)
    for _,b in ipairs(g.blocks) do
        if #b.succ==0 then g.exits[#g.exits+1]=b.id end
        if b.kind=="branch" or #b.succ>1 then g.branches=g.branches+1 end
        if b.kind=="loop-header" then g.loops=g.loops+1 end
    end
    g.exit=exit
    return g
end
return C
