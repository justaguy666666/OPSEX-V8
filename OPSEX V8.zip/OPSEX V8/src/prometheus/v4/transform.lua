 
 
 

local Transform = {}

local function copy_table(src)
    local dst = {}
    for k, v in pairs(src or {}) do
        if type(v) == "table" then
            dst[k] = copy_table(v)
        else
            dst[k] = v
        end
    end
    return dst
end

local function add_tag(region, tag)
    region.tags = region.tags or {}
    for _, existing in ipairs(region.tags) do
        if existing == tag then
            return
        end
    end
    region.tags[#region.tags + 1] = tag
end

local function annotate(region, name)
    region.transformations = region.transformations or {}
    region.transformations[#region.transformations + 1] = name
end

 
 
 
function Transform.apply(region, plan, rng)
    local out = copy_table(region)
    out.tags = out.tags or {}
    out.transformations = out.transformations or {}

    local kind = out.kind or "unknown"
    local complexity = tonumber(out.complexity) or 0
    local action = plan and (plan.action or plan.transform) or nil

    if kind == "straight-line" then
        add_tag(out, "v4.dataflow")
        annotate(out, action or "dataflow-restructure")
    elseif kind == "conditional" then
        add_tag(out, "v4.control")
        annotate(out, action or "region-control")
    elseif kind == "loop" or kind == "nested-loop" then
        add_tag(out, "v4.loop")
        annotate(out, action or "loop-region")
    elseif kind == "function" or kind == "closure" or kind == "callback" then
        add_tag(out, "v4.scope")
        annotate(out, action or "scope-aware")
    elseif kind == "table-heavy" then
        add_tag(out, "v4.table")
        annotate(out, action or "data-representation")
    elseif kind == "api-heavy" then
        add_tag(out, "v4.api")
        annotate(out, action or "api-representation")
    elseif kind == "stateful" then
        add_tag(out, "v4.state")
        annotate(out, action or "state-representation")
    else
        add_tag(out, "v4.contextual")
        annotate(out, action or "contextual")
    end

    out.v4_transformed = true
    out.transformation_complexity = complexity

    return out
end

function Transform.apply_all(regions, plans, rng)
    local result = {}
    for i, region in ipairs(regions or {}) do
        local plan = plans and plans[i] or nil
        result[i] = Transform.apply(region, plan, rng)
    end
    return result
end

return Transform
