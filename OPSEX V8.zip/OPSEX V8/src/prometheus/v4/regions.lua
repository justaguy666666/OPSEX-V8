local Ast = require("prometheus.ast")
local K = Ast.AstKind

local R = {}

local function addUnique(list, value, seen)
    if value == nil then return end
    if not seen[value] then
        seen[value] = true
        list[#list + 1] = value
    end
end

local function statementFlags(st, flags)
    local k = st and st.kind
    if not k then return end

    if k == K.FunctionCallStatement
        or k == K.PassSelfFunctionCallStatement
        or k == K.AssignmentStatement
        or k == K.LocalVariableDeclaration then
        flags.sideEffects = true
    end

    if k == K.ReturnStatement then flags.hasReturn = true end
    if k == K.BreakStatement then flags.hasBreak = true end
    if k == K.ContinueStatement then flags.hasContinue = true end

    if k == K.WhileStatement
        or k == K.RepeatStatement
        or k == K.ForStatement
        or k == K.ForInStatement then
        flags.hasLoop = true
    end

    if k == K.IfStatement then flags.hasBranch = true end

    if k == K.FunctionDeclaration
        or k == K.LocalFunctionDeclaration then
        flags.hasFunction = true
    end
end

local function classifyBlock(b, irBlock, analysis)
    local flags = {
        hasLoop = false,
        hasBranch = false,
        hasFunction = false,
        hasReturn = false,
        hasBreak = false,
        hasContinue = false,
        sideEffects = false,
        calls = 0,
        tableOps = 0,
    }

    for _, st in ipairs(b.statements or {}) do
        statementFlags(st, flags)
        local k = st.kind

        if k == K.FunctionCallStatement
            or k == K.PassSelfFunctionCallStatement
            or k == K.FunctionCallExpression
            or k == K.PassSelfFunctionCallExpression then
            flags.calls = flags.calls + 1
        end

        if k == K.TableConstructorExpression then
            flags.tableOps = flags.tableOps + 1
        end
    end

    if b.kind == "loop-header" or flags.hasLoop then
        return "loop", flags
    end
    if b.kind == "branch" or flags.hasBranch then
        return "conditional", flags
    end
    if flags.hasFunction then
        return "function", flags
    end
    if flags.tableOps > 0 then
        return "table-heavy", flags
    end
    if flags.calls >= 2 then
        return "api-heavy", flags
    end
    return "straight-line", flags
end

local function collectIRMetadata(irBlock)
    local inputs, outputs, inputSeen, outputSeen = {}, {}, {}, {}
    local captures, captureSeen = {}, {}
    local externalRefs, externalSeen = {}, {}
    local definitions = 0
    local uses = 0

    for _, ins in ipairs(irBlock and irBlock.instructions or {}) do
        for _, u in ipairs(ins.uses or {}) do
            uses = uses + 1
            local scope = u.scope
            local id = u.id
            if scope and scope.isGlobal then
                addUnique(externalRefs, id, externalSeen)
            else
                addUnique(inputs, id, inputSeen)
            end
            if scope and scope.isGlobal == false then
                 
                 
                 
            end
        end

        for _, d in ipairs(ins.defs or {}) do
            definitions = definitions + 1
            addUnique(outputs, d.id, outputSeen)
        end
    end

    return {
        inputs = inputs,
        outputs = outputs,
        captures = captures,
        externalReferences = externalRefs,
        definitions = definitions,
        uses = uses,
    }
end

local function addCandidates(region, analysis, config)
    local actions = {}
    local seen = {}

    local function add(x)
        if not seen[x] then
            seen[x] = true
            actions[#actions + 1] = x
        end
    end

    if region.type == "straight-line" then
        add("dataflow")
    elseif region.type == "conditional" then
        add("condition-state")
    elseif region.type == "loop" then
        add("loop-metadata")
    elseif region.type == "api-heavy" then
        add("call-region")
    elseif region.type == "table-heavy" then
        add("table-boundary")
    elseif region.type == "function" then
        add("scope-aware")
    end

    if region.metadata.definitions > 0 and region.metadata.uses > 0 then
        add("dependency-aware")
    end

    if #region.metadata.externalReferences > 0 then
        add("external-aware")
    end

    if analysis and analysis.captures and analysis.captures > 0
        and region.type ~= "loop" then
        add("capture-aware")
    end

    if region.metadata.hasReturn then add("return-aware") end
    if region.metadata.hasBreak or region.metadata.hasContinue then
        add("exit-aware")
    end

    region.candidateTransformations = actions
end

function R.classify(ast, cfg, ir, analysis, config)
    local out = {}
    local irById = {}

    for _, ib in ipairs(ir.blocks or {}) do
        irById[ib.id] = ib
    end

    for _, b in ipairs(cfg.blocks or {}) do
        local ib = irById[b.id]
        local insCount = #(ib and ib.instructions or {})
        local kind, flags = classifyBlock(b, ib, analysis)
        local md = collectIRMetadata(ib)

        md.hasReturn = flags.hasReturn
        md.hasBreak = flags.hasBreak
        md.hasContinue = flags.hasContinue
        md.hasLoop = flags.hasLoop
        md.hasBranch = flags.hasBranch
        md.sideEffects = flags.sideEffects
        md.calls = flags.calls
        md.tableOps = flags.tableOps

        local region = {
            id = b.id,
            type = kind,
            kind = kind,
            inputs = md.inputs,
            outputs = md.outputs,
            sideEffects = md.sideEffects and {"state"} or {},
            captures = md.captures,
            externalReferences = md.externalReferences,
            controlFlow = {
                successors = b.succ,
                predecessors = b.pred,
                loopDepth = b.loopDepth or 0,
                entryKind = b.kind,
            },
            complexity = insCount,
            metadata = md,
            candidateTransformations = {},
        }

        addCandidates(region, analysis, config)
        out[#out + 1] = region
    end

    return out
end

return R
