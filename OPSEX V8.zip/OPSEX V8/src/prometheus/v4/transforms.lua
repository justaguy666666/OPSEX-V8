local Ast = require("prometheus.ast")
local K = Ast.AstKind
local visitAst = require("prometheus.visitast")
local Scope = require("prometheus.scope")

local M = {}

local keywords = {
    "and","break","do","else","elseif","end","false","for","function",
    "if","in","local","nil","not","or","repeat","return","then","true",
    "until","while","continue","type","export","typeof"
}
local alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

local function name(c, used)
    repeat
        local n = c:nextRandomInt(8, 14)
        local out = alpha:sub(c:nextRandomInt(1, #alpha), c:nextRandomInt(1, #alpha))
        for _=2,n do
            local i=c:nextRandomInt(1,#alpha)
            out=out..alpha:sub(i,i)
        end
        if not used[out] then used[out]=true; return out end
    until false
end

local OPSEX_IDENT_PREFIX = "__opsex_"

local function rename(ast,c)
    if not ast or not ast.globalScope then return end
    local used={}
     
     
     
     
    ast.globalScope:renameVariables({
        Keywords=keywords,
        prefix=OPSEX_IDENT_PREFIX,
        generateName=function() return name(c,used) end
    })
    c:stat("identifiers.renamed")
end

local function globalMember(ast,name)
    local scope,id=ast.globalScope:resolveGlobal(name)
    return Ast.VariableExpression(scope,id)
end

local function member(base,key)
    return Ast.IndexExpression(base,Ast.StringExpression(key))
end

local function call(base,args)
    return Ast.FunctionCallExpression(base,args)
end

local function add(a,b) return Ast.AddExpression(a,b,false) end
local function sub(a,b) return Ast.SubExpression(a,b,false) end
local function mod(a,b) return Ast.ModExpression(a,b,false) end

local function encodedByte(byte,key)
    return (byte+key)%256
end

local function newGeneratedName(c, scope, tag)
    c._generatedNames = c._generatedNames or {}
    repeat
        c._generatedNames[tag] = (c._generatedNames[tag] or 0) + 1
        local n = c._generatedNames[tag]
        local prefix = (c.config and c.config.v7) and "__opsex_" or "v4_"
        local salt = (c.config and c.config.v7) and c:nextRandomInt(1000, 999999) or n
        local name = prefix .. tostring(salt) .. "_" .. tostring(n)
        if not scope:hasVariable(name) then
            return name
        end
    until false
end

local function decoderExpression(parentScope, values, key, variant, c, step)
     
     
     
     
    local fnScope=Scope:new(parentScope)
    local outId=fnScope:addVariable(newGeneratedName(c,fnScope,"str"))
    local loopId=fnScope:addVariable(newGeneratedName(c,fnScope,"idx"))
    local byteId=fnScope:addVariable(newGeneratedName(c,fnScope,"byte"))

    local outVar=Ast.VariableExpression(fnScope,outId)
    local loopVar=Ast.VariableExpression(fnScope,loopId)
    local byteVar=Ast.VariableExpression(fnScope,byteId)
    local vararg=Ast.VarargExpression()

    local selectScope,selectId=parentScope:resolveGlobal("select")
    local stringScope,stringId=parentScope:resolveGlobal("string")
    local selectFn=Ast.VariableExpression(selectScope,selectId)
    local stringVar=Ast.VariableExpression(stringScope,stringId)

    local argc=Ast.FunctionCallExpression(selectFn,{Ast.StringExpression("#"),vararg})
    local fetch=Ast.FunctionCallExpression(selectFn,{loopVar,vararg})

    local decoded
    if variant==2 then
        local offset=Ast.MulExpression(
            Ast.SubExpression(loopVar,Ast.NumberExpression(1),false),
            Ast.NumberExpression(step),false
        )
        decoded=Ast.ModExpression(
            Ast.AddExpression(
                Ast.SubExpression(byteVar,Ast.NumberExpression(key),false),
                offset,false
            ),Ast.NumberExpression(256),false
        )
    else
        local offset=Ast.MulExpression(loopVar,Ast.NumberExpression(step),false)
        decoded=Ast.ModExpression(
            Ast.AddExpression(
                Ast.SubExpression(byteVar,Ast.NumberExpression(key),false),
                offset,false
            ),Ast.NumberExpression(256),false
        )
    end

    local charCall=Ast.FunctionCallExpression(
        Ast.IndexExpression(stringVar,Ast.StringExpression("char")),
        {decoded}
    )
    local append=Ast.AssignmentStatement(
        {Ast.AssignmentVariable(fnScope,outId)},
        {Ast.StrCatExpression(outVar,charCall,false)}
    )

    local loopBody=Ast.Block({
        Ast.LocalVariableDeclaration(fnScope,{byteId},{fetch}),
        append,
    },fnScope)
    local loop=Ast.ForStatement(
        fnScope,loopId,
        Ast.NumberExpression(1),
        argc,
        Ast.NumberExpression(1),
        loopBody,
        fnScope
    )
    local body=Ast.Block({
        Ast.LocalVariableDeclaration(fnScope,{outId},{Ast.StringExpression("")}),
        loop,
        Ast.ReturnStatement({outVar}),
    },fnScope)
    local fn=Ast.FunctionLiteralExpression({Ast.VarargExpression()},body)
    return call(fn,values)
end

local function simpleStringExpression(ast,value,c,variant)
    local stringScope,stringId=ast.globalScope:resolveGlobal("string")
    local base=Ast.VariableExpression(stringScope,stringId)
    local char=member(base,"char")

     
     
     
     
    if c.config and c.config.v7 == true then
         
         
         
         
         
        local stringScope,stringId=ast.globalScope:resolveGlobal("string")
        local stringVar=Ast.VariableExpression(stringScope,stringId)
        local function member2(key)
            return Ast.IndexExpression(stringVar,Ast.StringExpression(key))
        end
        local char=member2("char")
        local format=member2("format")
        local reverse=member2("reverse")
        local sub=member2("sub")
        local rep=member2("rep")
        local family=c:nextRandomInt(1,6)
        local bytes={}
        for i=1,#value do bytes[i]=string.byte(value,i) end

        local function encodedByte(plain,i,mode)
            local salt=(family*41+i*17)%251
            if mode==1 then
                local e=(plain+salt)%256
                return Ast.ModExpression(
                    Ast.SubExpression(Ast.NumberExpression(e),Ast.NumberExpression(salt),false),
                    Ast.NumberExpression(256),false)
            elseif mode==2 then
                local e=(plain-salt)%256
                return Ast.ModExpression(
                    Ast.AddExpression(Ast.NumberExpression(e),Ast.NumberExpression(salt),false),
                    Ast.NumberExpression(256),false)
            else
                return Ast.NumberExpression(plain)
            end
        end

        local function charExpr(plain,i,mode)
            return call(char,{encodedByte(plain,i,mode)})
        end
        local function formatExpr(plain,i,mode)
            return call(format,{Ast.StringExpression("%c"),encodedByte(plain,i,mode)})
        end
        local function reverseTwice(expr)
            return call(reverse,{call(reverse,{expr})})
        end
        local function subIdentity(expr,n)
            return call(sub,{expr,Ast.NumberExpression(1),Ast.NumberExpression(n)})
        end

        if family==1 then
             
            local pieces={}; local pos=1
            while pos<=#bytes do
                local width=c:nextRandomInt(1,math.min(8,#bytes-pos+1))
                local args={}
                for i=pos,pos+width-1 do args[#args+1]=encodedByte(bytes[i],i,1) end
                pieces[#pieces+1]=call(char,args); pos=pos+width
            end
            local result=pieces[1] or Ast.StringExpression("")
            for i=2,#pieces do result=Ast.StrCatExpression(result,pieces[i],false) end
            return result,#bytes
        elseif family==2 then
             
            local result=nil
            for i,plain in ipairs(bytes) do
                local piece=formatExpr(plain,i,2)
                result=result and Ast.StrCatExpression(result,piece,false) or piece
            end
            return result or Ast.StringExpression(""),#bytes
        elseif family==3 then
             
             
            local pieces={}; local pos=1
            while pos<=#bytes do
                local width=c:nextRandomInt(1,5); local args={}; local last=math.min(pos+width-1,#bytes)
                for i=pos,last do args[#args+1]=encodedByte(bytes[i],i,2) end
                pieces[#pieces+1]=reverseTwice(call(char,args)); pos=last+1
            end
            local result=pieces[1] or Ast.StringExpression("")
            for i=2,#pieces do result=Ast.StrCatExpression(result,pieces[i],false) end
            return result,#bytes
        elseif family==4 then
             
             
            local pieces={}; local pos=1
            while pos<=#bytes do
                local width=c:nextRandomInt(1,7); local last=math.min(pos+width-1,#bytes); local args={}
                for i=pos,last do args[#args+1]=encodedByte(bytes[i],i,1) end
                pieces[#pieces+1]=subIdentity(call(char,args),last-pos+1); pos=last+1
            end
            local result=pieces[1] or Ast.StringExpression("")
            for i=2,#pieces do result=Ast.StrCatExpression(result,pieces[i],false) end
            return result,#bytes
        elseif family==5 then
             
             
            local result=nil
            for i,plain in ipairs(bytes) do
                local piece=call(rep,{charExpr(plain,i,1),Ast.NumberExpression(1)})
                result=result and Ast.StrCatExpression(result,piece,false) or piece
            end
            return result or Ast.StringExpression(""),#bytes
        else
             
             
            local result=nil; local pos=1
            while pos<=#bytes do
                local width=c:nextRandomInt(1,4); local last=math.min(pos+width-1,#bytes); local args={}
                for i=pos,last do args[#args+1]=encodedByte(bytes[i],i,2) end
                local piece
                if ((pos+family)%2)==0 then piece=call(char,args) else
                    local parts={}
                    for i=pos,last do parts[#parts+1]=formatExpr(bytes[i],i,1) end
                    piece=parts[1]
                    for j=2,#parts do piece=Ast.StrCatExpression(piece,parts[j],false) end
                end
                result=result and Ast.StrCatExpression(result,piece,false) or piece
                pos=last+1
            end
            return result or Ast.StringExpression(""),#bytes
        end
    end

     
     
     
     
    if c.config and c.config.v6 == true then
        local key = c:nextRandomInt(19, 237)
        local variant = c:nextRandomInt(1, 3)
        local chunks = {}
        local pos = 1
        local chunkSize = variant == 1 and #value or c:nextRandomInt(3, 11)
        while pos <= #value do
            local args = {}
            local last = math.min(pos + chunkSize - 1, #value)
            local localKey = variant == 2 and c:nextRandomInt(17, 239) or key
            local step = variant == 3 and c:nextRandomInt(1, 29) or 0
            for i = pos, last do
                local index = i - pos + 1
                local plain = string.byte(value, i)
                local encoded = (plain + localKey + ((i - 1) * step)) % 256
                local decoded = Ast.ModExpression(
                    Ast.SubExpression(
                        Ast.NumberExpression(encoded),
                        Ast.AddExpression(Ast.NumberExpression(localKey), Ast.NumberExpression((i - 1) * step), false),
                        false
                    ),
                    Ast.NumberExpression(256), false
                )
                args[#args + 1] = decoded
            end
            chunks[#chunks + 1] = call(char, args)
            pos = last + 1
        end
        local result = chunks[1] or Ast.StringExpression("")
        for i = 2, #chunks do result = Ast.StrCatExpression(result, chunks[i], false) end
        return result, #value
    end

     
     
     
     
    if c.config and c.config.v5 == true then
        local args = {}
        for i = 1, #value do
            args[#args + 1] = Ast.NumberExpression(string.byte(value, i))
        end
        if #args == 0 then
            return Ast.StringExpression(""), 0
        end
        local chunks = {}
        local chunkSize = 32
        local pos = 1
        while pos <= #args do
            local chunkArgs = {}
            local last = math.min(pos + chunkSize - 1, #args)
            for j = pos, last do
                chunkArgs[#chunkArgs + 1] = args[j]
            end
            chunks[#chunks + 1] = call(char, chunkArgs)
            pos = last + 1
        end
        local result = chunks[1]
        for i = 2, #chunks do
            result = Ast.StrCatExpression(result, chunks[i], false)
        end
        return result, #args
    end
    local key=c:nextRandomInt(17,239)
    local values={}
    if variant==1 then
        for i=1,#value do
            values[#values+1]=Ast.NumberExpression(encodedByte(string.byte(value,i),key))
        end
        local decoded={}
        for _,v in ipairs(values) do
            decoded[#decoded+1]=mod(sub(v,Ast.NumberExpression(key)),Ast.NumberExpression(256),false)
        end
        return call(char,decoded),#values
    end

     
     
     
    local step=c:nextRandomInt(1,31)
    for i=1,#value do
        local plain=string.byte(value,i)
        local encoded
        if variant==2 then
            encoded=(plain+key-((i-1)*step))%256
        else
            encoded=(plain+key-(i*step))%256
        end
        values[#values+1]=Ast.NumberExpression(encoded)
    end
    return decoderExpression(ast.globalScope,values,key,variant,c,step),#values
end

local function protectStrings(ast,c)
    if not c.config.planner.enableStringDiversification then return end
    local changed,bytes,strategies=0,0,{}
    visitAst(ast,nil,function(node,data)
        if node.kind~=K.StringExpression or type(node.value)~="string" or #node.value==0 then return node end
         
         
        if #node.value<=1 and c.random:next()<0.45 then return node end
        local variant=c:nextRandomInt(1,3)
        local expr,n=simpleStringExpression(ast,node.value,c,variant)
        changed=changed+1; bytes=bytes+n; strategies[variant]=(strategies[variant] or 0)+1
        return expr,true
    end,{})
    c:stat("literals.strings",changed)
    c:stat("literals.string-bytes",bytes)
    c:stat("literals.strategy-1",strategies[1] or 0)
    c:stat("literals.strategy-2",strategies[2] or 0)
    c:stat("literals.strategy-3",strategies[3] or 0)
end

local function containsKind(node,blocked)
    local seen={}
    local function walk(x)
        if type(x)~="table" or seen[x] then return false end
        seen[x]=true
        if x.kind and blocked[x.kind] then return true end
        local fields={"statements","body","elsebody","elseifs","expressions","rhs","lhs","args","condition","base","index","true_value","false_value","entries","value","key"}
        for _,field in ipairs(fields) do
            local v=x[field]
            if type(v)=="table" then
                if v.kind then
                    if walk(v) then return true end
                else
                    for _,item in pairs(v) do if walk(item) then return true end end
                end
            end
        end
        return false
    end
    return walk(node)
end

local function safePureExpression(node)
    if type(node) ~= "table" then return true end
    local blocked = {
        [K.FunctionCallExpression]=true,
        [K.PassSelfFunctionCallExpression]=true,
        [K.IndexExpression]=true,
        [K.AssignmentIndexing]=true,
        [K.FunctionLiteralExpression]=true,
    }
    local seen = {}
    local function walk(x)
        if type(x) ~= "table" or seen[x] then return true end
        seen[x] = true
        if x.kind and blocked[x.kind] then return false end
        for k,v in pairs(x) do
            if k ~= "scope" and k ~= "parentScope" and type(v) == "table" then
                if v.kind then
                    if not walk(v) then return false end
                else
                    for _,item in pairs(v) do
                        if type(item) == "table" and not walk(item) then return false end
                    end
                end
            end
        end
        return true
    end
    return walk(node)
end

local function safeAssignmentStatement(st)
    if st.kind ~= K.AssignmentStatement then return false end
    for _,lhs in ipairs(st.lhs or {}) do
        if lhs.kind ~= K.AssignmentVariable or not lhs.scope or lhs.scope.isGlobal then
            return false
        end
    end
    for _,rhs in ipairs(st.rhs or {}) do
        if not safePureExpression(rhs) then return false end
    end
    return true
end

local function safeLocalDeclaration(st)
    if st.kind ~= K.LocalVariableDeclaration then return false end
    for _,expr in ipairs(st.expressions or {}) do
        if not safePureExpression(expr) then return false end
    end
    return true
end

local function safeDispatchBlock(block, allowEffects)
    if not block then return false end
    if not allowEffects then
         
        local blocked = {
            [K.FunctionCallStatement]=true,[K.PassSelfFunctionCallStatement]=true,
            [K.ReturnStatement]=true,[K.BreakStatement]=true,[K.ContinueStatement]=true,
            [K.WhileStatement]=true,[K.RepeatStatement]=true,[K.ForStatement]=true,[K.ForInStatement]=true,
            [K.FunctionDeclaration]=true,[K.LocalFunctionDeclaration]=true,
            [K.FunctionLiteralExpression]=true,[K.AssignmentIndexing]=true,
            [K.IfStatement]=true,
        }
        for _,st in ipairs(block.statements or {}) do
            if blocked[st.kind] then return false end
            if st.kind == K.AssignmentStatement then
                if not safeAssignmentStatement(st) then return false end
            elseif st.kind == K.LocalVariableDeclaration then
                if not safeLocalDeclaration(st) then return false end
            elseif st.kind == K.CompoundAddStatement
                or st.kind == K.CompoundSubStatement
                or st.kind == K.CompoundMulStatement
                or st.kind == K.CompoundDivStatement
                or st.kind == K.CompoundModStatement
                or st.kind == K.CompoundPowStatement
                or st.kind == K.CompoundConcatStatement then
                return false
            end
        end
        return true
    end

     
     
     
     
     
    local allowed = {
        [K.FunctionCallStatement]=true, [K.PassSelfFunctionCallStatement]=true,
        [K.AssignmentStatement]=true, [K.LocalVariableDeclaration]=true,
        [K.CompoundAddStatement]=true, [K.CompoundSubStatement]=true,
        [K.CompoundMulStatement]=true, [K.CompoundDivStatement]=true,
        [K.CompoundModStatement]=true, [K.CompoundPowStatement]=true,
        [K.CompoundConcatStatement]=true,
    }
    local function containsFunctionLiteral(root)
        local seen = {}
        local function walk(node)
            if type(node) ~= "table" or seen[node] then return false end
            seen[node] = true
            if node.kind == K.FunctionLiteralExpression
                or node.kind == K.FunctionDeclaration
                or node.kind == K.LocalFunctionDeclaration then return true end
            for key, value in pairs(node) do
                if key ~= "scope" and key ~= "parentScope" and key ~= "globalScope"
                    and key ~= "parent" and key ~= "isAst" and type(value) == "table" then
                    if value.kind then
                        if walk(value) then return true end
                    else
                        for _, child in pairs(value) do
                            if type(child) == "table" and walk(child) then return true end
                        end
                    end
                end
            end
            return false
        end
        return walk(root)
    end
    for _, st in ipairs(block.statements or {}) do
        if not allowed[st.kind] or containsFunctionLiteral(st) then return false end
    end
    return true
end

local function newStateVar(scope,c)
    return scope:addVariable(newGeneratedName(c,scope,"state"))
end

local function cfgDispatch(ast,c)
    if not c.config.planner.enableCfgRestructure then return end
    local changed=0
    local allowEffects = c.config.planner.enableNestedCfgRestructure == true
    visitAst(ast,function(n)
         
         
         
        if (n.kind == K.FunctionLiteralExpression or n.kind == K.FunctionDeclaration
            or n.kind == K.LocalFunctionDeclaration) and n.__opsex_hot_callback then
            return n, true
        end
        return n
    end,function(n)
        if n.kind~=K.IfStatement or not n.body then return n end
        if #(n.elseifs or {})>0 then return n end
        if not safePureExpression(n.condition) then return n end
        if not safeDispatchBlock(n.body, allowEffects) then return n end
        if n.elsebody and not safeDispatchBlock(n.elsebody, allowEffects) then return n end

        local parent=n.body.scope and n.body.scope.parentScope
        if not parent then return n end

        local stateId=newStateVar(parent,c)
        local state=Ast.VariableExpression(parent,stateId)
         
         
        local declaration=Ast.LocalVariableDeclaration(parent,{stateId},{Ast.NumberExpression(1)})
        local setTwo=Ast.AssignmentStatement(
            {Ast.AssignmentVariable(parent,stateId)},
            {Ast.NumberExpression(2)}
        )
        local selectState=Ast.IfStatement(
            Ast.NotExpression(n.condition,false),
            Ast.Block({setTwo},n.body.scope),
            {},
            nil
        )

        local one=Ast.EqualsExpression(state,Ast.NumberExpression(1),false)
        local setZero=Ast.AssignmentStatement(
            {Ast.AssignmentVariable(parent,stateId)},
            {Ast.NumberExpression(0)}
        )

        local thenStatements={}
        for _,st in ipairs(n.body.statements or {}) do
            thenStatements[#thenStatements+1]=st
        end
        thenStatements[#thenStatements+1]=setZero

        local elseStatements={}
        for _,st in ipairs((n.elsebody and n.elsebody.statements) or {}) do
            elseStatements[#elseStatements+1]=st
        end
        elseStatements[#elseStatements+1]=setZero

        local dispatch=Ast.IfStatement(
            one,
            Ast.Block(thenStatements,n.body.scope),
            {},
            Ast.Block(elseStatements,(n.elsebody and n.elsebody.scope) or n.body.scope)
        )
        local loop=Ast.WhileStatement(
            Ast.Block({dispatch},Scope:new(parent)),
            Ast.NotExpression(Ast.EqualsExpression(state,Ast.NumberExpression(0),false),false),
            parent
        )

         
         
         
         
         
        local wrapper=Ast.DoStatement(
            Ast.Block({declaration,selectState,loop},parent)
        )

        changed=changed+1
        return wrapper
    end,{})
    c:stat("cfg.dispatch-rewrites",changed)
end

local function dataflow(ast,c)
    local changed=0
    if not c.config.planner.enableDataflowTransform then return end
    visitAst(ast,nil,function(n)
        if n.kind~=K.LocalVariableDeclaration or #n.ids~=1 or #n.expressions~=1 then return n end
        if n._v4DataflowGenerated then return n end
        if not c.random:boolean(c.config.planner.dataflowRate) then return n end
        local expr=n.expressions[1]
        if not expr or expr.kind~=K.VariableExpression then return n end
        if not expr.scope or expr.scope.isGlobal then return n end
        local scope=n.scope
        if not scope then return n end
         
         
         
         
         
         
        local carrier=Ast.TableConstructorExpression({
            Ast.TableEntry(expr)
        })
        local selectorVariant=c:nextRandomInt(1,3)
        local selector
        if selectorVariant==1 then
            selector=Ast.NumberExpression(1)
        elseif selectorVariant==2 then
            selector=Ast.AddExpression(Ast.NumberExpression(1),Ast.NumberExpression(0),false)
        else
            selector=Ast.SubExpression(Ast.NumberExpression(2),Ast.NumberExpression(1),false)
        end
        n.expressions[1]=Ast.IndexExpression(carrier,selector)
        n._v4DataflowGenerated=true
        changed=changed+1
        return n
    end,{})
    c:stat("dataflow.carriers",changed)
end

M.protectStrings = protectStrings

function M.apply(ast,plan,c)
    local seen={}
    for _,r in ipairs(plan.regions or {}) do
        for _,a in ipairs(r.candidateTransformations or {}) do seen[a]=true end
    end
    if c.config.planner.enableIdentifierTransform then rename(ast,c) end
    if seen["cfg-dispatch"] or (c.config.planner and c.config.planner.enableNestedCfgRestructure) then
        cfgDispatch(ast,c)
    end
    if seen["dataflow"] then dataflow(ast,c) end
    if c.config.planner.enableStringProtection == true then
        protectStrings(ast,c)
        c:pass("string-protection")
    end
    c:stat("planner.actions",0)
    local count=0
    for _,r in ipairs(plan.regions or {}) do count=count+#(r.candidateTransformations or {}) end
    c.statistics["planner.actions"]=count
    return ast
end

return M
