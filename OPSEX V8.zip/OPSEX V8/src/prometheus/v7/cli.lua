local Parser = require("prometheus.parser")
local Unparser = require("prometheus.unparser")
local E = require("prometheus.enums")
local Config = require("prometheus.v7.config")
local Pipeline = require("prometheus.v4.pipeline")
local Report = require("prometheus.v7.report")
local Compiler = require("prometheus.v6.compiler_phase10")
local V4Config = require("prometheus.v4.config")

local M = {}
M.Report = Report

 
 
 
 
local function vmOutputLooksUnsafe(node)
    local K = require("prometheus.ast").AstKind
    local seen = {}
    local function walk(x)
        if type(x) ~= "table" or seen[x] then return false end
        seen[x] = true
        if x.kind == K.IndexExpression and x.index and x.index.kind == K.NilExpression then
            return true
        end
        if x.kind == K.FunctionLiteralExpression then
            for _,arg in ipairs(x.args or {}) do
                if arg.kind ~= K.VarargExpression and (not arg.scope or arg.id == nil) then
                    return true
                end
            end
        elseif x.kind == K.VariableExpression and (not x.scope or x.id == nil) then
            return true
        end
        for k,v in pairs(x) do
            if k ~= "scope" and k ~= "parentScope" and type(v) == "table" then
                if v.kind then
                    if walk(v) then return true end
                else
                    for _,item in pairs(v) do
                        if walk(item) then return true end
                    end
                end
            end
        end
        return false
    end
    return walk(node)
end

local function sourceFallback(source, luaVer, pretty, config, seed)
     
     
     
    local ok, result = pcall(function()
        local cleanAst = Parser:new({LuaVersion=luaVer}):parse(source)
        local v4 = V4Config.create({seed=seed, LuaVersion=luaVer, PrettyPrint=pretty or false, planner=config.planner})
        v4.v5 = false
        v4.v6 = false
        v4.v7 = true
        return Pipeline.run(cleanAst, v4)
    end)
    if ok and result then return result end
    error(result or "V7 fallback compilation failed", 0)
end

function M.apply(source, luaVersion, pretty, seed, preset)
    local luaVer = luaVersion or E.LuaVersion.LuaU
    local buildSeed = tonumber(seed) or 0
    preset = preset or "v7"
    if preset ~= "v7" then error("V7 has one preset: v7", 0) end

    math.randomseed(buildSeed)
    local config = Config.create({seed=buildSeed, LuaVersion=luaVer, PrettyPrint=pretty or false, planner={}})
    local ast = Parser:new({LuaVersion=luaVer}):parse(source)
    local transformed, v4ctx = Pipeline.run(ast, config)

    math.randomseed(buildSeed)
    local usedFallback = false
     
     
     
     
    local largeScriptMode = false
    local out
    do
        local compiler = Compiler:new({v6=true, v7=true})
        local ok, compiled = pcall(function() return compiler:compile(transformed) end)
        if ok and type(compiled) == "table" and not vmOutputLooksUnsafe(compiled) then
            out = compiled
        else
             
             
             
             
             
             
            local retryOk, retryResult = pcall(function()
                local cleanAst = Parser:new({LuaVersion=luaVer}):parse(source)
                return Compiler:new({v6=true, v7=true}):compile(cleanAst)
            end)
            if retryOk and type(retryResult) == "table" then
                out = retryResult
                usedFallback = false
            else
                usedFallback = true
                out = sourceFallback(source, luaVer, pretty, config, buildSeed)
            end
        end
    end

    local result = Unparser:new({LuaVersion=luaVer, PrettyPrint=pretty or false}):unparse(out)
     
     
     
    if not usedFallback and (result:find("][nil]", 1, true) or result:find("[nil](", 1, true)) then
        usedFallback = true
        out = sourceFallback(source, luaVer, pretty, config, buildSeed)
        result = Unparser:new({LuaVersion=luaVer, PrettyPrint=pretty or false}):unparse(out)
    end
    local ctx = {
        v7=true, phase=1, seed=buildSeed, history=v4ctx.history or {},
        statistics=v4ctx.statistics or {}, diagnostics=v4ctx.diagnostics or {},
        vm={
            dispatch_strategy=out.__v6_vm_dispatch_strategy,
            representation_family=out.__v7_vm_representation_family,
            rolling_state=out.__v6_vm_rolling_state,
            block_count=out.__v6_vm_block_count,
            op_count=out.__v4_vm_op_count,
            branch_ops=out.__v4_vm_branch_ops,
            handler_count=out.__v5_vm_handler_count,
            route_count=out.__v6_vm_handler_route_count,
            register_count=out.__v7_vm_register_count,
            register_bank_width=out.__v7_vm_register_bank_width,
            decoy_count=out.__v7_vm_decoy_count,
            fallback=usedFallback,
            large_script_source_mode=largeScriptMode,
        }
    }
    ctx.history[#ctx.history+1] = largeScriptMode and "v7-large-script-source-mode" or (usedFallback and "v7-safe-source-fallback" or "v7-polymorphic-vm")
    ctx.statistics["v7.vm.large_script_source_mode"] = largeScriptMode and 1 or 0
    ctx.statistics["v7.vm.dispatch_strategy"] = out.__v6_vm_dispatch_strategy or 0
    ctx.statistics["v7.vm.representation_family"] = out.__v7_vm_representation_family or 0
    ctx.statistics["v7.vm.decoys"] = out.__v7_vm_decoy_count or 0
    ctx.statistics["v7.vm.fallback"] = usedFallback and 1 or 0
    return result, ctx
end

return M
