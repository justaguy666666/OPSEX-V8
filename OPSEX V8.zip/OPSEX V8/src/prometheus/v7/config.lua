local C = {}

local DEFAULT = {
    mode = "v7",
    seed = 0,
    LuaVersion = nil,
    PrettyPrint = false,
    v5 = true,
    v6 = true,
    v7 = true,
    vmSourceByteLimit = 2 * 1024 * 1024,
    planner = {
        maxRegionSize = 14,
        enableIdentifierTransform = true,
        enableDataflowTransform = true,
        enableConditionTransform = true,
        enableCfgRestructure = true,
        enableStringDiversification = true,
        enableSelectiveVirtualization = false,
        virtualizationRate = 0,
        cfgRestructureRate = 0.84,
        stringStrategyRate = 1.0,
        dataflowRate = 0.70,
        enableMetrics = true,
    }
}

local function copy(v)
    if type(v) ~= "table" then return v end
    local r = {}
    for k, x in pairs(v) do r[k] = copy(x) end
    return r
end

function C.create(options)
    options = options or {}
    local r = copy(DEFAULT)
    for k, v in pairs(options) do
        if type(v) == "table" and type(r[k]) == "table" then
            for a, b in pairs(v) do r[k][a] = copy(b) end
        else
            r[k] = copy(v)
        end
    end
    r.mode = "v7"
    r.v5 = true
    r.v6 = true
    r.v7 = true
    return r
end

return C
