local Parser = require("prometheus.parser")
local Unparser = require("prometheus.unparser")
local E = require("prometheus.enums")
local V4Config = require("prometheus.v4.config")
local V4Pipeline = require("prometheus.v4.pipeline")
local Report = require("prometheus.v5.report")
local Compiler = require("prometheus.v5.compiler_phase10_manual")

local M = {}
M.Report = Report

function M.apply(source, luaVersion, pretty, seed)
    local luaVer = luaVersion or E.LuaVersion.LuaU
    local buildSeed = tonumber(seed) or 0

     
     
     
     
    local config = V4Config.create({
        seed = buildSeed,
        LuaVersion = luaVer,
        PrettyPrint = pretty or false,
        v5 = true,
        planner = {
            enableIdentifierTransform = true,
            enableDataflowTransform = true,
            enableConditionTransform = true,
            enableCfgRestructure = true,
            enableStringDiversification = true,
            enableSelectiveVirtualization = false,
            virtualizationRate = 0,
            cfgRestructureRate = 0.45,
            stringStrategyRate = 1.0,
            dataflowRate = 0.25,
            enableMetrics = true,
        }
    })

    math.randomseed(buildSeed)
    local ast = Parser:new({LuaVersion = luaVer}):parse(source)
    local transformed, v4ctx = V4Pipeline.run(ast, config)

     
    math.randomseed(buildSeed)
    local compiler = Compiler:new()
    local out = compiler:compile(transformed)
    local result = Unparser:new({LuaVersion = luaVer, PrettyPrint = pretty or false}):unparse(out)

    local ctx = {
        v5 = true,
        phase = 10,
        seed = buildSeed,
        history = v4ctx.history or {},
        statistics = v4ctx.statistics or {},
        diagnostics = v4ctx.diagnostics or {},
        vm = {
            handler_indirection = out.__v5_vm_handler_indirection,
            handler_count = out.__v5_vm_handler_count,
            handler_route_indirection = out.__v6_vm_handler_route_indirection,
            handler_route_count = out.__v6_vm_handler_route_count,
            register_indirection = out.__v7_vm_register_indirection,
            register_count = out.__v7_vm_register_count,
            register_bank_width = out.__v7_vm_register_bank_width,
            branch_route_indirection = out.__v8_vm_branch_route_indirection,
            branch_route_count = out.__v8_vm_branch_route_count,
            context_indirection = out.__v9_vm_context_indirection,
            context_key_count = out.__v9_vm_context_key_count,
            op_count = out.__v4_vm_op_count,
            branch_ops = out.__v4_vm_branch_ops,
        }
    }
    ctx.history[#ctx.history + 1] = "v5-phase10-vm"
    ctx.statistics["v5.vm.handler_indirection"] = out.__v5_vm_handler_indirection and 1 or 0
    ctx.statistics["v5.vm.handler_count"] = out.__v5_vm_handler_count or 0
    ctx.statistics["v5.vm.handler_route_count"] = out.__v6_vm_handler_route_count or 0
    ctx.statistics["v5.vm.register_count"] = out.__v7_vm_register_count or 0
    ctx.statistics["v5.vm.branch_route_count"] = out.__v8_vm_branch_route_count or 0
    ctx.statistics["v5.vm.context_key_count"] = out.__v9_vm_context_key_count or 0
    ctx.statistics["v5.vm.op_count"] = out.__v4_vm_op_count or 0
    ctx.statistics["v5.vm.branch_ops"] = out.__v4_vm_branch_ops or 0

    return result, ctx
end

return M
