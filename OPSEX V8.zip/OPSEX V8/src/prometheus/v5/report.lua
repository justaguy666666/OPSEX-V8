local Report = {}

function Report.create(ctx, inputSize, outputSize, compileTime)
    local statistics = {}
    local pipeline = {}
    if ctx and ctx.statistics then
        for name, value in pairs(ctx.statistics) do
            statistics[name] = value
        end
    end
    if ctx and ctx.history then
        for i, name in ipairs(ctx.history) do pipeline[i] = name end
    end

    return {
        inputSize = inputSize or 0,
        outputSize = outputSize or 0,
        compileTime = compileTime or 0,
        deterministic = true,
        pipeline = pipeline,
        statistics = statistics,
        diagnostics = ctx and ctx.diagnostics or {},
        seed = ctx and ctx.seed or 0,
        v5 = ctx and ctx.v5 == true or true,
        phase = ctx and ctx.phase or 10,
        vm = ctx and ctx.vm or {},
    }
end

return Report
