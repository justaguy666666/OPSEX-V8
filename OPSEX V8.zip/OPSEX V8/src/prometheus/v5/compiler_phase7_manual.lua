 
 
 
 
 

local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");
local util = require("prometheus.util");

local lookupify = util.lookupify;
local AstKind = Ast.AstKind;
local visitAst = require("prometheus.visitast");

local unpack = unpack or table.unpack;

local blockModule = require("prometheus.compiler.block");
local registerModule = require("prometheus.compiler.register");
local upvalueModule = require("prometheus.compiler.upvalue");
local emitModule = require("prometheus.compiler.emit");
local compileCoreModule = require("prometheus.compiler.compile_core");

local Compiler = {};

function Compiler:new()
    local compiler = {
        blocks = {};
        registers = {};
        activeBlock = nil;
        registersForVar = {};
        usedRegisters = 0;
        maxUsedRegister = 0;
        registerVars = {};

        VAR_REGISTER = newproxy(false);
        RETURN_ALL = newproxy(false);
        POS_REGISTER = newproxy(false);
        RETURN_REGISTER = newproxy(false);
        UPVALUE = newproxy(false);

        BIN_OPS = lookupify{
            AstKind.LessThanExpression,
            AstKind.GreaterThanExpression,
            AstKind.LessThanOrEqualsExpression,
            AstKind.GreaterThanOrEqualsExpression,
            AstKind.NotEqualsExpression,
            AstKind.EqualsExpression,
            AstKind.StrCatExpression,
            AstKind.AddExpression,
            AstKind.SubExpression,
            AstKind.MulExpression,
            AstKind.DivExpression,
            AstKind.ModExpression,
            AstKind.PowExpression,
        };
    };

    setmetatable(compiler, self);
    self.__index = self;

    return compiler;
end

blockModule(Compiler);
registerModule(Compiler);
upvalueModule(Compiler);
emitModule(Compiler);
compileCoreModule(Compiler);

function Compiler:pushRegisterUsageInfo()
    table.insert(self.registerUsageStack, {
        usedRegisters = self.usedRegisters;
        registers = self.registers;
    });
    self.usedRegisters = 0;
    self.registers = {};
end

function Compiler:popRegisterUsageInfo()
    local info = table.remove(self.registerUsageStack);
    self.usedRegisters = info.usedRegisters;
    self.registers = info.registers;
end

function Compiler:compile(ast)
     
    Scope.resetNameCounter()
    self.blocks = {};
    self.registers = {};
    self.activeBlock = nil;
    self.registersForVar = {};
    self.scopeFunctionDepths = {};
    self.maxUsedRegister = 0;
    self.usedRegisters = 0;
    self.registerVars = {};
    self.usedBlockIds = {};
    self.vmOpMap = {};
    self.vmMicroOpCount = 0;

     
     
     
     
    local registerBankSizes = {80, 88, 96, 104, 112, 120};
    self.maxRegs = registerBankSizes[math.random(1, #registerBankSizes)];

     
     
     
    local blockIdWidths = {20, 21, 22, 23, 24};
    self.blockIdModulus = 2^blockIdWidths[math.random(1, #blockIdWidths)];
    self.blockIdMul = math.random(0, self.blockIdModulus - 1) * 2 + 1;
    if self.blockIdMul >= self.blockIdModulus then
        self.blockIdMul = self.blockIdMul - 2;
    end
    self.blockIdAdd = math.random(0, self.blockIdModulus - 1);

    self.upvalVars = {};
    self.registerUsageStack = {};

    self.upvalsProxyLenReturn = math.random(-2^22, 2^22);

    local newGlobalScope = Scope:newGlobal();
    local psc = Scope:new(newGlobalScope, nil);

    local _, getfenvVar = newGlobalScope:resolve("getfenv");
    local _, tableVar = newGlobalScope:resolve("table");
    local _, unpackVar = newGlobalScope:resolve("unpack");
    local _, envVar = newGlobalScope:resolve("_ENV");
    local _, newproxyVar = newGlobalScope:resolve("newproxy");
    local _, setmetatableVar = newGlobalScope:resolve("setmetatable");
    local _, getmetatableVar = newGlobalScope:resolve("getmetatable");
    local _, selectVar = newGlobalScope:resolve("select");

    psc:addReferenceToHigherScope(newGlobalScope, getfenvVar, 2);
    psc:addReferenceToHigherScope(newGlobalScope, tableVar);
    psc:addReferenceToHigherScope(newGlobalScope, unpackVar);
    psc:addReferenceToHigherScope(newGlobalScope, envVar);
    psc:addReferenceToHigherScope(newGlobalScope, newproxyVar);
    psc:addReferenceToHigherScope(newGlobalScope, setmetatableVar);
    psc:addReferenceToHigherScope(newGlobalScope, getmetatableVar);

    self.scope = Scope:new(psc);
    self.envVar = self.scope:addVariable();
    self.containerFuncVar = self.scope:addVariable();
    self.unpackVar = self.scope:addVariable();
    self.newproxyVar = self.scope:addVariable();
    self.setmetatableVar = self.scope:addVariable();
    self.getmetatableVar = self.scope:addVariable();
    self.selectVar = self.scope:addVariable();

    local argVar = self.scope:addVariable();

    self.containerFuncScope = Scope:new(self.scope);
    self.whileScope = Scope:new(self.containerFuncScope);

    self.posVar = self.containerFuncScope:addVariable();
    self.argsVar = self.containerFuncScope:addVariable();
    self.currentUpvaluesVar = self.containerFuncScope:addVariable();
    self.detectGcCollectVar = self.containerFuncScope:addVariable();
    self.returnVar = self.containerFuncScope:addVariable();

    self.upvaluesTable = self.scope:addVariable();
    self.upvaluesReferenceCountsTable = self.scope:addVariable();
    self.allocUpvalFunction = self.scope:addVariable();
    self.currentUpvalId = self.scope:addVariable();

    self.upvaluesProxyFunctionVar = self.scope:addVariable();
    self.upvaluesGcFunctionVar = self.scope:addVariable();
    self.freeUpvalueFunc = self.scope:addVariable();

     
     
     
     
    self.vmOpsVar = self.scope:addVariable();
     
     
     
    self.vmHandlerMapVar = self.scope:addVariable();
    self.vmHandlerRouteMapVar = self.scope:addVariable();
    self.vmRegisterMapVar = self.scope:addVariable();
    self.vmHandlerTokenMap = {};
    self.vmHandlerTokenCount = 0;
    self.vmHandlerRouteCount = 0;
    self.vmRegisterSlotMap = {};
    self.vmRegisterBankWidth = 0;
     
     
     
    self.vmBranchOpsVar = self.scope:addVariable();
    self.vmBranchMicroOpCount = 0;
    self.createClosureVars = {};
    self.createVarargClosureVar = self.scope:addVariable();
    local createClosureScope = Scope:new(self.scope);
    local createClosurePosArg = createClosureScope:addVariable();
    local createClosureUpvalsArg = createClosureScope:addVariable();
    local createClosureProxyObject = createClosureScope:addVariable();
    local createClosureFuncVar = createClosureScope:addVariable();

    local createClosureSubScope = Scope:new(createClosureScope);

    local upvalEntries = {};
    local upvalueIds = {};
    self.getUpvalueId = function(self, scope, id)
        local expression;
        local scopeFuncDepth = self.scopeFunctionDepths[scope];
        if(scopeFuncDepth == 0) then
            if upvalueIds[id] then
                return upvalueIds[id];
            end
            expression = Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.allocUpvalFunction), {});
        else
            require("logger"):error("Unresolved Upvalue, this error should not occur!");
        end
        table.insert(upvalEntries, Ast.TableEntry(expression));
        local uid = #upvalEntries;
        upvalueIds[id] = uid;
        return uid;
    end

    createClosureSubScope:addReferenceToHigherScope(self.scope, self.containerFuncVar);
    createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosurePosArg)
    createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureUpvalsArg, 1)
    createClosureScope:addReferenceToHigherScope(self.scope, self.upvaluesProxyFunctionVar)
    createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureProxyObject);

    local vmOpKinds = {
        AstKind.LessThanExpression,
        AstKind.GreaterThanExpression,
        AstKind.LessThanOrEqualsExpression,
        AstKind.GreaterThanOrEqualsExpression,
        AstKind.NotEqualsExpression,
        AstKind.EqualsExpression,
        AstKind.StrCatExpression,
        AstKind.AddExpression,
        AstKind.SubExpression,
        AstKind.MulExpression,
        AstKind.DivExpression,
        AstKind.ModExpression,
        AstKind.PowExpression,
        AstKind.NotExpression,
        AstKind.NegateExpression,
        AstKind.LenExpression,
    };
    local vmOpIds = {};
    local shuffledVmKinds = util.shuffle({unpack(vmOpKinds)});
    for i, kind in ipairs(shuffledVmKinds) do
        vmOpIds[kind] = i;
        self.vmOpMap[kind] = i;
    end

     
     
     
     
     
    local vmOpEntries = {};
    local vmHandlerEntries = {};
    local vmHandlerRouteEntries = {};
    local vmRegisterEntries = {};
    local handlerTokens = {};
    for i = 1, #shuffledVmKinds do
        handlerTokens[i] = i;
    end
    handlerTokens = util.shuffle(handlerTokens);

    local registerBankWidths = {16, 20, 24, 28, 32};
    self.vmRegisterBankWidth = registerBankWidths[math.random(1, #registerBankWidths)];

    for i, kind in ipairs(shuffledVmKinds) do
        local handlerToken = handlerTokens[i];
        self.vmHandlerTokenMap[i] = handlerToken;

        local unary = kind == AstKind.NotExpression
            or kind == AstKind.NegateExpression
            or kind == AstKind.LenExpression;

        local slot1 = math.random(1, self.vmRegisterBankWidth);
        local slot2;
        if not unary then
            repeat
                slot2 = math.random(1, self.vmRegisterBankWidth);
            until slot2 ~= slot1;
        end
        self.vmRegisterSlotMap[i] = {slot1, slot2};

        vmHandlerRouteEntries[#vmHandlerRouteEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(i),
            Ast.NumberExpression(handlerToken)
        );

        local registerItems = {
            Ast.TableEntry(Ast.NumberExpression(slot1)),
        };
        if slot2 then
            registerItems[#registerItems + 1] = Ast.TableEntry(Ast.NumberExpression(slot2));
        end

        vmRegisterEntries[#vmRegisterEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(i),
            Ast.TableConstructorExpression(registerItems)
        );

        local opScope = Scope:new(self.scope);
        local rhsVar = opScope:addVariable();
        local rhs = Ast.VariableExpression(opScope, rhsVar);
        local args;
        local opExpression;

        if unary then
            args = {Ast.VariableExpression(opScope, rhsVar)};
            opExpression = Ast[kind](rhs);
        else
            local lhsVar = opScope:addVariable();
            local lhs = Ast.VariableExpression(opScope, lhsVar);
            args = {
                Ast.VariableExpression(opScope, lhsVar),
                Ast.VariableExpression(opScope, rhsVar)
            };
            opExpression = Ast[kind](lhs, rhs);
        end

        vmHandlerEntries[#vmHandlerEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(handlerToken),
            Ast.FunctionLiteralExpression(
                args,
                Ast.Block({Ast.ReturnStatement({opExpression})}, opScope)
            )
        );

        local wrapperScope = Scope:new(self.scope);
        local wrapperArgs = {};
        local wrapperStatements = {};
        local bankVar = wrapperScope:addVariable();

        wrapperStatements[#wrapperStatements + 1] = Ast.LocalVariableDeclaration(
            wrapperScope,
            {bankVar},
            {Ast.TableConstructorExpression({})}
        );

        local arg1 = wrapperScope:addVariable();
        wrapperArgs[1] = Ast.VariableExpression(wrapperScope, arg1);
        local arg1Expr = Ast.VariableExpression(wrapperScope, arg1);

        local registerLookupForWrite1 = Ast.IndexExpression(
            Ast.VariableExpression(self.scope, self.vmRegisterMapVar),
            Ast.NumberExpression(i)
        );
        local slot1ExprForWrite = Ast.IndexExpression(
            registerLookupForWrite1,
            Ast.NumberExpression(1)
        );

        wrapperStatements[#wrapperStatements + 1] = Ast.AssignmentStatement(
            {Ast.IndexExpression(
                Ast.VariableExpression(wrapperScope, bankVar),
                slot1ExprForWrite
            )},
            {arg1Expr}
        );

        local registerLookupForRead1 = Ast.IndexExpression(
            Ast.VariableExpression(self.scope, self.vmRegisterMapVar),
            Ast.NumberExpression(i)
        );
        local slot1ExprForRead = Ast.IndexExpression(
            registerLookupForRead1,
            Ast.NumberExpression(1)
        );

        local callArgs = {};
        callArgs[1] = Ast.IndexExpression(
            Ast.VariableExpression(wrapperScope, bankVar),
            slot1ExprForRead
        );

        if not unary then
            local arg2 = wrapperScope:addVariable();
            wrapperArgs[2] = Ast.VariableExpression(wrapperScope, arg2);
            local arg2Expr = Ast.VariableExpression(wrapperScope, arg2);

            local registerLookupForWrite2 = Ast.IndexExpression(
                Ast.VariableExpression(self.scope, self.vmRegisterMapVar),
                Ast.NumberExpression(i)
            );
            local slot2ExprForWrite = Ast.IndexExpression(
                registerLookupForWrite2,
                Ast.NumberExpression(2)
            );

            wrapperStatements[#wrapperStatements + 1] = Ast.AssignmentStatement(
                {Ast.IndexExpression(
                    Ast.VariableExpression(wrapperScope, bankVar),
                    slot2ExprForWrite
                )},
                {arg2Expr}
            );

            local registerLookupForRead2 = Ast.IndexExpression(
                Ast.VariableExpression(self.scope, self.vmRegisterMapVar),
                Ast.NumberExpression(i)
            );
            local slot2ExprForRead = Ast.IndexExpression(
                registerLookupForRead2,
                Ast.NumberExpression(2)
            );

            callArgs[2] = Ast.IndexExpression(
                Ast.VariableExpression(wrapperScope, bankVar),
                slot2ExprForRead
            );
        end

        local routeLookup = Ast.IndexExpression(
            Ast.VariableExpression(self.scope, self.vmHandlerRouteMapVar),
            Ast.NumberExpression(i)
        );
        local handlerLookup = Ast.IndexExpression(
            Ast.VariableExpression(self.scope, self.vmHandlerMapVar),
            routeLookup
        );
        local handlerCall = Ast.FunctionCallExpression(handlerLookup, callArgs);
        wrapperStatements[#wrapperStatements + 1] = Ast.ReturnStatement({handlerCall});

        vmOpEntries[#vmOpEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(i),
            Ast.FunctionLiteralExpression(
                wrapperArgs,
                Ast.Block(wrapperStatements, wrapperScope)
            )
        );
    end
    self.vmHandlerTokenCount = #handlerTokens;
    self.vmHandlerRouteCount = #vmHandlerRouteEntries;

     
     
     
    local branchKinds = {
        AstKind.LessThanExpression,
        AstKind.GreaterThanExpression,
    };
    local shuffledBranchKinds = util.shuffle({unpack(branchKinds)});
    self.vmBranchOpMap = {};
    local vmBranchEntries = {};
    for i, kind in ipairs(shuffledBranchKinds) do
        self.vmBranchOpMap[kind] = i;
        local branchScope = Scope:new(self.scope);
        local lhsVar = branchScope:addVariable();
        local rhsVar = branchScope:addVariable();

         
         
         
         
        local lhsArg = Ast.VariableExpression(branchScope, lhsVar);
        local rhsArg = Ast.VariableExpression(branchScope, rhsVar);
        local lhsExpr = Ast.VariableExpression(branchScope, lhsVar);
        local rhsExpr = Ast.VariableExpression(branchScope, rhsVar);
        local opExpression = Ast[kind](lhsExpr, rhsExpr);

        vmBranchEntries[#vmBranchEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(i),
            Ast.FunctionLiteralExpression(
                {lhsArg, rhsArg},
                Ast.Block({Ast.ReturnStatement({opExpression})}, branchScope)
            )
        );
    end

     
     
     
    local branchCount = 0;
    local branchKindsForCount = {
        [AstKind.LessThanExpression] = true,
        [AstKind.GreaterThanExpression] = true,
        [AstKind.LessThanOrEqualsExpression] = true,
        [AstKind.GreaterThanOrEqualsExpression] = true,
        [AstKind.NotEqualsExpression] = true,
        [AstKind.EqualsExpression] = true,
    };
    visitAst(ast, nil, function(node)
        if node and branchKindsForCount[node.kind] then
            branchCount = branchCount + 1;
        end
        return node;
    end, {});

    self:compileTopNode(ast);
    self.vmBranchMicroOpCount = branchCount;

    local functionNodeAssignments = {
        {
            var = Ast.AssignmentVariable(self.scope, self.vmHandlerRouteMapVar),
            val = Ast.TableConstructorExpression(vmHandlerRouteEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmRegisterMapVar),
            val = Ast.TableConstructorExpression(vmRegisterEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmHandlerMapVar),
            val = Ast.TableConstructorExpression(vmHandlerEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmOpsVar),
            val = Ast.TableConstructorExpression(vmOpEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmBranchOpsVar),
            val = Ast.TableConstructorExpression(vmBranchEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.containerFuncVar),
            val = Ast.FunctionLiteralExpression({
                Ast.VariableExpression(self.containerFuncScope, self.posVar),
                Ast.VariableExpression(self.containerFuncScope, self.argsVar),
                Ast.VariableExpression(self.containerFuncScope, self.currentUpvaluesVar),
                Ast.VariableExpression(self.containerFuncScope, self.detectGcCollectVar)
            }, self:emitContainerFuncBody());
        }, {
            var = Ast.AssignmentVariable(self.scope, self.createVarargClosureVar),
            val = Ast.FunctionLiteralExpression({
                    Ast.VariableExpression(createClosureScope, createClosurePosArg),
                    Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
                },
                Ast.Block({
                    Ast.LocalVariableDeclaration(createClosureScope, {
                        createClosureProxyObject
                    }, {
                        Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.upvaluesProxyFunctionVar), {
                            Ast.VariableExpression(createClosureScope, createClosureUpvalsArg)
                        })
                    }),
                    Ast.LocalVariableDeclaration(createClosureScope, {createClosureFuncVar},{
                        Ast.FunctionLiteralExpression({
                            Ast.VarargExpression();
                        },
                        Ast.Block({
                            Ast.ReturnStatement{
                                Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.containerFuncVar), {
                                    Ast.VariableExpression(createClosureScope, createClosurePosArg),
                                    Ast.TableConstructorExpression({Ast.TableEntry(Ast.VarargExpression())}),
                                    Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
                                    Ast.VariableExpression(createClosureScope, createClosureProxyObject)
                                })
                            }
                        }, createClosureSubScope)
                        );
                    });
                    Ast.ReturnStatement{Ast.VariableExpression(createClosureScope, createClosureFuncVar)};
                }, createClosureScope)
            );
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesTable),
            val = Ast.TableConstructorExpression({}),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesReferenceCountsTable),
            val = Ast.TableConstructorExpression({}),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.allocUpvalFunction),
            val = self:createAllocUpvalFunction(),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.currentUpvalId),
            val = Ast.NumberExpression(0),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesProxyFunctionVar),
            val = self:createUpvaluesProxyFunc(),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesGcFunctionVar),
            val = self:createUpvaluesGcFunc(),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.freeUpvalueFunc),
            val = self:createFreeUpvalueFunc(),
        },
    }

    local tbl = {
        Ast.VariableExpression(self.scope, self.containerFuncVar),
        Ast.VariableExpression(self.scope, self.createVarargClosureVar),
        Ast.VariableExpression(self.scope, self.upvaluesTable),
        Ast.VariableExpression(self.scope, self.upvaluesReferenceCountsTable),
        Ast.VariableExpression(self.scope, self.allocUpvalFunction),
        Ast.VariableExpression(self.scope, self.currentUpvalId),
        Ast.VariableExpression(self.scope, self.upvaluesProxyFunctionVar),
        Ast.VariableExpression(self.scope, self.upvaluesGcFunctionVar),
        Ast.VariableExpression(self.scope, self.freeUpvalueFunc),
    };
     
    local closureIds = {};
    for i in pairs(self.createClosureVars) do
        closureIds[#closureIds + 1] = i;
    end
    table.sort(closureIds);
    for _, i in ipairs(closureIds) do
        local entry = self.createClosureVars[i];
        table.insert(functionNodeAssignments, entry);
        table.insert(tbl, Ast.VariableExpression(entry.var.scope, entry.var.id));
    end

    util.shuffle(functionNodeAssignments);
    local assignmentStatLhs, assignmentStatRhs = {}, {};
    for i, v in ipairs(functionNodeAssignments) do
        assignmentStatLhs[i] = v.var;
        assignmentStatRhs[i] = v.val;
    end


     
    local ids = util.shuffle({1, 2, 3, 4, 5, 6, 7});

    local items = {
        Ast.VariableExpression(self.scope, self.envVar),
        Ast.VariableExpression(self.scope, self.unpackVar),
        Ast.VariableExpression(self.scope, self.newproxyVar),
        Ast.VariableExpression(self.scope, self.setmetatableVar),
        Ast.VariableExpression(self.scope, self.getmetatableVar),
        Ast.VariableExpression(self.scope, self.selectVar),
        Ast.VariableExpression(self.scope, argVar),
    }

    local astItems = {
        Ast.OrExpression(Ast.AndExpression(Ast.VariableExpression(newGlobalScope, getfenvVar), Ast.FunctionCallExpression(Ast.VariableExpression(newGlobalScope, getfenvVar), {})), Ast.VariableExpression(newGlobalScope, envVar));
        Ast.OrExpression(Ast.VariableExpression(newGlobalScope, unpackVar), Ast.IndexExpression(Ast.VariableExpression(newGlobalScope, tableVar), Ast.StringExpression("unpack")));
        Ast.VariableExpression(newGlobalScope, newproxyVar);
        Ast.VariableExpression(newGlobalScope, setmetatableVar);
        Ast.VariableExpression(newGlobalScope, getmetatableVar);
        Ast.VariableExpression(newGlobalScope, selectVar);
        Ast.TableConstructorExpression({
            Ast.TableEntry(Ast.VarargExpression());
        })
    }

    local functionNode = Ast.FunctionLiteralExpression({
      items[ids[1]], items[ids[2]], items[ids[3]], items[ids[4]],
      items[ids[5]], items[ids[6]], items[ids[7]],
      unpack(util.shuffle(tbl))
    }, Ast.Block({
        Ast.AssignmentStatement(assignmentStatLhs, assignmentStatRhs);
        Ast.ReturnStatement{
            Ast.FunctionCallExpression(Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.createVarargClosureVar), {
                    Ast.NumberExpression(self.startBlockId);
                    Ast.TableConstructorExpression(upvalEntries);
                }), {Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.unpackVar), {Ast.VariableExpression(self.scope, argVar)})});
        }
    }, self.scope));

    local result = Ast.TopNode(Ast.Block({
        Ast.ReturnStatement{Ast.FunctionCallExpression(functionNode, {
            astItems[ids[1]], astItems[ids[2]], astItems[ids[3]], astItems[ids[4]],
            astItems[ids[5]], astItems[ids[6]], astItems[ids[7]],
        })};
    }, psc), newGlobalScope);
    result.__v4_vm_micro_ops = self.vmMicroOpCount or 0;
    result.__v5_vm_handler_indirection = true;
    result.__v5_vm_handler_count = self.vmHandlerTokenCount or 0;
    result.__v6_vm_handler_route_indirection = true;
    result.__v6_vm_handler_route_count = self.vmHandlerRouteCount or 0;
    result.__v7_vm_register_indirection = true;
    result.__v7_vm_register_count = #shuffledVmKinds;
    result.__v7_vm_register_bank_width = self.vmRegisterBankWidth or 0;
    result.__v4_vm_op_count = #shuffledVmKinds;
    result.__v4_vm_branch_ops = self.vmBranchMicroOpCount or 0;
    result.__v4_vm_branch_layout = self.vmBranchOpMap;
    result.__v4_vm_branch_opcode_count = #shuffledBranchKinds;
    return result;
end

function Compiler:getCreateClosureVar(argCount)
    if not self.createClosureVars[argCount] then
        local var = Ast.AssignmentVariable(self.scope, self.scope:addVariable());
        local createClosureScope = Scope:new(self.scope);
        local createClosureSubScope = Scope:new(createClosureScope);

        local createClosurePosArg = createClosureScope:addVariable();
        local createClosureUpvalsArg = createClosureScope:addVariable();
        local createClosureProxyObject = createClosureScope:addVariable();
        local createClosureFuncVar = createClosureScope:addVariable();

        createClosureSubScope:addReferenceToHigherScope(self.scope, self.containerFuncVar);
        createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosurePosArg)
        createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureUpvalsArg, 1)
        createClosureScope:addReferenceToHigherScope(self.scope, self.upvaluesProxyFunctionVar)
        createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureProxyObject);

        local  argsTb, argsTb2 = {}, {};
        for i = 1, argCount do
            local arg = createClosureSubScope:addVariable()
            argsTb[i] = Ast.VariableExpression(createClosureSubScope, arg);
            argsTb2[i] = Ast.TableEntry(Ast.VariableExpression(createClosureSubScope, arg));
        end

        local val = Ast.FunctionLiteralExpression({
            Ast.VariableExpression(createClosureScope, createClosurePosArg),
            Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
        }, Ast.Block({
                Ast.LocalVariableDeclaration(createClosureScope, {
                    createClosureProxyObject
                }, {
                    Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.upvaluesProxyFunctionVar), {
                        Ast.VariableExpression(createClosureScope, createClosureUpvalsArg)
                    })
                }),
                Ast.LocalVariableDeclaration(createClosureScope, {createClosureFuncVar},{
                    Ast.FunctionLiteralExpression(argsTb,
                    Ast.Block({
                        Ast.ReturnStatement{
                            Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.containerFuncVar), {
                                Ast.VariableExpression(createClosureScope, createClosurePosArg),
                                Ast.TableConstructorExpression(argsTb2),
                                Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
                                Ast.VariableExpression(createClosureScope, createClosureProxyObject)
                            })
                        }
                    }, createClosureSubScope)
                    );
                });
                Ast.ReturnStatement{Ast.VariableExpression(createClosureScope, createClosureFuncVar)}
            }, createClosureScope)
        );
        self.createClosureVars[argCount] = {
            var = var,
            val = val,
        }
    end


    local var = self.createClosureVars[argCount].var;
    return var.scope, var.id;
end

return Compiler;
