local M = {}
function M.create(ctx, inputSize, outputSize, compileTime)
    ctx = ctx or {}
    return {
        mode = "v6-beta", seed = ctx.seed or 0, v6 = true,
        pipeline = ctx.history or {}, statistics = ctx.statistics or {},
        inputSize = inputSize or 0, outputSize = outputSize or 0,
        compileTime = compileTime or 0, deterministic = true,
        vm = ctx.vm or {},
    }
end
return M
