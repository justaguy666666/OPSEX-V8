local C = {}

local DEFAULT = {
    mode = "v6-beta",
    seed = 0,
    LuaVersion = nil,
    PrettyPrint = false,
    v5 = true,
    v6 = true,
    planner = {
        maxRegionSize = 10,
        enableIdentifierTransform = true,
        enableDataflowTransform = true,
        enableConditionTransform = true,
        enableCfgRestructure = true,
        enableStringDiversification = true,
        enableSelectiveVirtualization = false,
        virtualizationRate = 0,
        cfgRestructureRate = 0.72,
        stringStrategyRate = 1.0,
        dataflowRate = 0.58,
        enableMetrics = true,
    }
}

local function copy(v)
    if type(v) ~= "table" then return v end
    local r = {}
    for k, x in pairs(v) do r[k] = copy(x) end
    return r
end

function C.create(options)
    options = options or {}
    local r = copy(DEFAULT)
    for k, v in pairs(options) do
        if type(v) == "table" and type(r[k]) == "table" then
            for a, b in pairs(v) do r[k][a] = copy(b) end
        else
            r[k] = copy(v)
        end
    end
    r.mode = "v6-beta"
    r.v5 = true
    r.v6 = true
    return r
end

return C
