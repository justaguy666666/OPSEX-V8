local Parser = require("prometheus.parser")
local Unparser = require("prometheus.unparser")
local E = require("prometheus.enums")
local Config = require("prometheus.v6.config")
local Pipeline = require("prometheus.v4.pipeline")
local Report = require("prometheus.v6.report")
local Compiler = require("prometheus.v6.compiler_phase10")

local M = {}
M.Report = Report

function M.apply(source, luaVersion, pretty, seed, preset)
    local luaVer = luaVersion or E.LuaVersion.LuaU
    local buildSeed = tonumber(seed) or 0
    preset = preset or "v6-beta"
    if preset ~= "v6-beta" then error("V6 has one preset: v6-beta", 0) end

    math.randomseed(buildSeed)
    local config = Config.create({
        seed = buildSeed, LuaVersion = luaVer, PrettyPrint = pretty or false,
        planner = {},
    })
    local ast = Parser:new({LuaVersion = luaVer}):parse(source)
    local transformed, v4ctx = Pipeline.run(ast, config)

    math.randomseed(buildSeed)
    local compiler = Compiler:new({v6 = true})
    local out = compiler:compile(transformed)
    local result = Unparser:new({LuaVersion = luaVer, PrettyPrint = pretty or false}):unparse(out)

    local ctx = {
        v6 = true, phase = 1, seed = buildSeed, history = v4ctx.history or {},
        statistics = v4ctx.statistics or {}, diagnostics = v4ctx.diagnostics or {},
        vm = {
            dispatch_strategy = out.__v6_vm_dispatch_strategy,
            rolling_state = out.__v6_vm_rolling_state,
            block_count = out.__v6_vm_block_count,
            op_count = out.__v4_vm_op_count,
            branch_ops = out.__v4_vm_branch_ops,
            handler_count = out.__v5_vm_handler_count,
            route_count = out.__v6_vm_handler_route_count,
            register_count = out.__v7_vm_register_count,
            context_key_count = out.__v9_vm_context_key_count,
        }
    }
    ctx.history[#ctx.history + 1] = "v6-heterogeneous-vm"
    ctx.statistics["v6.vm.dispatch_strategy"] = out.__v6_vm_dispatch_strategy or 0
    ctx.statistics["v6.vm.rolling_state"] = out.__v6_vm_rolling_state and 1 or 0
    ctx.statistics["v6.vm.block_count"] = out.__v6_vm_block_count or 0
    return result, ctx
end

return M
