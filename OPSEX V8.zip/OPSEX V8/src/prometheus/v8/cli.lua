local Parser = require("prometheus.parser")
local Unparser = require("prometheus.unparser")
local E = require("prometheus.enums")
local Config = require("prometheus.v8.config")
local Pipeline = require("prometheus.v4.pipeline")
local Report = require("prometheus.v8.report")
local Compiler = require("prometheus.v8.compiler")
local V4Config = require("prometheus.v4.config")
local MoonVeilCompat = require("prometheus.v8.moonveil_compat")
local EncryptStrings = require("prometheus.steps.EncryptStrings")
local AntiTamper = require("prometheus.steps.AntiTamper")
local Ast = require("prometheus.ast")

local function loadRuntimeGuard(seed)
    local path = "src/prometheus/v8/runtime_guard.lua"
    local f, err = io.open(path, "rb")
    if not f then
        error("V8 runtime guard missing: " .. tostring(err), 0)
    end
    local guard = f:read("*a")
    f:close()
    local seedNumber = math.floor(tonumber(seed) or 0)
    guard = guard:gsub("__OPSEX_V8_SEED__", tostring(seedNumber), 1)
    return guard
end

 
 
 
 
local function integrityGateNameForSeed(seed)
     
     
    local modulus = 2147483647
    local state = math.floor(math.abs(tonumber(seed) or 0)) % modulus
    state = (state + 104729) % modulus
    local alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    local out = {}
    for i = 1, 18 do
        state = (state * 48271 + 12820163 + i * 7919) % modulus
        local index = (state % #alphabet) + 1
        out[i] = alphabet:sub(index, index)
    end
    local first = out[1]
    if first:match("%d") then out[1] = "q" end
    return table.concat(out)
end

local function opaqueBootstrapLocals(seed)
     
     
     
    local modulus = 2147483647
    local state = math.floor(math.abs(tonumber(seed) or 0)) % modulus
    local alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local function nextName(salt)
        state = (state + salt * 104729 + 8191) % modulus
        local chars = {}
        for i = 1, 13 do
            state = (state * 48271 + 12820163 + i * salt) % modulus
            chars[i] = alphabet:sub((state % #alphabet) + 1, (state % #alphabet) + 1)
        end
        return table.concat(chars)
    end
    local a, b, c = nextName(3), nextName(7), nextName(11)
    while b == a do b = nextName(17) end
    while c == a or c == b do c = nextName(23) end
    return a, b, c
end

local function buildAntiTamperVmBootstrap(seed, luaVersion, gateName)
    local buildSeed = math.floor(tonumber(seed) or 0)
    math.randomseed(buildSeed + 194711)
    local seedAst = Parser:new({LuaVersion=luaVersion}):parse("do end")
    seedAst = AntiTamper:new({UseDebug=false}):apply(seedAst, {PrettyPrint=false}) or seedAst
    local gateStatement = seedAst.body and seedAst.body.statements and seedAst.body.statements[1]
    if not gateStatement or gateStatement.kind ~= Ast.AstKind.DoStatement or not gateStatement.body then
        error("V8 AntiTamper gate could not be extracted for VM compilation", 0)
    end
    local gateFunction = Ast.FunctionLiteralExpression({}, gateStatement.body)
    local wrapper = Ast.TopNode(Ast.Block({Ast.ReturnStatement({gateFunction})}, seedAst.globalScope), seedAst.globalScope)
    math.randomseed(buildSeed + 194711)
    local compiled = Compiler:new({v6=true, v7=true, v8=true, seed=buildSeed + 194711}):compile(wrapper)
    local first = compiled.body and compiled.body.statements and compiled.body.statements[1]
    local expression = first and first.args and first.args[1]
    if not expression then error("V8 AntiTamper VM compilation produced no callable", 0) end
    local expressionWrapper = Ast.TopNode(Ast.Block({Ast.ReturnStatement({expression})}, compiled.globalScope), compiled.globalScope)
    local source = Unparser:new({LuaVersion=luaVersion, PrettyPrint=false}):unparse(expressionWrapper)
    source = source:gsub("^return%s*", "", 1)
    if source == "" or source:match("^return") then error("V8 AntiTamper VM expression serialization failed", 0) end
    math.randomseed(buildSeed)
     
     
     
    local stateName, callableName = opaqueBootstrapLocals(buildSeed)
    return gateName .. " = (function() local " .. stateName .. " = false; local " .. callableName .. " = (function(...) return " .. source .. " end)(); return function() if not " .. stateName .. " then " .. stateName .. " = true; " .. callableName .. "() end end end)(); " .. gateName .. "()"
end

local M = {}
M.Report = Report

 
 
 
 
local function v8StringDecoderVariant(seed)
    local modulus = 90000000
    local normalized = math.floor(math.abs(tonumber(seed) or 0)) % modulus
    local mixed = (normalized * 69621 + 12345) % modulus
    mixed = (mixed * mixed + normalized * 104729 + 48271) % modulus
    return (mixed % 3) + 1
end

 
 
 
 
local function vmOutputLooksUnsafe(node)
    local K = require("prometheus.ast").AstKind
    local seen = {}
    local function walk(x)
        if type(x) ~= "table" or seen[x] then return false end
        seen[x] = true
        if x.kind == K.IndexExpression and x.index and x.index.kind == K.NilExpression then
            return true
        end
        if x.kind == K.FunctionLiteralExpression then
            for _,arg in ipairs(x.args or {}) do
                if arg.kind ~= K.VarargExpression and (not arg.scope or arg.id == nil) then
                    return true
                end
            end
        elseif x.kind == K.VariableExpression and (not x.scope or x.id == nil) then
            return true
        end
        for k,v in pairs(x) do
            if k ~= "scope" and k ~= "parentScope" and type(v) == "table" then
                if v.kind then
                    if walk(v) then return true end
                else
                    for _,item in pairs(v) do
                        if walk(item) then return true end
                    end
                end
            end
        end
        return false
    end
    return walk(node)
end

function M.apply(source, luaVersion, pretty, seed, preset, mode)
    local luaVer = luaVersion or E.LuaVersion.LuaU
    local buildSeed = tonumber(seed) or 0
    preset = preset or "v8"
    mode = mode or "cff"
    if preset ~= "v8" then error("V8 has one preset: v8", 0) end
    if mode ~= "cff" and mode ~= "vm" and mode ~= "hybrid" and mode ~= "fullVm" and mode ~= "safeEnv" then
        error("V8 mode must be cff, vm, hybrid, fullVm, or safeEnv", 0)
    end
    local selectiveVmMode = mode == "vm" or mode == "hybrid"
    local macroMode = selectiveVmMode and "vm" or mode

    if mode == "cff" or selectiveVmMode then
        math.randomseed(buildSeed)
        local preparedSource = MoonVeilCompat.prepareSource(source)
        local ast = Parser:new({LuaVersion=luaVer}):parse(preparedSource)
        ast = MoonVeilCompat.prepareAst(ast, macroMode)
        local autoVmMarked, autoVmSkipped = 0, 0
        local autoVmLowered, autoVmFailed = 0, 0
        local integrityGateName = nil
        if selectiveVmMode then
            integrityGateName = integrityGateNameForSeed(buildSeed)
            MoonVeilCompat.setIntegrityGateName(integrityGateName)
             
             
            ast, autoVmMarked, autoVmSkipped = MoonVeilCompat.selectAutoVmCandidates(ast, mode == "hybrid" and 128 or 64)
        end

         
         
         
         
         
         
        if selectiveVmMode then
            ast, autoVmLowered, autoVmFailed = MoonVeilCompat.lowerAutoVmCandidates(ast, buildSeed, luaVer)
        end
        math.randomseed(buildSeed)
        local sourceConfig = V4Config.create({
            mode="v8-cff", seed=buildSeed, LuaVersion=luaVer,
            PrettyPrint=pretty or false, v7=true,
            planner={
                enableSelectiveVirtualization=false,
                enableStringProtection=(not selectiveVmMode),
                 
                 
                 
                enableNestedCfgRestructure=(selectiveVmMode),
                enableMetrics=true,
            }
        })
        local transformed, ctx = Pipeline.run(ast, sourceConfig)
        transformed, ctx.vmMacroCount = MoonVeilCompat.lowerVmMacros(transformed, buildSeed, luaVer)
        if selectiveVmMode then MoonVeilCompat.setIntegrityGateName(nil) end
        local loweredMethodCalls = 0
        if selectiveVmMode then
            transformed, loweredMethodCalls = MoonVeilCompat.lowerMethodCallNames(transformed)
        end

         
         
         
         
         
        if selectiveVmMode then
            math.randomseed(buildSeed + 73129)
            local finalStringEncryptor = EncryptStrings:new({Variant=v8StringDecoderVariant(buildSeed)})
            transformed = finalStringEncryptor:apply(transformed) or transformed
            math.randomseed(buildSeed)
        end
        ctx.statistics["v8.auto_vm.marked"] = autoVmMarked
        ctx.statistics["v8.auto_vm.skipped"] = autoVmSkipped
        ctx.statistics["v8.auto_vm.lowered"] = autoVmLowered
        ctx.statistics["v8.auto_vm.failed"] = autoVmFailed
        ctx.statistics["v8.auto_vm.no_functions"] = (mode == "vm" and autoVmLowered == 0 and (ctx.vmMacroCount or 0) == 0) and 1 or 0
        ctx.statistics["v8.method_calls.lowered"] = loweredMethodCalls
        local result = Unparser:new({LuaVersion=luaVer, PrettyPrint=pretty or false}):unparse(transformed)
        if selectiveVmMode then
            local antiTamperVmBootstrap = buildAntiTamperVmBootstrap(buildSeed, luaVer, integrityGateName)
            result = antiTamperVmBootstrap .. "\n" .. result
        end
        ctx.mode = mode == "hybrid" and "v8-hybrid-semantic-vm" or (mode == "vm" and "v8-vm-selective" or "v8-cff")
        ctx.seed = buildSeed
        ctx.history[#ctx.history+1] = selectiveVmMode and (mode == "hybrid" and "opsex-hybrid-semantic-vm" or "opsex-moonveil-style-selective-vm") or "opsex-moonveil-style-cff"
        ctx.statistics["v8.macro.vm_functions"] = (ctx.vmMacroCount or 0) + autoVmLowered
        ctx.statistics["v8.runtime_guard"] = 0
        ctx.statistics["v8.anti_tamper"] = selectiveVmMode and 1 or 0
        if selectiveVmMode then ctx.history[#ctx.history+1] = "v8-anti-tamper-vm-gate" end
        ctx.vm = {full_program_virtualization=false, hybrid_semantic_vm=(mode == "hybrid"), selective_vm_functions=(ctx.vmMacroCount or 0) + autoVmLowered, auto_vm_marked=autoVmMarked, auto_vm_lowered=autoVmLowered, auto_vm_failed=autoVmFailed, auto_vm_skipped=autoVmSkipped, strings_protected=true, anti_tamper=selectiveVmMode}
        return result, ctx
    end

     
     
     
     
     
    if mode == "fullVm" then
        math.randomseed(buildSeed)
        local preparedSource = MoonVeilCompat.prepareSource(source)
        local ast = Parser:new({LuaVersion=luaVer}):parse(preparedSource)
        ast = MoonVeilCompat.prepareAst(ast, mode)
        local macroVmCount = 0
        ast, macroVmCount = MoonVeilCompat.lowerVmMacros(ast, buildSeed, luaVer)

         
         
         
         
         
         
        local function clearSkipFlags(node, seen)
            if type(node) ~= "table" or seen[node] then return end
            seen[node] = true
            node.__opsex_skip_obfuscation = nil
            if node.scope then node.scope.__opsex_skip_obfuscation = nil end
            for key, value in pairs(node) do
                if key ~= "scope" and key ~= "parentScope" and key ~= "globalScope"
                    and key ~= "parent" and key ~= "isAst" and type(value) == "table" then
                    if value.kind then clearSkipFlags(value, seen)
                    else for _, child in pairs(value) do clearSkipFlags(child, seen) end end
                end
            end
        end
        clearSkipFlags(ast, {})

         
         
         
        math.randomseed(buildSeed + 73129)
        local stringEncryptor = EncryptStrings:new({Variant=v8StringDecoderVariant(buildSeed)})
        ast = stringEncryptor:apply(ast) or ast

        math.randomseed(buildSeed)
        local ok, out = pcall(function()
            return Compiler:new({v6=true, v7=true, v8=true, seed=buildSeed}):compile(ast)
        end)
        if not ok or type(out) ~= "table" or vmOutputLooksUnsafe(out) then
            error("V8 VM compilation failed; no selective/source fallback was emitted" .. (not ok and (": " .. tostring(out)) or ""), 0)
        end
         
         
         
         
        clearSkipFlags(out, {})
        math.randomseed(buildSeed + 73129)
        local compiledStringEncryptor = EncryptStrings:new({Variant=v8StringDecoderVariant(buildSeed)})
        out = compiledStringEncryptor:apply(out) or out
        math.randomseed(buildSeed)

        local result = Unparser:new({LuaVersion=luaVer, PrettyPrint=pretty or false}):unparse(out)
        if result:find("][nil]", 1, true) or result:find("[nil](", 1, true) then
            error("V8 emitted an unsafe nil dispatch; build rejected", 0)
        end
        local ctx = {
            mode="v8-full-vm", v8=true, phase=4, seed=buildSeed, history={},
            statistics={}, diagnostics={},
            vm={full_program_virtualization=true, selective_vm_functions=macroVmCount,
                macro_vm_functions=macroVmCount, fallback=false, large_script_source_mode=false,
                dispatch_strategy=out.__v6_vm_dispatch_strategy,
                representation_family=out.__v7_vm_representation_family,
                block_count=out.__v6_vm_block_count, op_count=out.__v4_vm_op_count,
                handler_count=out.__v5_vm_handler_count, route_count=out.__v6_vm_handler_route_count,
                register_count=out.__v7_vm_register_count,
                state_families=out.__v8_vm_state_families or 0,
                execution_family=out.__v8_vm_execution_family or 1,
                dispatch_topology=out.__v11_vm_dispatch_topology or 1,
                operation_fusion=out.__v12_vm_operation_fusion or false,
                fusion_count=out.__v12_vm_fusion_count or 0,
                constant_decoder=out.__v13_vm_constant_decoder or false,
                constant_decoder_family=out.__v13_vm_constant_decoder_family or 1}
        }
        ctx.history[#ctx.history+1] = "v8-whole-program-vm"
        ctx.history[#ctx.history+1] = "v8-phase4a-execution-entanglement"
        ctx.history[#ctx.history+1] = "v8-phase4b-variable-dispatch-topology"
        ctx.history[#ctx.history+1] = "v8-phase4c-operation-fusion"
        ctx.history[#ctx.history+1] = "v8-phase4d-constant-decoder-polymorphism"
        ctx.statistics["v8.vm.fallback"] = 0
        ctx.statistics["v8.vm.full_program_virtualization"] = 1
        ctx.statistics["v8.vm.macro_functions"] = macroVmCount
        return result, ctx
    end

    math.randomseed(buildSeed)
    local config = Config.create({
        seed=buildSeed,
        LuaVersion=luaVer,
        PrettyPrint=pretty or false,
        planner={}
    })
     
     
     
     
    local guardSource = nil
    if mode == "safeEnv" then
        guardSource = "do\n" .. loadRuntimeGuard(buildSeed) .. "\nend"
    end
     
     
     
     
    local guardedSource = source
    local ast = Parser:new({LuaVersion=luaVer}):parse(guardedSource)
     
     
     
     
     
    math.randomseed(buildSeed + 73129)
    local stringEncryptor = EncryptStrings:new({Variant=v8StringDecoderVariant(buildSeed)})
    ast = stringEncryptor:apply(ast) or ast
     
     
     
     
    local transformed = ast
    local v4ctx = {history={}, statistics={}, diagnostics={}}

    math.randomseed(buildSeed)
     
     
    local out
    local compiler = Compiler:new({v6=true, v7=true, v8=true, seed=buildSeed})
    local ok, compiled = pcall(function() return compiler:compile(transformed) end)
    if ok and type(compiled) == "table" and not vmOutputLooksUnsafe(compiled) then
        out = compiled
    else
        local retryOk, retryResult = pcall(function()
             
             
             
            local cleanAst = Parser:new({LuaVersion=luaVer}):parse(guardedSource)
            math.randomseed(buildSeed + 73129)
            local retryEncryptor = EncryptStrings:new({Variant=v8StringDecoderVariant(buildSeed)})
            cleanAst = retryEncryptor:apply(cleanAst) or cleanAst
            math.randomseed(buildSeed)
            return Compiler:new({v6=true, v7=true, v8=true, seed=buildSeed}):compile(cleanAst)
        end)
        if retryOk and type(retryResult) == "table" and not vmOutputLooksUnsafe(retryResult) then
            out = retryResult
        else
            error("V8 VM compilation failed; no V7/source fallback was emitted", 0)
        end
    end

    local result = Unparser:new({LuaVersion=luaVer, PrettyPrint=pretty or false}):unparse(out)
    local guardContext = nil
    if guardSource then
        local guardAst = Parser:new({LuaVersion=luaVer}):parse(guardSource)
        local guardConfig = V4Config.create({
            mode="v8-safeEnv-guard", seed=buildSeed, LuaVersion=luaVer,
            PrettyPrint=pretty or false, v7=true,
            planner={enableSelectiveVirtualization=false, enableStringProtection=false, enableMetrics=true}
        })
        local transformedGuard
        transformedGuard, guardContext = Pipeline.run(guardAst, guardConfig)
        local guardText = Unparser:new({LuaVersion=luaVer, PrettyPrint=pretty or false}):unparse(transformedGuard)
        result = guardText .. "\n" .. result
    end

     
     
    if result:find("][nil]", 1, true) or result:find("[nil](", 1, true) then
        error("V8 emitted an unsafe nil dispatch; build rejected", 0)
    end
    local ctx = {
        mode=mode == "safeEnv" and "v8-safeEnv" or "v8-full-vm",
        v8=true, phase=4, seed=buildSeed, history=v4ctx.history or {},
        statistics=v4ctx.statistics or {}, diagnostics=v4ctx.diagnostics or {},
        vm={
            dispatch_strategy=out.__v6_vm_dispatch_strategy,
            representation_family=out.__v7_vm_representation_family,
            rolling_state=out.__v6_vm_rolling_state,
            block_count=out.__v6_vm_block_count,
            op_count=out.__v4_vm_op_count,
            branch_ops=out.__v4_vm_branch_ops,
            handler_count=out.__v5_vm_handler_count,
            route_count=out.__v6_vm_handler_route_count,
            register_count=out.__v7_vm_register_count,
            register_bank_width=out.__v7_vm_register_bank_width,
            decoy_count=out.__v7_vm_decoy_count,
            fallback=false,
            large_script_source_mode=false,
            state_families=out.__v8_vm_state_families or 0,
            execution_family=out.__v8_vm_execution_family or 1,
            execution_entanglement=out.__v10_vm_execution_entanglement or false,
            entangle_width=out.__v10_vm_entangle_width or 0,
            dispatch_topology=out.__v11_vm_dispatch_topology or 1,
            operation_fusion=out.__v12_vm_operation_fusion or false,
            fusion_count=out.__v12_vm_fusion_count or 0,
            fusion_use_count=out.__v12_vm_fusion_use_count or 0,
            constant_decoder=out.__v13_vm_constant_decoder or false,
            constant_decoder_family=out.__v13_vm_constant_decoder_family or 1,
            uniqueness_score=out.__v14_vm_uniqueness_score or 0,
            uniqueness_fingerprint=out.__v14_vm_uniqueness_fingerprint or 0,
            uniqueness_similarity=out.__v14_vm_uniqueness_similarity or 0,
        }
    }
    ctx.history[#ctx.history+1] = "v8-multifamily-vm"
    if mode == "safeEnv" then
        ctx.history[#ctx.history+1] = "v8-runtime-integrity-guard-source-gate"
        if guardContext and guardContext.history then
            for _, pass in ipairs(guardContext.history) do ctx.history[#ctx.history+1] = "guard:" .. pass end
        end
    end
    ctx.history[#ctx.history+1] = "v8-phase4a-execution-entanglement"
    ctx.history[#ctx.history+1] = "v8-phase4b-variable-dispatch-topology"
    ctx.history[#ctx.history+1] = "v8-phase4c-operation-fusion"
    ctx.history[#ctx.history+1] = "v8-phase4d-constant-decoder-polymorphism"
    ctx.history[#ctx.history+1] = "v8-phase4e-build-uniqueness-scoring"
    ctx.statistics["v8.vm.large_script_source_mode"] = 0
    ctx.statistics["v8.vm.dispatch_strategy"] = out.__v6_vm_dispatch_strategy or 0
    ctx.statistics["v8.vm.representation_family"] = out.__v7_vm_representation_family or 0
    ctx.statistics["v8.vm.decoys"] = out.__v7_vm_decoy_count or 0
    ctx.statistics["v8.vm.fallback"] = 0
    ctx.statistics["v8.vm.state_families"] = out.__v8_vm_state_families or 0
    ctx.statistics["v8.vm.execution_family"] = out.__v8_vm_execution_family or 1
    ctx.statistics["v8.vm.execution_entanglement"] = out.__v10_vm_execution_entanglement and 1 or 0
    ctx.statistics["v8.vm.entangle_width"] = out.__v10_vm_entangle_width or 0
    ctx.statistics["v8.vm.dispatch_topology"] = out.__v11_vm_dispatch_topology or 1
    ctx.statistics["v8.vm.operation_fusion"] = out.__v12_vm_operation_fusion and 1 or 0
    ctx.statistics["v8.vm.fusion_count"] = out.__v12_vm_fusion_count or 0
    ctx.statistics["v8.vm.fusion_use_count"] = out.__v12_vm_fusion_use_count or 0
    ctx.statistics["v8.vm.constant_decoder"] = out.__v13_vm_constant_decoder and 1 or 0
    ctx.statistics["v8.vm.constant_decoder_family"] = out.__v13_vm_constant_decoder_family or 1
    ctx.statistics["v8.vm.uniqueness_score"] = out.__v14_vm_uniqueness_score or 0
    ctx.statistics["v8.vm.uniqueness_fingerprint"] = out.__v14_vm_uniqueness_fingerprint or 0
    ctx.statistics["v8.vm.uniqueness_similarity"] = out.__v14_vm_uniqueness_similarity or 0
    ctx.statistics["v8.vm.opcode_layout"] = out.__v8_vm_opcode_layout or 1
    ctx.statistics["v8.runtime_guard"] = mode == "safeEnv" and 1 or 0
    ctx.statistics["v8.runtime_guard.vm_lowered"] = 0
    ctx.statistics["v8.runtime_guard.source_obfuscated"] = mode == "safeEnv" and 1 or 0
    return result, ctx
end

return M
