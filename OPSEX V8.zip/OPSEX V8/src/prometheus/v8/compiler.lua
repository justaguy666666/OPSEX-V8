 
 
 
 
 

local Ast = require("prometheus.ast");
local Scope = require("prometheus.scope");
local util = require("prometheus.util");

local lookupify = util.lookupify;
local AstKind = Ast.AstKind;
local visitAst = require("prometheus.visitast");

local unpack = unpack or table.unpack;

local blockModule = require("prometheus.compiler.block");
local registerModule = require("prometheus.compiler.register");
local upvalueModule = require("prometheus.compiler.upvalue");
local emitModule = require("prometheus.compiler.emit");
local compileCoreModule = require("prometheus.compiler.compile_core");

local Compiler = {};

 
 
 
local recentV8Fingerprints = {};
local MAX_RECENT_V8_FINGERPRINTS = 32;

local function v8UniquenessFingerprint(metrics)
    local h = 2166136261;
    local function mix(v)
        v = math.floor(math.abs(tonumber(v) or 0));
        h = (h * 16777619 + v + 97) % 4294967296;
    end
    for i = 1, #metrics do mix(metrics[i]); end
    return h;
end

local function v8RelativeSimilarity(a, b)
    local sum = 0;
    local n = math.min(#a, #b);
    if n == 0 then return 1; end
    for i = 1, n do
        local x = math.abs(tonumber(a[i]) or 0);
        local y = math.abs(tonumber(b[i]) or 0);
        local denom = math.max(1, x, y);
        sum = sum + (1 - math.min(1, math.abs(x - y) / denom));
    end
    return sum / n;
end

 
 
 
 
local function v8SeededValue(seed, salt, modulus)
     
     
     
    local mixMod = 90000000;
    local normalized = math.floor(math.abs(tonumber(seed) or 0)) % mixMod;
    local s = math.floor(math.abs(tonumber(salt) or 0)) % mixMod;
    local mixed = (normalized + s * 69621 + 12345) % mixMod;
    mixed = (mixed * mixed + s * 48271 + 40699) % mixMod;
    mixed = (mixed * mixed + normalized * 104729 + s + 97) % mixMod;
    return mixed % modulus;
end

local function v8SeededOdd(seed, salt, modulus)
     
     
    return v8SeededValue(seed, salt, modulus / 2) * 2 + 1;
end

function Compiler:new(options)
    options = options or {}
    local compiler = {
        blocks = {};
        registers = {};
        activeBlock = nil;
        registersForVar = {};
        usedRegisters = 0;
        maxUsedRegister = 0;
        registerVars = {};
        v6Mode = options.v6 == true;
        v7Mode = options.v7 == true;
        v8Mode = options.v8 == true;
        buildSeed = tonumber(options.seed) or 0;

         
         
         
        VAR_REGISTER = {};
        RETURN_ALL = {};
        POS_REGISTER = {};
        RETURN_REGISTER = {};
        UPVALUE = {};

        BIN_OPS = lookupify{
            AstKind.LessThanExpression,
            AstKind.GreaterThanExpression,
            AstKind.LessThanOrEqualsExpression,
            AstKind.GreaterThanOrEqualsExpression,
            AstKind.NotEqualsExpression,
            AstKind.EqualsExpression,
            AstKind.StrCatExpression,
            AstKind.AddExpression,
            AstKind.SubExpression,
            AstKind.MulExpression,
            AstKind.DivExpression,
            AstKind.ModExpression,
            AstKind.PowExpression,
        };
    };

    setmetatable(compiler, self);
    self.__index = self;

    return compiler;
end

blockModule(Compiler);
registerModule(Compiler);
upvalueModule(Compiler);
emitModule(Compiler);
compileCoreModule(Compiler);

function Compiler:pushRegisterUsageInfo()
    table.insert(self.registerUsageStack, {
        usedRegisters = self.usedRegisters;
        registers = self.registers;
    });
    self.usedRegisters = 0;
    self.registers = {};
end

function Compiler:popRegisterUsageInfo()
    local info = table.remove(self.registerUsageStack);
    self.usedRegisters = info.usedRegisters;
    self.registers = info.registers;
end

function Compiler:compile(ast)
     
     
     
    if self.v8Mode then math.randomseed(123456) end
     
    Scope.resetNameCounter()
    self.blocks = {};
    self.registers = {};
    self.activeBlock = nil;
    self.registersForVar = {};
    self.scopeFunctionDepths = {};
    self.maxUsedRegister = 0;
    self.usedRegisters = 0;
    self.registerVars = {};
    self.usedBlockIds = {};
    self.vmOpMap = {};
    self.vmMicroOpCount = 0;
    self.vmFusionMap = {};
    self.vmFusionPairs = {};
    self.vmFusionHandlerMap = {};
    self.vmFusionCount = 0;
    self.vmFusionUseCount = 0;
    self.vmDispatchStrategy = self.v7Mode and math.random(1, 6) or (self.v6Mode and math.random(1, 3) or 1);
    if self.v8Mode then
         
        self.vmDispatchStrategy = math.random(1, 6);
         
         
         
         
         
         
        self.vmExecutionFamily = 1;
        self.vmDispatchTopology = v8SeededValue(self.buildSeed, 178, 3) + 1;
         
         
         
         
        self.vmExecutionBucketWidth = ({2, 3, 4, 5})[v8SeededValue(self.buildSeed, 179, 4) + 1];
        self.vmExecutionKeyModulus = 2^24;
        local seedKey = math.floor(math.abs(self.buildSeed)) % (self.vmExecutionKeyModulus / 2);
        self.vmExecutionKeyMul = ((seedKey * 48271 + 1) % (self.vmExecutionKeyModulus / 2)) * 2 + 1;
        self.vmExecutionKeyAdd = (seedKey * 69621 + 12345) % self.vmExecutionKeyModulus;
    else
        self.vmExecutionFamily = 1;
    end
    self.vmRepresentationFamily = self.v7Mode and math.random(1, 4) or 1;
    if self.v8Mode then
         
         
         
         
         
        self.vmRepresentationFamily = v8SeededValue(self.buildSeed, 405, 8) + 1;
    end
    self.vmRollingStateModulus = self.v7Mode and ({65536, 131072, 262144, 524288})[math.random(1, 4)] or 65536;
    self.vmRollingStateMul = math.random(0, self.vmRollingStateModulus - 1) * 2 + 1;
    if self.vmRollingStateMul >= self.vmRollingStateModulus then self.vmRollingStateMul = self.vmRollingStateMul - 2; end
    self.vmRollingStateAdd = math.random(0, self.vmRollingStateModulus - 1);
    self.vmRollingStateInit = math.random(1, self.vmRollingStateModulus - 1);

     
     
     
     
     
     
    local registerBankSizes = {80, 88, 96, 104, 112, 120};
    self.maxRegs = registerBankSizes[math.random(1, #registerBankSizes)];

     
     
     
    local blockIdWidths = self.v7Mode and {22, 23, 24, 25, 26} or {20, 21, 22, 23, 24};
    if self.v8Mode then blockIdWidths = {24, 25, 26}; end
    self.blockIdModulus = 2^blockIdWidths[math.random(1, #blockIdWidths)];
     
     
    math.random(0, self.blockIdModulus - 1);
    math.random(0, self.blockIdModulus - 1);
    self.blockIdMul = v8SeededOdd(self.buildSeed, 101, self.blockIdModulus);
    self.blockIdAdd = v8SeededValue(self.buildSeed, 102, self.blockIdModulus);

     
     
     
     
    if self.v8Mode then
        local function modInverse(a, m)
            local t, newt = 0, 1;
            local r, newr = m, a;
            while newr ~= 0 do
                local q = math.floor(r / newr);
                t, newt = newt, t - q * newt;
                r, newr = newr, r - q * newr;
            end
            if t < 0 then t = t + m; end
            return t;
        end
        self.vmStateModulus = self.blockIdModulus;
        self.vmStateFamilyCount = 4;
        self.vmStateFamilies = {};
        self.vmStateEdgeCount = 0;
        self.vmStateEdgeFamilies = {};
        for family = 1, self.vmStateFamilyCount do
            math.random(0, self.vmStateModulus - 1);
            math.random(0, self.vmStateModulus - 1);
            local mul = v8SeededOdd(self.buildSeed, 200 + family * 2, self.vmStateModulus);
            local add = v8SeededValue(self.buildSeed, 201 + family * 2, self.vmStateModulus);
            self.vmStateFamilies[family] = {mul=mul, add=add, inverse=modInverse(mul, self.vmStateModulus)};
        end
         
        self.vmStateMul = self.vmStateFamilies[1].mul;
        self.vmStateAdd = self.vmStateFamilies[1].add;
        self.vmStateInverse = self.vmStateFamilies[1].inverse;
        local integrityModuli = {65536, 131072, 262144, 524288};
        local integrityModulusIndex = math.random(1, #integrityModuli);
        self.vmStateIntegrityModulus = integrityModuli[integrityModulusIndex];
        math.random(0, self.vmStateIntegrityModulus - 1);
        math.random(0, self.vmStateIntegrityModulus - 1);
        math.random(1, self.vmStateIntegrityModulus - 1);
        self.vmStateIntegrityMul = v8SeededOdd(self.buildSeed, 302, self.vmStateIntegrityModulus);
        self.vmStateIntegrityAdd = v8SeededValue(self.buildSeed, 303, self.vmStateIntegrityModulus);
        self.vmStateIntegrityInit = v8SeededValue(self.buildSeed, 304, self.vmStateIntegrityModulus - 1) + 1;
    end

    self.upvalVars = {};
    self.registerUsageStack = {};

    self.upvalsProxyLenReturn = math.random(-2^22, 2^22);

    local newGlobalScope = Scope:newGlobal();
    local psc = Scope:new(newGlobalScope, nil);

    local _, getfenvVar = newGlobalScope:resolve("getfenv");
    local _, tableVar = newGlobalScope:resolve("table");
    local _, unpackVar = newGlobalScope:resolve("unpack");
    local _, envVar = newGlobalScope:resolve("_ENV");
    local _, setmetatableVar = newGlobalScope:resolve("setmetatable");
    local _, getmetatableVar = newGlobalScope:resolve("getmetatable");
    local _, selectVar = newGlobalScope:resolve("select");

    psc:addReferenceToHigherScope(newGlobalScope, getfenvVar, 2);
    psc:addReferenceToHigherScope(newGlobalScope, tableVar);
    psc:addReferenceToHigherScope(newGlobalScope, unpackVar);
    psc:addReferenceToHigherScope(newGlobalScope, envVar);
    psc:addReferenceToHigherScope(newGlobalScope, setmetatableVar);
    psc:addReferenceToHigherScope(newGlobalScope, getmetatableVar);

    self.scope = Scope:new(psc);
    self.envVar = self.scope:addVariable();
    self.containerFuncVar = self.scope:addVariable();
    self.unpackVar = self.scope:addVariable();
    self.setmetatableVar = self.scope:addVariable();
    self.getmetatableVar = self.scope:addVariable();
    self.selectVar = self.scope:addVariable();
     
     
    self.newproxyVar = self.scope:addVariable();
    self.contextSentinelArg = self.scope:addVariable();

    local argVar = self.scope:addVariable();

    self.containerFuncScope = Scope:new(self.scope);
    self.whileScope = Scope:new(self.containerFuncScope);

    self.posVar = self.containerFuncScope:addVariable();
    self.vmStateVar = self.containerFuncScope:addVariable();
    self.vmDispatchTableVar = self.containerFuncScope:addVariable();
    self.vmStateFamilyVar = self.containerFuncScope:addVariable();
    self.argsVar = self.containerFuncScope:addVariable();
    self.currentUpvaluesVar = self.containerFuncScope:addVariable();
    self.detectGcCollectVar = self.containerFuncScope:addVariable();
    self.returnVar = self.containerFuncScope:addVariable();
    self.vmIntegrityVar = self.v6Mode and self.containerFuncScope:addVariable() or nil;
    self.vmStateIntegrityVar = self.v8Mode and self.containerFuncScope:addVariable() or nil;

    self.upvaluesTable = self.scope:addVariable();
    self.upvaluesReferenceCountsTable = self.scope:addVariable();
    self.allocUpvalFunction = self.scope:addVariable();
    self.currentUpvalId = self.scope:addVariable();

    self.upvaluesProxyFunctionVar = self.scope:addVariable();
    self.upvaluesGcFunctionVar = self.scope:addVariable();
    self.freeUpvalueFunc = self.scope:addVariable();

     
     
     
     
    self.vmOpsVar = self.scope:addVariable();
    self.vmFusionVar = self.scope:addVariable();
     
     
     
     
    self.vmConstDecoderVar = self.scope:addVariable();
     
     
     
     
    self.vmHandlerMapVar = self.scope:addVariable();
    self.vmHandlerRouteMapVar = self.scope:addVariable();
    self.vmRegisterMapVar = self.scope:addVariable();
    self.vmHandlerTokenMap = {};
    self.vmHandlerTokenCount = 0;
    self.vmHandlerRouteCount = 0;
    self.vmRegisterSlotMap = {};
    self.vmRegisterBankWidth = 0;
    self.vmBranchHandlerMapVar = self.scope:addVariable();
self.vmBranchRouteMapVar = self.scope:addVariable();
    self.vmBranchRouteCount = 0;
    self.vmContextVar = self.scope:addVariable();

     
     
     
     
    local usedContextKeys = {};
    local function nextContextKey()
        local key;
        repeat
            key = math.random(1000000, 9000000);
        until not usedContextKeys[key];
        usedContextKeys[key] = true;
        return key;
    end

     
     
     
     
     
    self.vmEntangleWidth = math.random(3, 7);
    self.vmEntangleModulus = 65536;
    self.vmEntangleMul = math.random(0, self.vmEntangleModulus - 1) * 2 + 1;
    if self.vmEntangleMul >= self.vmEntangleModulus then
        self.vmEntangleMul = self.vmEntangleMul - 2;
    end
    self.vmEntangleAdd = math.random(0, self.vmEntangleModulus - 1);
    self.vmEntangleInit = math.random(1, self.vmEntangleModulus - 1);

    self.vmContextKeyMap = {
        handler = nextContextKey(),
        handlerRoute = nextContextKey(),
        register = nextContextKey(),
        branchHandler = nextContextKey(),
        branchRoute = nextContextKey(),
        entangle = nextContextKey(),
        entangleWidth = nextContextKey(),
    };

    self.vmDecoyCount = self.v7Mode and math.random(3, 8) or 0;
    self.vmDecoyKeys = {};
    for _ = 1, self.vmDecoyCount do
        self.vmDecoyKeys[#self.vmDecoyKeys + 1] = nextContextKey();
    end
     
     
     
    self.vmBranchOpsVar = self.scope:addVariable();
     
    self.vmBranchHandlerMapVar = self.scope:addVariable();
    self.vmBranchRouteMapVar = self.scope:addVariable();
    self.vmBranchMicroOpCount = 0;
    self.vmBranchRouteCount = 0;
    self.createClosureVars = {};
    self.createVarargClosureVar = self.scope:addVariable();
    local createClosureScope = Scope:new(self.scope);
    local createClosurePosArg = createClosureScope:addVariable();
    local createClosureUpvalsArg = createClosureScope:addVariable();
    local createClosureProxyObject = createClosureScope:addVariable();
    local createClosureFuncVar = createClosureScope:addVariable();

    local createClosureSubScope = Scope:new(createClosureScope);

    local upvalEntries = {};
    local upvalueIds = {};
    self.getUpvalueId = function(self, scope, id)
        local expression;
        local scopeFuncDepth = self.scopeFunctionDepths[scope];
        if(scopeFuncDepth == 0) then
            if upvalueIds[id] then
                return upvalueIds[id];
            end
            expression = Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.allocUpvalFunction), {});
        else
            require("logger"):error("Unresolved Upvalue, this error should not occur!");
        end
        table.insert(upvalEntries, Ast.TableEntry(expression));
        local uid = #upvalEntries;
        upvalueIds[id] = uid;
        return uid;
    end

    createClosureSubScope:addReferenceToHigherScope(self.scope, self.containerFuncVar);
    createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosurePosArg)
    createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureUpvalsArg, 1)
    createClosureScope:addReferenceToHigherScope(self.scope, self.upvaluesProxyFunctionVar)
    createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureProxyObject);

    local vmOpKinds = {
        AstKind.LessThanExpression,
        AstKind.GreaterThanExpression,
        AstKind.LessThanOrEqualsExpression,
        AstKind.GreaterThanOrEqualsExpression,
        AstKind.NotEqualsExpression,
        AstKind.EqualsExpression,
        AstKind.StrCatExpression,
        AstKind.AddExpression,
        AstKind.SubExpression,
        AstKind.MulExpression,
        AstKind.DivExpression,
        AstKind.ModExpression,
        AstKind.PowExpression,
        AstKind.NotExpression,
        AstKind.NegateExpression,
        AstKind.LenExpression,
    };
    local vmOpIds = {};
    local shuffledVmKinds = util.shuffle({unpack(vmOpKinds)});
    local opcodeIds = {};
    local opcodeUsed = {};
    local opcodeLayout = self.v8Mode and math.random(1, 4) or 1;
    local function nextOpcodeId()
        local id;
        repeat
            if opcodeLayout == 1 then
                id = #opcodeIds + 1;
            elseif opcodeLayout == 2 then
                id = #shuffledVmKinds - #opcodeIds;
            elseif opcodeLayout == 3 then
                id = math.random(1000, 900000);
            else
                id = math.random(1, 2^20);
            end
        until not opcodeUsed[id];
        opcodeUsed[id] = true;
        opcodeIds[#opcodeIds + 1] = id;
        return id;
    end
    for i, kind in ipairs(shuffledVmKinds) do
        local opId = nextOpcodeId();
        vmOpIds[kind] = opId;
        self.vmOpMap[kind] = opId;
    end
    self.vmOpcodeLayout = opcodeLayout;

     
     
     
     
     
     
    local decoderFamilies = {1, 2, 4};
    self.vmConstDecoderFamily = self.v8Mode and decoderFamilies[v8SeededValue(self.buildSeed, 401, #decoderFamilies) + 1] or 1;
    self.vmConstDecoderModulus = self.v8Mode and 16777216 or 1048576;
    math.random(0, self.vmConstDecoderModulus - 1);
    self.vmConstDecoderMul = v8SeededOdd(self.buildSeed, 402, self.vmConstDecoderModulus);
    local function constModInverse(a, m)
        local t, newt = 0, 1;
        local r, newr = m, a;
        while newr ~= 0 do
            local q = math.floor(r / newr);
            t, newt = newt, t - q * newt;
            r, newr = newr, r - q * newr;
        end
        if t < 0 then t = t + m; end
        return t;
    end
    self.vmConstDecoderInverse = constModInverse(self.vmConstDecoderMul, self.vmConstDecoderModulus);
    math.random(0, self.vmConstDecoderModulus - 1);
    math.random(1, 65535);
    self.vmConstDecoderAdd = v8SeededValue(self.buildSeed, 403, self.vmConstDecoderModulus);
    self.vmConstDecoderSaltMul = v8SeededValue(self.buildSeed, 404, 65535) + 1;

     
     
     
     
     
    self.vmFusionMap = {};
    self.vmFusionPairs = {};
    self.vmFusionHandlerMap = {};
    local fusionKinds = {
        AstKind.AddExpression,
        AstKind.SubExpression,
        AstKind.MulExpression,
        AstKind.DivExpression,
        AstKind.ModExpression,
        AstKind.PowExpression,
        AstKind.StrCatExpression,
    };
    local fusionCandidates = {};
    for _, outerKind in ipairs(fusionKinds) do
        for _, innerKind in ipairs(fusionKinds) do
            fusionCandidates[#fusionCandidates + 1] = {outer=outerKind, inner=innerKind};
        end
    end
    util.shuffle(fusionCandidates);
    local fusionTarget = self.v8Mode and (3 + (123456 % 6)) or 0;
    local selected = {};
    local function addFusionPair(pair)
        local key = tostring(pair.outer) .. "|" .. tostring(pair.inner);
        if selected[key] then return false end
        selected[key] = true;
        self.vmFusionMap[pair.outer] = self.vmFusionMap[pair.outer] or {};
        local pairId = #self.vmFusionPairs + 1;
        self.vmFusionMap[pair.outer][pair.inner] = pairId;
        self.vmFusionPairs[pairId] = {outer=pair.outer, inner=pair.inner};
        return true;
    end
    if fusionTarget > 0 then
         
         
        addFusionPair({outer=AstKind.MulExpression, inner=AstKind.AddExpression});
    end
    local candidateIndex = 1;
    while #self.vmFusionPairs < fusionTarget and candidateIndex <= #fusionCandidates do
        addFusionPair(fusionCandidates[candidateIndex]);
        candidateIndex = candidateIndex + 1;
    end
    self.vmFusionCount = #self.vmFusionPairs;

     
     
     
     
     
    local function vmContextRef(key)
        return Ast.IndexExpression(
            Ast.VariableExpression(self.scope, self.vmContextVar),
            Ast.NumberExpression(self.vmContextKeyMap[key])
        );
    end

     
     
     
    local function encodeVmConstant(value, salt)
        local m = self.vmConstDecoderModulus;
        local v = value % m;
        local saltTerm = (salt * self.vmConstDecoderSaltMul) % m;
        local family = self.vmConstDecoderFamily;
        if family == 1 then
            return (v * self.vmConstDecoderMul + self.vmConstDecoderAdd + saltTerm) % m;
        elseif family == 2 then
            return (v * self.vmConstDecoderMul - self.vmConstDecoderAdd + saltTerm) % m;
        elseif family == 3 then
            return (v + self.vmConstDecoderAdd + saltTerm) % m;
        else
            return (v * self.vmConstDecoderMul + self.vmConstDecoderAdd - saltTerm) % m;
        end
    end

    local function decodedVmConstant(value, salt)
        return Ast.FunctionCallExpression(
            Ast.VariableExpression(self.scope, self.vmConstDecoderVar),
            {Ast.NumberExpression(encodeVmConstant(value, salt)), Ast.NumberExpression(salt)}
        );
    end

    local vmOpEntries = {};
    local vmHandlerEntries = {};
    local vmHandlerRouteEntries = {};
    local vmRegisterEntries = {};
    local handlerTokens = {};
    local handlerTokenUsed = {};
    local function nextHandlerToken()
        local token;
        repeat
            token = self.v8Mode and math.random(1000, 900000) or (#handlerTokens + 1);
        until not handlerTokenUsed[token];
        handlerTokenUsed[token] = true;
        handlerTokens[#handlerTokens + 1] = token;
        return token;
    end
    for _ = 1, #shuffledVmKinds do
        nextHandlerToken();
    end
    handlerTokens = util.shuffle(handlerTokens);

    local registerBankWidths = self.v7Mode and {24, 28, 32, 36, 40, 48} or {16, 20, 24, 28, 32};
    self.vmRegisterBankWidth = registerBankWidths[math.random(1, #registerBankWidths)];

    for i, kind in ipairs(shuffledVmKinds) do
        local handlerToken = handlerTokens[i];
        self.vmHandlerTokenMap[i] = handlerToken;

        local unary = kind == AstKind.NotExpression
            or kind == AstKind.NegateExpression
            or kind == AstKind.LenExpression;

        local slot1 = math.random(1, self.vmRegisterBankWidth);
        local slot2;
        if not unary then
            repeat
                slot2 = math.random(1, self.vmRegisterBankWidth);
            until slot2 ~= slot1;
        end
        self.vmRegisterSlotMap[i] = {slot1, slot2};

         
         
         
         
        local routeAliases = {};
        for alias = 1, self.vmEntangleWidth do
            routeAliases[#routeAliases + 1] = Ast.TableEntry(decodedVmConstant(handlerToken, i + alias + 211));
        end
        vmHandlerRouteEntries[#vmHandlerRouteEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(i),
            Ast.TableConstructorExpression(routeAliases)
        );

        local registerItems = {
            Ast.TableEntry(Ast.NumberExpression(slot1)),
        };
        if slot2 then
            registerItems[#registerItems + 1] = Ast.TableEntry(Ast.NumberExpression(slot2));
        end

        vmRegisterEntries[#vmRegisterEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(i),
            Ast.TableConstructorExpression(registerItems)
        );

        local opScope = Scope:new(self.scope);
        local rhsVar = opScope:addVariable();
        local rhs = Ast.VariableExpression(opScope, rhsVar);
        local args;
        local opExpression;

        if unary then
            args = {Ast.VariableExpression(opScope, rhsVar)};
            opExpression = Ast[kind](rhs);
        else
            local lhsVar = opScope:addVariable();
            local lhs = Ast.VariableExpression(opScope, lhsVar);
            args = {
                Ast.VariableExpression(opScope, lhsVar),
                Ast.VariableExpression(opScope, rhsVar)
            };
            opExpression = Ast[kind](lhs, rhs);
        end

        vmHandlerEntries[#vmHandlerEntries + 1] = Ast.KeyedTableEntry(
            decodedVmConstant(handlerToken, i + 311),
            Ast.FunctionLiteralExpression(
                args,
                Ast.Block({Ast.ReturnStatement({opExpression})}, opScope)
            )
        );

        local wrapperScope = Scope:new(self.scope);
        local wrapperArgs = {};
        local wrapperStatements = {};
        local bankVar = wrapperScope:addVariable();

        wrapperStatements[#wrapperStatements + 1] = Ast.LocalVariableDeclaration(
            wrapperScope,
            {bankVar},
            {Ast.TableConstructorExpression({})}
        );

        local arg1 = wrapperScope:addVariable();
        wrapperArgs[1] = Ast.VariableExpression(wrapperScope, arg1);
        local arg1Expr = Ast.VariableExpression(wrapperScope, arg1);

        local registerLookupForWrite1 = Ast.IndexExpression(
            vmContextRef("register"),
            Ast.NumberExpression(i)
        );
        local slot1ExprForWrite = Ast.IndexExpression(
            registerLookupForWrite1,
            Ast.NumberExpression(1)
        );

        wrapperStatements[#wrapperStatements + 1] = Ast.AssignmentStatement(
            {Ast.IndexExpression(
                Ast.VariableExpression(wrapperScope, bankVar),
                slot1ExprForWrite
            )},
            {arg1Expr}
        );

        local registerLookupForRead1 = Ast.IndexExpression(
            vmContextRef("register"),
            Ast.NumberExpression(i)
        );
        local slot1ExprForRead = Ast.IndexExpression(
            registerLookupForRead1,
            Ast.NumberExpression(1)
        );

        local callArgs = {};
        callArgs[1] = Ast.IndexExpression(
            Ast.VariableExpression(wrapperScope, bankVar),
            slot1ExprForRead
        );

        if not unary then
            local arg2 = wrapperScope:addVariable();
            wrapperArgs[2] = Ast.VariableExpression(wrapperScope, arg2);
            local arg2Expr = Ast.VariableExpression(wrapperScope, arg2);

            local registerLookupForWrite2 = Ast.IndexExpression(
                vmContextRef("register"),
                Ast.NumberExpression(i)
            );
            local slot2ExprForWrite = Ast.IndexExpression(
                registerLookupForWrite2,
                Ast.NumberExpression(2)
            );

            wrapperStatements[#wrapperStatements + 1] = Ast.AssignmentStatement(
                {Ast.IndexExpression(
                    Ast.VariableExpression(wrapperScope, bankVar),
                    slot2ExprForWrite
                )},
                {arg2Expr}
            );

            local registerLookupForRead2 = Ast.IndexExpression(
                vmContextRef("register"),
                Ast.NumberExpression(i)
            );
            local slot2ExprForRead = Ast.IndexExpression(
                registerLookupForRead2,
                Ast.NumberExpression(2)
            );

            callArgs[2] = Ast.IndexExpression(
                Ast.VariableExpression(wrapperScope, bankVar),
                slot2ExprForRead
            );
        end

        local routeAliasesLookup = Ast.IndexExpression(
            vmContextRef("handlerRoute"),
            Ast.NumberExpression(i)
        );
        local routeAliasIndex = Ast.AddExpression(
            Ast.ModExpression(
                vmContextRef("entangle"),
                vmContextRef("entangleWidth")
            ),
            Ast.NumberExpression(1),
            false
        );
        local routeLookup = Ast.IndexExpression(routeAliasesLookup, routeAliasIndex);
        local handlerLookup = Ast.IndexExpression(
            vmContextRef("handler"),
            routeLookup
        );
        local handlerCall = Ast.FunctionCallExpression(handlerLookup, callArgs);
        local resultVar = wrapperScope:addVariable();
        wrapperStatements[#wrapperStatements + 1] = Ast.LocalVariableDeclaration(
            wrapperScope, {resultVar}, {handlerCall}
        );
         
         
        wrapperStatements[#wrapperStatements + 1] = Ast.AssignmentStatement(
            {Ast.AssignmentIndexing(
                Ast.VariableExpression(self.scope, self.vmContextVar),
                Ast.NumberExpression(self.vmContextKeyMap.entangle)
            )},
            {Ast.ModExpression(
                Ast.AddExpression(
                    Ast.MulExpression(
                        vmContextRef("entangle"),
                        Ast.NumberExpression(self.vmEntangleMul),
                        false
                    ),
                    Ast.NumberExpression(handlerToken + i),
                    false
                ),
                Ast.NumberExpression(self.vmEntangleModulus)
            )}
        );
        wrapperStatements[#wrapperStatements + 1] = Ast.ReturnStatement({Ast.VariableExpression(wrapperScope, resultVar)});

        vmOpEntries[#vmOpEntries + 1] = Ast.KeyedTableEntry(
            decodedVmConstant(self.vmOpMap[kind], i + 101),
            Ast.FunctionLiteralExpression(
                wrapperArgs,
                Ast.Block(wrapperStatements, wrapperScope)
            )
        );
    end
     
     
     
     
    local vmFusionEntries = {};
    local nextFusionHandlerId = 0;
    for pairId, pair in ipairs(self.vmFusionPairs) do
        self.vmFusionHandlerMap[pairId] = {};
        for _, orientation in ipairs({"left", "right"}) do
            nextFusionHandlerId = nextFusionHandlerId + 1;
            self.vmFusionHandlerMap[pairId][orientation] = nextFusionHandlerId;
            local fusionScope = Scope:new(self.scope);
            local aVar = fusionScope:addVariable();
            local bVar = fusionScope:addVariable();
            local cVar = fusionScope:addVariable();
            local a = Ast.VariableExpression(fusionScope, aVar);
            local b = Ast.VariableExpression(fusionScope, bVar);
            local c = Ast.VariableExpression(fusionScope, cVar);
            local inner = Ast[pair.inner](a, b);
            local fused;
            if orientation == "left" then
                fused = Ast[pair.outer](inner, c);
            else
                fused = Ast[pair.outer](a, inner);
            end
            vmFusionEntries[#vmFusionEntries + 1] = Ast.KeyedTableEntry(
                decodedVmConstant(nextFusionHandlerId, nextFusionHandlerId + 701),
                Ast.FunctionLiteralExpression(
                    {a, b, c},
                    Ast.Block({Ast.ReturnStatement({fused})}, fusionScope)
                )
            );
        end
    end
    self.vmFusionCount = nextFusionHandlerId;

    if self.v7Mode then
        for d = 1, self.vmDecoyCount do
            local token = nextHandlerToken();
            local decoyScope = Scope:new(self.scope);
            local decoyArg = decoyScope:addVariable();
            local decoyExpr = Ast.AddExpression(
                Ast.VariableExpression(decoyScope, decoyArg),
                Ast.NumberExpression(d),
                false
            );
            vmHandlerEntries[#vmHandlerEntries + 1] = Ast.KeyedTableEntry(
                Ast.NumberExpression(token),
                Ast.FunctionLiteralExpression(
                    {Ast.VariableExpression(decoyScope, decoyArg)},
                    Ast.Block({Ast.ReturnStatement({decoyExpr})}, decoyScope)
                )
            );
        end
    end
    self.vmHandlerTokenCount = #handlerTokens + (self.vmDecoyCount or 0);
    self.vmHandlerRouteCount = #vmHandlerRouteEntries;

     
     
     
    local branchKinds = {
        AstKind.LessThanExpression,
        AstKind.GreaterThanExpression,
        AstKind.EqualsExpression,
    };
    local shuffledBranchKinds = util.shuffle({unpack(branchKinds)});
    self.vmBranchOpMap = {};
    local vmBranchEntries = {};
    local vmBranchHandlerEntries = {};
    local vmBranchRouteEntries = {};
    local branchHandlerTokens = {1, 2, 3};
    branchHandlerTokens = util.shuffle(branchHandlerTokens);

    for i, kind in ipairs(shuffledBranchKinds) do
        self.vmBranchOpMap[kind] = i;
        local handlerToken = branchHandlerTokens[i];
        local branchScope = Scope:new(self.scope);
        local lhsVar = branchScope:addVariable();
        local rhsVar = branchScope:addVariable();

        local lhsArg = Ast.VariableExpression(branchScope, lhsVar);
        local rhsArg = Ast.VariableExpression(branchScope, rhsVar);
        local lhsExpr = Ast.VariableExpression(branchScope, lhsVar);
        local rhsExpr = Ast.VariableExpression(branchScope, rhsVar);
        local opExpression = Ast[kind](lhsExpr, rhsExpr);

        vmBranchHandlerEntries[#vmBranchHandlerEntries + 1] = Ast.KeyedTableEntry(
            decodedVmConstant(handlerToken, i + 401),
            Ast.FunctionLiteralExpression(
                {lhsArg, rhsArg},
                Ast.Block({Ast.ReturnStatement({opExpression})}, branchScope)
            )
        );

        local branchRouteAliases = {};
        for alias = 1, self.vmEntangleWidth do
            branchRouteAliases[#branchRouteAliases + 1] = Ast.TableEntry(decodedVmConstant(handlerToken, i + alias + 501));
        end
        vmBranchRouteEntries[#vmBranchRouteEntries + 1] = Ast.KeyedTableEntry(
            Ast.NumberExpression(i),
            Ast.TableConstructorExpression(branchRouteAliases)
        );

         
         
        local wrapperScope = Scope:new(self.scope);
        local wrapperLhsVar = wrapperScope:addVariable();
        local wrapperRhsVar = wrapperScope:addVariable();
        local wrapperLhs = Ast.VariableExpression(wrapperScope, wrapperLhsVar);
        local wrapperRhs = Ast.VariableExpression(wrapperScope, wrapperRhsVar);
        local wrapperLhsExpr = Ast.VariableExpression(wrapperScope, wrapperLhsVar);
        local wrapperRhsExpr = Ast.VariableExpression(wrapperScope, wrapperRhsVar);

        local branchRouteAliasesLookup = Ast.IndexExpression(
            vmContextRef("branchRoute"),
            Ast.NumberExpression(i)
        );
        local branchAliasIndex = Ast.AddExpression(
            Ast.ModExpression(
                vmContextRef("entangle"),
                vmContextRef("entangleWidth")
            ),
            Ast.NumberExpression(1),
            false
        );
        local routeLookup = Ast.IndexExpression(branchRouteAliasesLookup, branchAliasIndex);
        local handlerLookup = Ast.IndexExpression(
            vmContextRef("branchHandler"),
            routeLookup
        );
        local handlerCall = Ast.FunctionCallExpression(handlerLookup, {
            wrapperLhsExpr,
            wrapperRhsExpr
        });
        local branchResultVar = wrapperScope:addVariable();
        local branchStatements = {
            Ast.LocalVariableDeclaration(wrapperScope, {branchResultVar}, {handlerCall}),
            Ast.AssignmentStatement(
                {Ast.AssignmentIndexing(
                    Ast.VariableExpression(self.scope, self.vmContextVar),
                    Ast.NumberExpression(self.vmContextKeyMap.entangle)
                )},
                {Ast.ModExpression(
                    Ast.AddExpression(
                        Ast.MulExpression(vmContextRef("entangle"), Ast.NumberExpression(self.vmEntangleMul), false),
                        Ast.NumberExpression(handlerToken + i + 17),
                        false
                    ),
                    Ast.NumberExpression(self.vmEntangleModulus)
                )}
            ),
            Ast.ReturnStatement({Ast.VariableExpression(wrapperScope, branchResultVar)})
        };

        vmBranchEntries[#vmBranchEntries + 1] = Ast.KeyedTableEntry(
            decodedVmConstant(i, i + 601),
            Ast.FunctionLiteralExpression(
                {wrapperLhs, wrapperRhs},
                Ast.Block(branchStatements, wrapperScope)
            )
        );
    end
    self.vmBranchRouteCount = #vmBranchRouteEntries;

     
     
     
    local branchCount = 0;
    local branchKindsForCount = {
        [AstKind.LessThanExpression] = true,
        [AstKind.GreaterThanExpression] = true,
        [AstKind.LessThanOrEqualsExpression] = true,
        [AstKind.GreaterThanOrEqualsExpression] = true,
        [AstKind.NotEqualsExpression] = true,
        [AstKind.EqualsExpression] = true,
    };
    visitAst(ast, nil, function(node)
        if node and branchKindsForCount[node.kind] then
            branchCount = branchCount + 1;
        end
        return node;
    end, {});

    self:compileTopNode(ast);
    self.vmBranchMicroOpCount = branchCount;

    local decoderScope = Scope:new(self.scope);
    local decoderXVar = decoderScope:addVariable();
    local decoderSaltVar = decoderScope:addVariable();
    local decoderX = Ast.VariableExpression(decoderScope, decoderXVar);
    local decoderSalt = Ast.VariableExpression(decoderScope, decoderSaltVar);
    local decoderMod = Ast.NumberExpression(self.vmConstDecoderModulus);
    local decoderSaltTerm = Ast.ModExpression(
        Ast.MulExpression(decoderSalt, Ast.NumberExpression(self.vmConstDecoderSaltMul), false),
        decoderMod
    );
    local decoderAdd = Ast.NumberExpression(self.vmConstDecoderAdd);
    local decoderInv = Ast.NumberExpression(self.vmConstDecoderInverse);
    local decoderBodyExpr;
    if self.vmConstDecoderFamily == 1 then
        decoderBodyExpr = Ast.ModExpression(
            Ast.MulExpression(
                Ast.SubExpression(Ast.SubExpression(decoderX, decoderAdd, false), decoderSaltTerm, false),
                decoderInv,
                false
            ),
            decoderMod
        );
    elseif self.vmConstDecoderFamily == 2 then
        decoderBodyExpr = Ast.ModExpression(
            Ast.MulExpression(
                Ast.SubExpression(Ast.AddExpression(decoderX, decoderAdd, false), decoderSaltTerm, false),
                decoderInv,
                false
            ),
            decoderMod
        );
    elseif self.vmConstDecoderFamily == 3 then
        decoderBodyExpr = Ast.ModExpression(
            Ast.SubExpression(Ast.SubExpression(decoderX, decoderAdd, false), decoderSaltTerm, false),
            decoderMod
        );
    else
        decoderBodyExpr = Ast.ModExpression(
            Ast.MulExpression(
                Ast.AddExpression(Ast.SubExpression(decoderX, decoderAdd, false), decoderSaltTerm, false),
                decoderInv,
                false
            ),
            decoderMod
        );
    end
    local vmConstDecoderAssignment = Ast.AssignmentStatement(
        {Ast.AssignmentVariable(self.scope, self.vmConstDecoderVar)},
        {Ast.FunctionLiteralExpression(
            {decoderX, decoderSalt},
            Ast.Block({Ast.ReturnStatement({decoderBodyExpr})}, decoderScope)
        )}
    );

    local functionNodeAssignments = {
        {
            var = Ast.AssignmentVariable(self.scope, self.vmHandlerRouteMapVar),
            val = Ast.TableConstructorExpression(vmHandlerRouteEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmRegisterMapVar),
            val = Ast.TableConstructorExpression(vmRegisterEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmHandlerMapVar),
            val = Ast.TableConstructorExpression(vmHandlerEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmOpsVar),
            val = Ast.TableConstructorExpression(vmOpEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmFusionVar),
            val = Ast.TableConstructorExpression(vmFusionEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmBranchHandlerMapVar),
            val = Ast.TableConstructorExpression(vmBranchHandlerEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmBranchRouteMapVar),
            val = Ast.TableConstructorExpression(vmBranchRouteEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.vmBranchOpsVar),
            val = Ast.TableConstructorExpression(vmBranchEntries),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.containerFuncVar),
            val = Ast.FunctionLiteralExpression({
                Ast.VariableExpression(self.containerFuncScope, self.posVar),
                Ast.VariableExpression(self.containerFuncScope, self.argsVar),
                Ast.VariableExpression(self.containerFuncScope, self.currentUpvaluesVar),
                Ast.VariableExpression(self.containerFuncScope, self.detectGcCollectVar)
            }, self:emitContainerFuncBody());
        }, {
            var = Ast.AssignmentVariable(self.scope, self.createVarargClosureVar),
            val = Ast.FunctionLiteralExpression({
                    Ast.VariableExpression(createClosureScope, createClosurePosArg),
                    Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
                },
                Ast.Block({
                    Ast.LocalVariableDeclaration(createClosureScope, {
                        createClosureProxyObject
                    }, {
                        Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.upvaluesProxyFunctionVar), {
                            Ast.VariableExpression(createClosureScope, createClosureUpvalsArg)
                        })
                    }),
                    Ast.LocalVariableDeclaration(createClosureScope, {createClosureFuncVar},{
                        Ast.FunctionLiteralExpression({
                            Ast.VarargExpression();
                        },
                        Ast.Block({
                            Ast.ReturnStatement{
                                Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.containerFuncVar), {
                                    Ast.VariableExpression(createClosureScope, createClosurePosArg),
                                    Ast.TableConstructorExpression({Ast.TableEntry(Ast.VarargExpression())}),
                                    Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
                                    Ast.VariableExpression(createClosureScope, createClosureProxyObject)
                                })
                            }
                        }, createClosureSubScope)
                        );
                    });
                    Ast.ReturnStatement{Ast.VariableExpression(createClosureScope, createClosureFuncVar)};
                }, createClosureScope)
            );
        }, {
            var = Ast.AssignmentVariable(self.scope, self.newproxyVar),
            val = Ast.BooleanExpression(false),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesTable),
            val = Ast.TableConstructorExpression({}),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesReferenceCountsTable),
            val = Ast.TableConstructorExpression({}),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.allocUpvalFunction),
            val = self:createAllocUpvalFunction(),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.currentUpvalId),
            val = Ast.NumberExpression(0),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesProxyFunctionVar),
            val = self:createUpvaluesProxyFunc(),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.upvaluesGcFunctionVar),
            val = self:createUpvaluesGcFunc(),
        }, {
            var = Ast.AssignmentVariable(self.scope, self.freeUpvalueFunc),
            val = self:createFreeUpvalueFunc(),
        },
    }

    local tbl = {
        Ast.VariableExpression(self.scope, self.containerFuncVar),
        Ast.VariableExpression(self.scope, self.createVarargClosureVar),
        Ast.VariableExpression(self.scope, self.upvaluesTable),
        Ast.VariableExpression(self.scope, self.upvaluesReferenceCountsTable),
        Ast.VariableExpression(self.scope, self.allocUpvalFunction),
        Ast.VariableExpression(self.scope, self.currentUpvalId),
        Ast.VariableExpression(self.scope, self.upvaluesProxyFunctionVar),
        Ast.VariableExpression(self.scope, self.upvaluesGcFunctionVar),
        Ast.VariableExpression(self.scope, self.freeUpvalueFunc),
    };
     
    local closureIds = {};
    for i in pairs(self.createClosureVars) do
        closureIds[#closureIds + 1] = i;
    end
    table.sort(closureIds);
    for _, i in ipairs(closureIds) do
        local entry = self.createClosureVars[i];
        table.insert(functionNodeAssignments, entry);
        table.insert(tbl, Ast.VariableExpression(entry.var.scope, entry.var.id));
    end

    util.shuffle(functionNodeAssignments);
    local assignmentStatLhs, assignmentStatRhs = {}, {};
    for i, v in ipairs(functionNodeAssignments) do
        assignmentStatLhs[i] = v.var;
        assignmentStatRhs[i] = v.val;
    end


     
    local ids = util.shuffle({1, 2, 3, 4, 5, 6, 7});

    local items = {
        Ast.VariableExpression(self.scope, self.envVar),
        Ast.VariableExpression(self.scope, self.unpackVar),
        Ast.VariableExpression(self.scope, self.contextSentinelArg),
        Ast.VariableExpression(self.scope, self.setmetatableVar),
        Ast.VariableExpression(self.scope, self.getmetatableVar),
        Ast.VariableExpression(self.scope, self.selectVar),
        Ast.VariableExpression(self.scope, argVar),
    }

    local astItems = {
        Ast.OrExpression(Ast.AndExpression(Ast.VariableExpression(newGlobalScope, getfenvVar), Ast.FunctionCallExpression(Ast.VariableExpression(newGlobalScope, getfenvVar), {})), Ast.VariableExpression(newGlobalScope, envVar));
        Ast.OrExpression(Ast.VariableExpression(newGlobalScope, unpackVar), Ast.IndexExpression(Ast.VariableExpression(newGlobalScope, tableVar), Ast.StringExpression("unpack")));
        Ast.TableConstructorExpression({});
        Ast.VariableExpression(newGlobalScope, setmetatableVar);
        Ast.VariableExpression(newGlobalScope, getmetatableVar);
        Ast.VariableExpression(newGlobalScope, selectVar);
        Ast.TableConstructorExpression({
            Ast.TableEntry(Ast.VarargExpression());
        })
    }

     
     
    local vmContextAssignment = Ast.AssignmentStatement(
        {Ast.AssignmentVariable(self.scope, self.vmContextVar)},
        {Ast.TableConstructorExpression({
            Ast.KeyedTableEntry(Ast.NumberExpression(self.vmContextKeyMap.handler), Ast.VariableExpression(self.scope, self.vmHandlerMapVar)),
            Ast.KeyedTableEntry(Ast.NumberExpression(self.vmContextKeyMap.handlerRoute), Ast.VariableExpression(self.scope, self.vmHandlerRouteMapVar)),
            Ast.KeyedTableEntry(Ast.NumberExpression(self.vmContextKeyMap.register), Ast.VariableExpression(self.scope, self.vmRegisterMapVar)),
            Ast.KeyedTableEntry(Ast.NumberExpression(self.vmContextKeyMap.branchHandler), Ast.VariableExpression(self.scope, self.vmBranchHandlerMapVar)),
            Ast.KeyedTableEntry(Ast.NumberExpression(self.vmContextKeyMap.branchRoute), Ast.VariableExpression(self.scope, self.vmBranchRouteMapVar)),
            Ast.KeyedTableEntry(Ast.NumberExpression(self.vmContextKeyMap.entangle), Ast.NumberExpression(self.vmEntangleInit)),
            Ast.KeyedTableEntry(Ast.NumberExpression(self.vmContextKeyMap.entangleWidth), Ast.NumberExpression(self.vmEntangleWidth)),
            unpack((function()
                local extra = {};
                for i, key in ipairs(self.vmDecoyKeys or {}) do
                    extra[#extra + 1] = Ast.KeyedTableEntry(Ast.NumberExpression(key), Ast.TableConstructorExpression({
                        Ast.TableEntry(Ast.NumberExpression(i)),
                        Ast.TableEntry(Ast.StringExpression("v7"))
                    }));
                end
                return extra;
            end)()),
        })}
    );

    local functionNode = Ast.FunctionLiteralExpression({
      items[ids[1]], items[ids[2]], items[ids[3]], items[ids[4]],
      items[ids[5]], items[ids[6]], items[ids[7]],
      unpack(util.shuffle(tbl))
    }, Ast.Block({
        vmConstDecoderAssignment;
        Ast.AssignmentStatement(assignmentStatLhs, assignmentStatRhs);
        vmContextAssignment;
        Ast.ReturnStatement{
            Ast.FunctionCallExpression(Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.createVarargClosureVar), {
                    Ast.NumberExpression(self.startBlockId);
                    Ast.TableConstructorExpression(upvalEntries);
                }), {Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.unpackVar), {Ast.VariableExpression(self.scope, argVar)})});
        }
    }, self.scope));

    local result = Ast.TopNode(Ast.Block({
        Ast.ReturnStatement{Ast.FunctionCallExpression(functionNode, {
            astItems[ids[1]], astItems[ids[2]], astItems[ids[3]], astItems[ids[4]],
            astItems[ids[5]], astItems[ids[6]], astItems[ids[7]],
        })};
    }, psc), newGlobalScope);
    result.__v4_vm_micro_ops = self.vmMicroOpCount or 0;
     
     
     
    local uniquenessMetrics = {};
    local nodeCounts = {};
    local maxDepth = 0;
    local function scanNode(node, depth)
        if type(node) ~= "table" then return end
        if node.kind then
            local d = depth or 0;
            if d > maxDepth then maxDepth = d; end
            nodeCounts[node.kind] = (nodeCounts[node.kind] or 0) + 1;
        end
        for k, v in pairs(node) do
            if k ~= "scope" and k ~= "parentScope" and k ~= "parent" and type(v) == "table" then
                if v.kind then
                    scanNode(v, (depth or 0) + 1);
                else
                    for _, item in pairs(v) do
                        if type(item) == "table" and item.kind then
                            scanNode(item, (depth or 0) + 1);
                        end
                    end
                end
            end
        end
    end
    scanNode(result, 0);
    local function countKind(kind) return nodeCounts[kind] or 0 end
    uniquenessMetrics = {
        countKind(AstKind.FunctionLiteralExpression),
        countKind(AstKind.TableConstructorExpression),
        countKind(AstKind.FunctionCallExpression),
        countKind(AstKind.IndexExpression),
        countKind(AstKind.IfStatement),
        countKind(AstKind.WhileStatement),
        countKind(AstKind.ForStatement),
        countKind(AstKind.ForInStatement),
        countKind(AstKind.AssignmentStatement),
        countKind(AstKind.ReturnStatement),
        countKind(AstKind.AddExpression) + countKind(AstKind.SubExpression) + countKind(AstKind.MulExpression) + countKind(AstKind.DivExpression),
        countKind(AstKind.EqualsExpression) + countKind(AstKind.LessThanExpression) + countKind(AstKind.GreaterThanExpression),
        maxDepth,
        self.vmExecutionFamily or 1,
        self.vmDispatchTopology or 1,
        self.vmConstDecoderFamily or 1,
        self.vmFusionCount or 0,
        self.vmFusionUseCount or 0,
        self.vmStateFamilyCount or 0,
        self.vmEntangleWidth or 0,
        self.vmRepresentationFamily or 1,
        self.vmOpcodeLayout or 1,
         
         
         
        self.vmConstDecoderMul or 0,
        self.vmConstDecoderAdd or 0,
        self.vmConstDecoderSaltMul or 0,
        self.blockIdMul or 0,
        self.blockIdAdd or 0,
        (self.vmStateFamilies and self.vmStateFamilies[1] and self.vmStateFamilies[1].mul) or 0,
        (self.vmStateFamilies and self.vmStateFamilies[1] and self.vmStateFamilies[1].add) or 0,
        (self.vmContextKeyMap and self.vmContextKeyMap.handler) or 0,
        (self.vmHandlerTokenMap and self.vmHandlerTokenMap[1]) or 0,
    };
    local fingerprint = v8UniquenessFingerprint(uniquenessMetrics);
    local maxSimilarity = 0;
    for _, prior in ipairs(recentV8Fingerprints) do
        if prior.seed ~= self.buildSeed then
            local similarity = v8RelativeSimilarity(uniquenessMetrics, prior.metrics);
            if similarity > maxSimilarity then maxSimilarity = similarity; end
        end
    end
    local distinctBuckets = {};
    for _, value in ipairs(uniquenessMetrics) do
        local bucket = math.floor(math.abs(value) % 17);
        distinctBuckets[bucket] = true;
    end
    local distinctCount = 0;
    for _ in pairs(distinctBuckets) do distinctCount = distinctCount + 1; end
    local intrinsicScore = math.min(100, 45 + distinctCount * 3 +
        ((self.vmExecutionFamily and self.vmDispatchTopology and self.vmConstDecoderFamily) and 10 or 0));
    local distanceScore = (#recentV8Fingerprints == 0) and 100 or (100 * (1 - maxSimilarity));
    local uniquenessScore = math.floor((intrinsicScore * 0.55) + (distanceScore * 0.45) + 0.5);
    if uniquenessScore < 0 then uniquenessScore = 0 end
    if uniquenessScore > 100 then uniquenessScore = 100 end
     
     
     
     
    if #recentV8Fingerprints >= MAX_RECENT_V8_FINGERPRINTS then
        table.remove(recentV8Fingerprints, 1);
    end
    recentV8Fingerprints[#recentV8Fingerprints + 1] = {
        seed=self.buildSeed, metrics=uniquenessMetrics, fingerprint=fingerprint
    };

    result.__v6_vm_dispatch_strategy = self.v6Mode and self.vmDispatchStrategy or nil;
    result.__v6_vm_rolling_state = self.v6Mode;
    result.__v6_vm_block_count = #self.blocks;
    result.__v5_vm_handler_indirection = true;
    result.__v5_vm_handler_count = self.vmHandlerTokenCount or 0;
    result.__v6_vm_handler_route_indirection = true;
    result.__v6_vm_handler_route_count = self.vmHandlerRouteCount or 0;
    result.__v7_vm_register_indirection = true;
    result.__v7_vm_register_count = #shuffledVmKinds;
    result.__v7_vm_register_bank_width = self.vmRegisterBankWidth or 0;
    result.__v8_vm_branch_route_indirection = true;
    result.__v8_vm_branch_route_count = self.vmBranchRouteCount or 0;
    result.__v9_vm_context_indirection = true;
    result.__v9_vm_context_key_count = 7 + (self.vmDecoyCount or 0);
    result.__v10_vm_execution_entanglement = self.v8Mode and true or false;
    result.__v10_vm_entangle_width = self.v8Mode and self.vmEntangleWidth or 0;
    result.__v7_vm_representation_family = self.v7Mode and self.vmRepresentationFamily or 1;
    result.__v7_vm_decoy_count = self.vmDecoyCount or 0;
    result.__v8_vm_state_codec = self.v8Mode or false;
    result.__v8_vm_state_modulus = self.v8Mode and self.vmStateModulus or 0;
    result.__v8_vm_state_families = self.v8Mode and self.vmStateFamilyCount or 0;
    result.__v8_vm_state_integrity = self.v8Mode and true or false;
    result.__v8_vm_opcode_layout = self.v8Mode and self.vmOpcodeLayout or 1;
    result.__v8_vm_execution_family = self.v8Mode and self.vmExecutionFamily or 1;
    result.__v11_vm_dispatch_topology = self.v8Mode and (self.vmDispatchTopology or 1) or 1;
    result.__v12_vm_operation_fusion = self.v8Mode and true or false;
    result.__v12_vm_fusion_count = self.v8Mode and (self.vmFusionCount or 0) or 0;
    result.__v12_vm_fusion_use_count = self.v8Mode and (self.vmFusionUseCount or 0) or 0;
    result.__v13_vm_constant_decoder = self.v8Mode and true or false;
    result.__v13_vm_constant_decoder_family = self.v8Mode and self.vmConstDecoderFamily or 1;
    result.__v13_vm_constant_decoder_modulus = self.v8Mode and self.vmConstDecoderModulus or 0;
    result.__v14_vm_uniqueness_score = self.v8Mode and uniquenessScore or 0;
    result.__v14_vm_uniqueness_fingerprint = self.v8Mode and fingerprint or 0;
    result.__v14_vm_uniqueness_similarity = self.v8Mode and maxSimilarity or 0;
    result.__v14_vm_uniqueness_metric_count = self.v8Mode and #uniquenessMetrics or 0;
    result.__v4_vm_op_count = #shuffledVmKinds;
    result.__v4_vm_branch_ops = self.vmBranchMicroOpCount or 0;
    result.__v4_vm_branch_layout = self.vmBranchOpMap;
    result.__v4_vm_branch_opcode_count = #shuffledBranchKinds;
    return result;
end

function Compiler:getCreateClosureVar(argCount)
    if not self.createClosureVars[argCount] then
        local var = Ast.AssignmentVariable(self.scope, self.scope:addVariable());
        local createClosureScope = Scope:new(self.scope);
        local createClosureSubScope = Scope:new(createClosureScope);

        local createClosurePosArg = createClosureScope:addVariable();
        local createClosureUpvalsArg = createClosureScope:addVariable();
        local createClosureProxyObject = createClosureScope:addVariable();
        local createClosureFuncVar = createClosureScope:addVariable();

        createClosureSubScope:addReferenceToHigherScope(self.scope, self.containerFuncVar);
        createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosurePosArg)
        createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureUpvalsArg, 1)
        createClosureScope:addReferenceToHigherScope(self.scope, self.upvaluesProxyFunctionVar)
        createClosureSubScope:addReferenceToHigherScope(createClosureScope, createClosureProxyObject);

        local  argsTb, argsTb2 = {}, {};
        for i = 1, argCount do
            local arg = createClosureSubScope:addVariable()
            argsTb[i] = Ast.VariableExpression(createClosureSubScope, arg);
            argsTb2[i] = Ast.TableEntry(Ast.VariableExpression(createClosureSubScope, arg));
        end

        local val = Ast.FunctionLiteralExpression({
            Ast.VariableExpression(createClosureScope, createClosurePosArg),
            Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
        }, Ast.Block({
                Ast.LocalVariableDeclaration(createClosureScope, {
                    createClosureProxyObject
                }, {
                    Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.upvaluesProxyFunctionVar), {
                        Ast.VariableExpression(createClosureScope, createClosureUpvalsArg)
                    })
                }),
                Ast.LocalVariableDeclaration(createClosureScope, {createClosureFuncVar},{
                    Ast.FunctionLiteralExpression(argsTb,
                    Ast.Block({
                        Ast.ReturnStatement{
                            Ast.FunctionCallExpression(Ast.VariableExpression(self.scope, self.containerFuncVar), {
                                Ast.VariableExpression(createClosureScope, createClosurePosArg),
                                Ast.TableConstructorExpression(argsTb2),
                                Ast.VariableExpression(createClosureScope, createClosureUpvalsArg),
                                Ast.VariableExpression(createClosureScope, createClosureProxyObject)
                            })
                        }
                    }, createClosureSubScope)
                    );
                });
                Ast.ReturnStatement{Ast.VariableExpression(createClosureScope, createClosureFuncVar)}
            }, createClosureScope)
        );
        self.createClosureVars[argCount] = {
            var = var,
            val = val,
        }
    end


    local var = self.createClosureVars[argCount].var;
    return var.scope, var.id;
end

return Compiler;
