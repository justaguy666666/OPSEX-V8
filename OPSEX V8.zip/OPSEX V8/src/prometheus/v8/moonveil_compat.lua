 
 
 
local Ast = require("prometheus.ast")
local K = Ast.AstKind
local visitAst = require("prometheus.visitast")
local Parser = require("prometheus.parser")
local Unparser = require("prometheus.unparser")
local Compiler = require("prometheus.v8.compiler")
local Scope = require("prometheus.scope")
local E = require("prometheus.enums")

local M = {}
local integrityGateName = nil

function M.setIntegrityGateName(name)
    integrityGateName = name
end

local DIRECTIVE_PREFIX = "OPSEX_INTERNAL_DIRECTIVE_"
local DIRECTIVE_NAMES = {
    omit = "OMIT",
    vm = "VM",
    cff = "CFF",
}

local function longBracketAt(line, index)
    local rest = line:sub(index)
    local equals = rest:match("^%[(=*)%[")
    if equals == nil then return nil end
    return "]" .. equals .. "]", index + #equals + 1
end

local function scanLineState(line, state)
    local i = 1
    while i <= #line do
        if state and state.kind == "long" then
            local a, b = line:find(state.close, i, true)
            if not a then return state end
            state = nil
            i = b + 1
        elseif state and state.kind == "quote" then
            local ch = line:sub(i, i)
            if ch == "\\" then
                i = i + 2
            elseif ch == state.quote then
                state = nil
                i = i + 1
            else
                i = i + 1
            end
        else
            local ch = line:sub(i, i)
            local pair = line:sub(i, i + 1)
            if pair == "--" then
                local close, after = longBracketAt(line, i + 2)
                if close then
                    state = {kind="long", close=close}
                    i = after + 1
                else
                    break
                end
            elseif ch == "'" or ch == '"' then
                state = {kind="quote", quote=ch}
                i = i + 1
            elseif ch == "[" then
                local close, after = longBracketAt(line, i)
                if close then
                    state = {kind="long", close=close}
                    i = after + 1
                else
                    i = i + 1
                end
            else
                i = i + 1
            end
        end
    end
    if state and state.kind == "quote" then
        if line:sub(-1) ~= "\\" then return nil end
    end
    return state
end

function M.prepareSource(source)
    local out = {}
    local state = nil
    for line in (source .. "\n"):gmatch("([^\n]*)\n") do
        local directive = nil
        if not state then directive = line:match("^%s*%-%-!mv:([%w_%-]+).*$") end
        if directive then
            local key = DIRECTIVE_NAMES[directive:lower()]
            if not key then
                error("Unsupported OPSEX directive --!mv:" .. directive, 0)
            end
            out[#out + 1] = DIRECTIVE_PREFIX .. key .. "()"
            state = nil
        else
            out[#out + 1] = line
            state = scanLineState(line, state)
        end
    end
    return table.concat(out, "\n")
end

local function nodeName(node)
    if not node or node.kind ~= K.VariableExpression or not node.scope or node.id == nil then
        return nil
    end
    return node.scope:getVariableName(node.id)
end

local function callName(node)
    if not node or node.kind ~= K.FunctionCallExpression then return nil end
    return nodeName(node.base)
end

local function markFunction(fn, mode)
    if not fn then return end
    if fn.kind == K.FunctionLiteralExpression then
        fn.__opsex_skip_obfuscation = mode == "omit" or mode == "vm"
        fn.__opsex_protection_mode = mode
        if fn.body then
            fn.body.__opsex_skip_obfuscation = fn.__opsex_skip_obfuscation
            if fn.body.scope then fn.body.scope.__opsex_skip_obfuscation = fn.__opsex_skip_obfuscation end
        end
    elseif fn.kind == K.FunctionDeclaration or fn.kind == K.LocalFunctionDeclaration then
        fn.__opsex_skip_obfuscation = mode == "omit"
        fn.__opsex_protection_mode = mode
        if fn.body then
            fn.body.__opsex_skip_obfuscation = mode == "omit" or mode == "vm"
            if fn.body.scope then fn.body.scope.__opsex_skip_obfuscation = mode == "omit" or mode == "vm" end
        end
    elseif fn.kind == K.LocalVariableDeclaration then
        for _, value in ipairs(fn.expressions or {}) do
            if value.kind == K.FunctionLiteralExpression then markFunction(value, mode) end
        end
    end
end

local function isDirectiveCall(stmt, expected)
    if not stmt or stmt.kind ~= K.FunctionCallStatement then return false end
    local name = nodeName(stmt.base)
    return name == DIRECTIVE_PREFIX .. expected
end

local function markDirectiveTarget(stmt, mode)
    if not stmt then
        error("--!mv:" .. mode .. " must precede a function declaration", 0)
    end
    if stmt.kind == K.FunctionDeclaration or stmt.kind == K.LocalFunctionDeclaration then
        markFunction(stmt, mode)
        return
    end
    if stmt.kind == K.LocalVariableDeclaration then
        local marked = false
        for _, value in ipairs(stmt.expressions or {}) do
            if value.kind == K.FunctionLiteralExpression then
                markFunction(value, mode)
                marked = true
            end
        end
        if marked then return end
    end
    error("--!mv:" .. mode .. " must precede a function declaration", 0)
end

local function macroError(name, mode)
    error("OPSEX macro " .. name .. " is documented by MoonVeil but is not implemented in OPSEX mode '" .. mode .. "' yet; refusing to emit a broken script", 0)
end

function M.prepareAst(ast, mode)
    mode = mode or "cff"
    local directives = {OMIT="omit", VM="vm", CFF="cff"}

     
     
    visitAst(ast, function(node)
        if node.__opsex_skip_obfuscation then return node, true end
        if node.kind == K.VariableExpression then
            local name = nodeName(node)
            if name == "MV_OBFUSCATED" or name == "LPH_OBFUSCATED" then
                return Ast.BooleanExpression(true), true
            end
        end
        if node.kind == K.FunctionCallExpression then
            local name = callName(node)
            if name == "MV_OMIT" or name == "MV_OMIT_FUNCTION" or name == "LPH_NO_VIRTUALIZE" then
                local value = node.args and node.args[1]
                if value and value.kind == K.FunctionLiteralExpression then markFunction(value, "omit") end
                return value or Ast.NilExpression(), true
            elseif name == "MV_VM" then
                if mode ~= "cff" and mode ~= "vm" then macroError(name, mode) end
                local value = node.args and node.args[1]
                if not value or value.kind ~= K.FunctionLiteralExpression then
                    error("MV_VM expects an anonymous function as its first argument", 0)
                end
                if node.args[2] then
                    error("OPSEX currently supports one VM backend; the MV_VM vmType argument is not supported", 0)
                end
                markFunction(value, "vm")
            elseif name == "MV_COMPRESS" or name == "LPH_ENCSTR" or name == "LPH_ENCNUM" or name == "LPH_JIT" or name == "LPH_NO_UPVALUES" then
                return (node.args and node.args[1]) or Ast.NilExpression(), true
            elseif name == "MV_CRASH" or name == "LPH_CRASH" then
                local scope, id = ast.globalScope:resolveGlobal("error")
                return Ast.FunctionCallExpression(Ast.VariableExpression(scope, id), {Ast.StringExpression("OPSEX crash macro triggered")}), true
            elseif name == "MV_ENC_FUNC" or name == "LPH_ENCFUNC" or name == "MV_CFF" or name == "MV_ENC_STR" or name == "MV_INDEX_TO_NUM" or name == "MV_REWRITE" or name == "MV_PRECHECK" or name == "MV_INLINE" then
                macroError(name, mode)
            end
        end
        return node
    end, function(node)
        if node.kind == K.Block then
            local i = 1
            while i <= #node.statements do
                local stmt = node.statements[i]
                local targetMode
                for key, value in pairs(directives) do
                    if isDirectiveCall(stmt, key) then targetMode = value; break end
                end
                if targetMode then
                    markDirectiveTarget(node.statements[i + 1], targetMode)
                    table.remove(node.statements, i)
                else
                    i = i + 1
                end
            end
        end
        return node
    end, {})
    return ast
end

local function hasCapturedLocals(fn, globalScope)
    local inside, seen = {}, {}
    local function collect(scope)
        if not scope or inside[scope] then return end
        inside[scope] = true
        for _, child in ipairs(scope.children or {}) do collect(child) end
    end
    collect(fn.body and fn.body.scope)
    local captured = false
    local function walk(x)
        if captured or type(x) ~= "table" or seen[x] then return end
        seen[x] = true
        if x.kind == K.VariableExpression or x.kind == "AssignmentVariable" then
            if x.scope and x.scope ~= globalScope and not inside[x.scope] then
                captured = true
                return
            end
        end
        if x.kind then
            for k, v in pairs(x) do
                if k ~= "scope" and k ~= "parentScope" and k ~= "globalScope"
                    and k ~= "isAst" and k ~= "parent" and type(v) == "table" then
                    if v.kind then walk(v)
                    else for _, item in pairs(v) do walk(item) end end
                end
            end
        end
    end
    walk(fn.body)
    return captured
end

 
 
 
local function inspectAutoVmBody(body)
    local count, unsafe, hasString = 0, false, false
    local loopCount, maxLoopDepth = 0, 0
    local seen = {}
    local loopKinds = {
        [K.WhileStatement]=true, [K.RepeatStatement]=true,
        [K.ForStatement]=true, [K.ForInStatement]=true,
    }
    local function walk(x, root, loopDepth)
        if type(x) ~= "table" or seen[x] then return end
        seen[x] = true
        if x.kind then
            count = count + 1
            local childLoopDepth = loopDepth or 0
            if loopKinds[x.kind] then
                loopCount = loopCount + 1
                childLoopDepth = childLoopDepth + 1
                if childLoopDepth > maxLoopDepth then maxLoopDepth = childLoopDepth end
            end
            if x.kind == K.StringExpression then hasString = true end
            if not root and x.kind == K.FunctionLiteralExpression then unsafe = true end
            for k, v in pairs(x) do
                if k ~= "scope" and k ~= "parentScope" and k ~= "globalScope"
                    and k ~= "isAst" and k ~= "parent" and type(v) == "table" then
                    if v.kind then walk(v, false, childLoopDepth)
                    else for _, item in pairs(v) do walk(item, false, childLoopDepth) end end
                end
            end
        end
    end
    walk(body, true, 0)
     
     
     
    if loopCount > 3 or maxLoopDepth > 1 then unsafe = true end
    return count, unsafe, hasString
end

local function encodedStringExpression(value, globalScope)
    if value == "" then return Ast.StringExpression("") end
    local stringScope, stringId = globalScope:resolveGlobal("string")
    local chunks = {}
    local offset = 1
    while offset <= #value do
        local args = {}
        local stopAt = math.min(#value, offset + 63)
        for i = offset, stopAt do args[#args + 1] = Ast.NumberExpression(value:byte(i)) end
        local base = Ast.IndexExpression(Ast.VariableExpression(stringScope, stringId), Ast.StringExpression("char"))
        chunks[#chunks + 1] = Ast.FunctionCallExpression(base, args)
        offset = stopAt + 1
    end
    local result = chunks[1]
    for i = 2, #chunks do result = Ast.StrCatExpression(result, chunks[i]) end
    return result
end

local function encodeBodyStrings(body, globalScope)
    local seen = {}
    local function walk(x, parent, key)
        if type(x) ~= "table" or seen[x] then return end
        seen[x] = true
        if x.kind == K.StringExpression then
            local replacement = encodedStringExpression(tostring(x.value or ""), globalScope)
            if parent then parent[key] = replacement end
            return
        end
        if x.kind then
            for k, v in pairs(x) do
                if k ~= "scope" and k ~= "parentScope" and k ~= "globalScope"
                    and k ~= "isAst" and k ~= "parent" and type(v) == "table" then
                    if v.kind then walk(v, x, k)
                    else
                        for index, item in pairs(v) do
                            if type(item) == "table" then walk(item, v, index) end
                        end
                    end
                end
            end
        end
    end
    walk(body, nil, nil)
end

 
 
 
local function findHotTopLevelFunctions(ast)
    local topScope = ast.body and ast.body.scope
    local declarations, hot, calls = {}, {}, {}
    local function keyFor(scope, id) return scope and (tostring(scope) .. ":" .. tostring(id)) end
    local function walk(x, fn)
        local seen = {}
        local function visit(node)
            if type(node) ~= "table" or not node.kind or seen[node] then return end
            seen[node] = true
            fn(node)
            for k, v in pairs(node) do
                if k ~= "scope" and k ~= "parentScope" and k ~= "globalScope"
                    and k ~= "isAst" and k ~= "parent" and type(v) == "table" then
                    if v.kind then visit(v)
                    else for _, item in pairs(v) do if type(item) == "table" then visit(item) end end end
                end
            end
        end
        visit(x)
    end

    local function register(node)
        if node.kind == K.LocalFunctionDeclaration and node.scope == topScope then
            declarations[keyFor(node.scope, node.id)] = node
            calls[node] = {}
        end
    end
    walk(ast.body, register)

     
     
     
    local callbackMethods = {
        connect=true, connectparallel=true, once=true,
        bindtorenderstep=true, bindtosimulation=true, bindtoclose=true,
        oninvoke=true, bindaction=true, bindactionatpriority=true,
        setcore=true,
    }
    local callbackFunctions = {spawn=true, defer=true, delay=true, wrap=true}
    local function terminalName(expr)
        if not expr then return nil end
        if expr.kind == K.VariableExpression then return nodeName(expr) end
        if expr.kind == K.IndexExpression then
            local idx = expr.index
            if idx and idx.kind == K.StringExpression then return tostring(idx.value) end
        end
        return nil
    end
    local function isCallbackRegistration(node)
        local member = (node.kind == K.PassSelfFunctionCallExpression or node.kind == K.PassSelfFunctionCallStatement)
            and node.passSelfFunctionName or nil
        if member and callbackMethods[string.lower(tostring(member))] then return true end
        local base = node.base
        local name = terminalName(base)
        if name then
            local lower = string.lower(tostring(name))
            if callbackMethods[lower] then return true end
            if callbackFunctions[lower] then return true end
        end
         
         
        if base and base.kind == K.IndexExpression then
            local parentName = terminalName(base.base)
            local lowerParent = parentName and string.lower(tostring(parentName))
            if lowerParent == "task" or lowerParent == "coroutine" then
                local leaf = terminalName(base)
                if leaf and callbackFunctions[string.lower(tostring(leaf))] then return true end
            end
        end
        return false
    end
    local hotSignals = {
        heartbeat=true, renderstepped=true, stepped=true, prerender=true,
        presimulation=true, postsimulation=true, inputbegan=true, inputchanged=true,
        inputended=true, touchmoved=true, mousemoved=true, mousebutton1down=true,
        mousebutton1up=true, mousebutton2down=true, mousebutton2up=true,
        move=true, jump=true,
    }
    local function isHotCallbackRegistration(node)
        if not isCallbackRegistration(node) then return false end
        local method = (node.kind == K.PassSelfFunctionCallExpression or node.kind == K.PassSelfFunctionCallStatement)
            and string.lower(tostring(node.passSelfFunctionName or '')) or string.lower(tostring(terminalName(node.base) or ''))
        if method == 'bindtorenderstep' or method == 'bindtosimulation' then return true end
         
         
        if method == 'spawn' or method == 'defer' or method == 'delay' or method == 'wrap' then return true end
        if method == 'connect' or method == 'connectparallel' then
            local receiver = node.base
            if node.kind == K.FunctionCallExpression or node.kind == K.FunctionCallStatement then
                receiver = receiver and receiver.kind == K.IndexExpression and receiver.base or receiver
            end
            local signal = terminalName(receiver)
            return signal ~= nil and hotSignals[string.lower(tostring(signal))] == true
        end
         
         
        return false
    end

    local function markExpressionCallback(expr)
        if not expr then return end
        if expr.kind == K.VariableExpression then
            local id = keyFor(expr.scope, expr.id)
            if declarations[id] then hot[id] = true end
        elseif expr.kind == K.FunctionLiteralExpression and expr.body then
             
             
            expr.__opsex_hot_callback = true
            expr.body.__opsex_hot_callback = true
             
             
            walk(expr.body, function(n)
                if (n.kind == K.FunctionCallExpression or n.kind == K.PassSelfFunctionCallExpression
                    or n.kind == K.FunctionCallStatement or n.kind == K.PassSelfFunctionCallStatement)
                    and n.base and n.base.kind == K.VariableExpression then
                    local id = keyFor(n.base.scope, n.base.id)
                    if declarations[id] then hot[id] = true end
                end
            end)
        end
    end
    walk(ast.body, function(node)
        if node.kind == K.FunctionCallExpression or node.kind == K.PassSelfFunctionCallExpression
            or node.kind == K.FunctionCallStatement or node.kind == K.PassSelfFunctionCallStatement then
            if isHotCallbackRegistration(node) then
                for _, arg in ipairs(node.args or {}) do markExpressionCallback(arg) end
            end
             
             
             
             
            local function markTableCallbacks(expr, seen)
                if type(expr) ~= "table" or not expr.kind or seen[expr] then return end
                seen[expr] = true
                if expr.kind == K.FunctionLiteralExpression then
                    markExpressionCallback(expr)
                    return
                end
                if expr.kind == K.TableConstructorExpression then
                    for _, entry in ipairs(expr.entries or {}) do
                        if entry.kind == K.KeyedTableEntry and entry.value
                            and entry.value.kind == K.FunctionLiteralExpression then
                            markExpressionCallback(entry.value)
                        elseif entry.kind == K.TableEntry and entry.value
                            and entry.value.kind == K.FunctionLiteralExpression then
                            markExpressionCallback(entry.value)
                        end
                    end
                end
                for key, value in pairs(expr) do
                    if key ~= "scope" and key ~= "parentScope" and key ~= "globalScope"
                        and key ~= "parent" and key ~= "isAst" and type(value) == "table" then
                        if value.kind then markTableCallbacks(value, seen)
                        else for _, child in pairs(value) do markTableCallbacks(child, seen) end end
                    end
                end
            end
            if isHotCallbackRegistration(node) then
                for _, arg in ipairs(node.args or {}) do
                    if arg.kind == K.TableConstructorExpression then markTableCallbacks(arg, {}) end
                end
            end
        end
    end)

     
    local changed = true
    while changed do
        changed = false
        for id, decl in pairs(declarations) do
            if hot[id] then
                walk(decl.body, function(n)
                    if (n.kind == K.FunctionCallExpression or n.kind == K.PassSelfFunctionCallExpression
                        or n.kind == K.FunctionCallStatement or n.kind == K.PassSelfFunctionCallStatement)
                        and n.base and n.base.kind == K.VariableExpression then
                        local called = keyFor(n.base.scope, n.base.id)
                        if declarations[called] and not hot[called] then hot[called] = true; changed = true end
                    end
                end)
            end
        end
    end
     
     
    for id in pairs(hot) do
        local declaration = declarations[id]
        if declaration then
            declaration.__opsex_hot_callback = true
            if declaration.body then declaration.body.__opsex_hot_callback = true end
        end
    end
    return hot, keyFor
end

 
 
 
 
local function collectLowerableCaptures(fn, globalScope, selfScope, selfId)
    local inside, scopesSeen = {}, {}
    local function collectScope(scope)
        if not scope or inside[scope] then return end
        inside[scope] = true
        for _, child in ipairs(scope.children or {}) do collectScope(child) end
    end
    collectScope(fn.body and fn.body.scope)

    local captures, byKey, seenNodes = {}, {}, {}
    local invalid = false
    local function key(scope, id) return tostring(scope) .. ':' .. tostring(id) end
    local function walk(node)
        if invalid or type(node) ~= 'table' or not node.kind or seenNodes[node] then return end
        seenNodes[node] = true
        if node.kind == K.FunctionLiteralExpression and node ~= fn then
            invalid = true
            return
        end
        if node.kind == K.AssignmentVariable and node.scope and node.scope ~= globalScope and not inside[node.scope] then
            invalid = true
            return
        end
        if node.kind == K.VariableExpression and node.scope and node.scope ~= globalScope and not inside[node.scope] then
            if node.scope == selfScope and node.id == selfId then
                invalid = true  
                return
            end
            local k = key(node.scope, node.id)
            if not byKey[k] then
                local item = {scope=node.scope, id=node.id, key=k}
                byKey[k] = item
                captures[#captures + 1] = item
            end
        end
        for k, v in pairs(node) do
            if k ~= 'scope' and k ~= 'parentScope' and k ~= 'globalScope' and k ~= 'isAst' and k ~= 'parent'
                and type(v) == 'table' then
                if v.kind then walk(v)
                else for _, child in pairs(v) do if type(child) == 'table' then walk(child) end end end
            end
        end
    end
    walk(fn.body)
    if invalid then return nil end
    table.sort(captures, function(a, b)
        if a.scope == b.scope then return a.id < b.id end
        return tostring(a.scope) < tostring(b.scope)
    end)
    return captures
end

local function rewriteCaptureReferences(body, captureMap, restore)
    local seen = {}
    local function walk(node, parent, key)
        if type(node) ~= 'table' or seen[node] then return end
        seen[node] = true
        if (node.kind == K.VariableExpression or node.kind == K.AssignmentVariable) and node.scope then
            local replacement = captureMap[tostring(node.scope) .. ':' .. tostring(node.id)]
            if replacement then
                restore[#restore + 1] = {parent=parent, key=key, original=node}
                if node.kind == K.AssignmentVariable then
                    parent[key] = Ast.AssignmentVariable(replacement.scope, replacement.id)
                else
                    parent[key] = Ast.VariableExpression(replacement.scope, replacement.id)
                end
                return
            end
        end
        if node.kind then
            for k, v in pairs(node) do
                if k ~= 'scope' and k ~= 'parentScope' and k ~= 'globalScope' and k ~= 'isAst' and k ~= 'parent'
                    and type(v) == 'table' then
                    if v.kind then walk(v, node, k)
                    else for index, item in pairs(v) do if type(item) == 'table' then walk(item, v, index) end end end
                end
            end
        end
    end
    walk(body, nil, nil)
end

local function buildCaptureWrapper(node, ast, compiledExpression, captures)
    local factoryScope = Scope:new(node.scope)
    local factoryArgs, factoryCaptureVars = {}, {}
    for i, capture in ipairs(captures) do
        local name = '_opx_outer_' .. tostring(i)
        local id = factoryScope:addVariable(name)
        factoryArgs[#factoryArgs + 1] = Ast.VariableExpression(factoryScope, id)
        factoryCaptureVars[#factoryCaptureVars + 1] = Ast.VariableExpression(factoryScope, id)
    end
     
     
    factoryArgs[#factoryArgs + 1] = Ast.VarargExpression()

    local vmName = '_opx_vmfn'
    local vmId = factoryScope:addVariable(vmName)
    local vmVar = Ast.VariableExpression(factoryScope, vmId)

    local wrapperScope = Scope:new(factoryScope)
    local wrapperArgs, vmCallArgs = {}, {}
    for _, captureVar in ipairs(factoryCaptureVars) do vmCallArgs[#vmCallArgs + 1] = captureVar end
    for i, arg in ipairs(node.args or {}) do
        if arg.kind == K.VarargExpression then return nil end
        local originalName = arg.scope and arg.scope:getVariableName(arg.id)
        if not originalName then return nil end
        local argId = wrapperScope:addVariable(originalName)
        wrapperArgs[#wrapperArgs + 1] = Ast.VariableExpression(wrapperScope, argId)
        vmCallArgs[#vmCallArgs + 1] = Ast.VariableExpression(wrapperScope, argId)
    end

    local vmCall = Ast.FunctionCallExpression(vmVar, vmCallArgs)
    local innerBody = Ast.Block({Ast.ReturnStatement({vmCall})}, wrapperScope)
    local innerFunction = Ast.FunctionLiteralExpression(wrapperArgs, innerBody)
    local vmDeclaration = Ast.LocalVariableDeclaration(factoryScope, {vmId}, {compiledExpression})
    local factoryBody = Ast.Block({vmDeclaration, Ast.ReturnStatement({innerFunction})}, factoryScope)
    local factoryFunction = Ast.FunctionLiteralExpression(factoryArgs, factoryBody)
    factoryFunction.isParenthesizedExpression = true
    local factoryCallArgs = {}
    for _, capture in ipairs(captures) do
        factoryCallArgs[#factoryCallArgs + 1] = Ast.VariableExpression(capture.scope, capture.id)
    end
    factoryCallArgs[#factoryCallArgs + 1] = Ast.VarargExpression()
    return Ast.FunctionCallExpression(factoryFunction, factoryCallArgs)
end

function M.selectAutoVmCandidates(ast, maxCandidates)
    maxCandidates = math.max(0, math.floor(tonumber(maxCandidates) or 1))
    local marked, skipped = 0, 0
    if maxCandidates == 0 then return ast, marked, skipped end
    local hotFunctions, keyFor = findHotTopLevelFunctions(ast)
    ast = visitAst(ast, function(node)
        if marked >= maxCandidates then return node end
        if node.kind == K.LocalFunctionDeclaration
            and node.__opsex_protection_mode == nil
            and node.scope == (ast.body and ast.body.scope) then
            local fn = Ast.FunctionLiteralExpression(node.args, node.body)
            local size, risky = inspectAutoVmBody(node.body)
            local captures = collectLowerableCaptures(fn, ast.globalScope, node.scope, node.id)
            local isHot = hotFunctions[keyFor(node.scope, node.id)] == true
            local hasVararg = false
            for _, arg in ipairs(node.args or {}) do if arg.kind == K.VarargExpression then hasVararg = true end end
             
             
             
             
            if not isHot and not risky and size <= 768 and captures and not hasVararg then
                node.__opsex_auto_vm_captures = captures
                node.__opsex_auto_vm_candidate = true
                node.scope.__opsex_auto_vm_ids = node.scope.__opsex_auto_vm_ids or {}
                node.scope.__opsex_auto_vm_ids[node.id] = true
                encodeBodyStrings(node.body, ast.globalScope)
                if node.body then node.body.__opsex_skip_obfuscation = true end
                marked = marked + 1
            else
                skipped = skipped + 1
            end
        end
        return node
    end, nil, {})
    return ast, marked, skipped
end


local function compileVmFunction(fn, ast, seed, luaVersion)
    if hasCapturedLocals(fn, ast.globalScope) then
        error("MV_VM function captures local/upvalue state; selective VM lowering currently requires a self-contained function. Use --!mv:omit for hot callbacks or keep this function in CFF mode.", 0)
    end
    local compiledFunction = fn
    if integrityGateName then
         
         
         
         
         
        local gateCallAst = Parser:new({LuaVersion=luaVersion}):parse(integrityGateName .. "()")
        local statements = {gateCallAst.body.statements[1]}
        for _, statement in ipairs(fn.body.statements or {}) do
            statements[#statements + 1] = statement
        end
        local body = Ast.Block(statements, fn.body.scope)
        compiledFunction = Ast.FunctionLiteralExpression(fn.args, body)
    end
    local wrapper = Ast.TopNode(Ast.Block({Ast.ReturnStatement({compiledFunction})}, ast.body.scope), ast.globalScope)
     
     
     
     
    wrapper = M.lowerMethodCallNames(wrapper)
    local snippet = Unparser:new({LuaVersion=luaVersion, PrettyPrint=false}):unparse(wrapper)
    local isolated = Parser:new({LuaVersion=luaVersion}):parse(snippet)
    math.randomseed(tonumber(seed) or 0)
    local compiled = Compiler:new({v6=true, v7=true, v8=true, seed=tonumber(seed) or 0}):compile(isolated)
    local first = compiled.body and compiled.body.statements and compiled.body.statements[1]
    local expression = first and first.args and first.args[1]
    if not expression then error("MV_VM lowering produced no callable VM expression", 0) end
    return expression
end

function M.lowerAutoVmCandidates(ast, seed, luaVersion)
    local lowered, failed = 0, 0
    local luaVer = luaVersion or E.LuaVersion.LuaU
    ast = visitAst(ast, function(node)
        local markedIds = node.scope and node.scope.__opsex_auto_vm_ids
        if node.kind == K.LocalFunctionDeclaration
            and (node.__opsex_auto_vm_candidate or (markedIds and markedIds[node.id])) then
            local captures = node.__opsex_auto_vm_captures or {}
            local fn = Ast.FunctionLiteralExpression(node.args, node.body)
            local captureMap, restore = {}, {}
            local extraArgs = {}
            local ok, expression = pcall(function()
                for i, capture in ipairs(captures) do
                    local capName = '_opx_capture_' .. tostring(i)
                    local capId = node.body.scope:addVariable(capName)
                    local capExpr = Ast.VariableExpression(node.body.scope, capId)
                    captureMap[capture.key] = {scope=node.body.scope, id=capId}
                    extraArgs[#extraArgs + 1] = capExpr
                end
                rewriteCaptureReferences(node.body, captureMap, restore)
                local vmArgs = {}
                for _, arg in ipairs(extraArgs) do vmArgs[#vmArgs + 1] = arg end
                for _, arg in ipairs(node.args or {}) do vmArgs[#vmArgs + 1] = arg end
                fn.args = vmArgs
                return compileVmFunction(fn, ast,
                    (tonumber(seed) or 0) + (lowered + failed) * 7919, luaVer)
            end)
             
            for i = #restore, 1, -1 do
                local item = restore[i]
                item.parent[item.key] = item.original
            end
            if not ok then
                failed = failed + 1
                if node.body then node.body.__opsex_skip_obfuscation = nil end
                return node
            end
            local initializer
            if #captures == 0 then
                initializer = expression
            else
                local wrapped, wrapError = pcall(buildCaptureWrapper, node, ast, expression, captures)
                if not wrapped or not wrapError then
                    failed = failed + 1
                    if node.body then node.body.__opsex_skip_obfuscation = nil end
                    return node
                end
                initializer = wrapError
            end
            local replacement = Ast.LocalVariableDeclaration(node.scope, {node.id}, {initializer})
            replacement.__opsex_skip_obfuscation = true
            lowered = lowered + 1
            return replacement, true
        end
        return node
    end, nil, {})
    return ast, lowered, failed
end

 
 
 
 
 
 
local function isStableReceiver(expr)
    if not expr then return false end
    if expr.kind == K.VariableExpression then return true end
    if expr.kind == K.IndexExpression then
        local index = expr.index
        local stableIndex = index and (index.kind == K.StringExpression or index.kind == K.NumberExpression
            or index.kind == K.VariableExpression)
        return stableIndex and isStableReceiver(expr.base)
    end
    return false
end

function M.lowerMethodCallNames(ast)
    local lowered = 0
    ast = visitAst(ast, function(node)
        if (node.kind == K.PassSelfFunctionCallExpression or node.kind == K.PassSelfFunctionCallStatement)
            and type(node.passSelfFunctionName) == 'string' and isStableReceiver(node.base) then
            local receiver = node.base
            local method = Ast.IndexExpression(receiver, Ast.StringExpression(node.passSelfFunctionName))
            local args = {receiver}
            for _, arg in ipairs(node.args or {}) do args[#args + 1] = arg end
            lowered = lowered + 1
            if node.kind == K.PassSelfFunctionCallStatement then
                return Ast.FunctionCallStatement(method, args), true
            end
            return Ast.FunctionCallExpression(method, args), true
        end
        return node
    end, nil, {})
    return ast, lowered
end

function M.lowerVmMacros(ast, seed, luaVersion)
    local count = 0
    local luaVer = luaVersion or E.LuaVersion.LuaU
    ast = visitAst(ast, function(node)
        if node.kind == K.LocalFunctionDeclaration and node.__opsex_protection_mode == "vm" then
            local fn = Ast.FunctionLiteralExpression(node.args, node.body)
            local ok, expression = pcall(compileVmFunction, fn, ast, (tonumber(seed) or 0) + count * 7919, luaVer)
            if not ok then
                if node.__opsex_auto_vm then return node end
                error(expression, 0)
            end
            count = count + 1
            return Ast.LocalVariableDeclaration(node.scope, {node.id}, {expression}), true
        elseif node.kind == K.FunctionDeclaration and node.__opsex_protection_mode == "vm" then
            local fn = Ast.FunctionLiteralExpression(node.args, node.body)
            local expression = compileVmFunction(fn, ast, seed, luaVer)
            count = count + 1
            return Ast.AssignmentStatement({Ast.AssignmentVariable(node.scope, node.id)}, {expression}), true
        elseif node.kind == K.LocalVariableDeclaration then
            local replaced = false
            for i, value in ipairs(node.expressions or {}) do
                if value.kind == K.FunctionLiteralExpression and value.__opsex_protection_mode == "vm" then
                    node.expressions[i] = compileVmFunction(value, ast, seed, luaVer)
                    count = count + 1
                    replaced = true
                end
            end
            if replaced then return node, true end
        elseif node.kind == K.FunctionCallExpression and callName(node) == "MV_VM" then
            local fn = node.args and node.args[1]
            if not fn or fn.kind ~= K.FunctionLiteralExpression then
                error("MV_VM expects an anonymous function", 0)
            end
            local expression = compileVmFunction(fn, ast, seed, luaVer)
            count = count + 1
            return expression, true
        end
        return node
    end, nil, {})
    return ast, count
end

return M
