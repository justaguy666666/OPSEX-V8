 
 
 
 
 

local PREFIX = "_";

return function(id, _)
	return PREFIX .. tostring(id);
end
